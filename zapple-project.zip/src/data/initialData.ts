import { User, Wallet, Transaction, AppNotification, SupportTicket, TaskSubmission, Withdrawal } from '../types';

// Real user accounts are populated dynamically from backend authentication
export const INITIAL_USERS: User[] = [];

// Production Real Wallet: Starts with real 0 balances, loaded dynamically from backend ledger
export const INITIAL_WALLET: Wallet = {
  userId: '',
  currentBalance: 0,
  pendingBalance: 0,
  paidOutTotal: 0,
  totalEarned: 0,
  demoBalance: 0,
  pendingRewards: 0,
};

export const INITIAL_TASKS: any[] = [];

export const INITIAL_SUBMISSIONS: TaskSubmission[] = [];

// No fake transactions - transactions populate from real backend ledger
export const INITIAL_TRANSACTIONS: Transaction[] = [];

export const INITIAL_WITHDRAWALS: Withdrawal[] = [];

export const INITIAL_NOTIFICATIONS: AppNotification[] = [
  {
    id: 'notif_welcome',
    userId: 'all',
    title: 'Welcome to TalkReward',
    message: 'Connect on 3-minute voice conversations with peers to earn ₹20 per verified call. Earnings mature after a 15-day holding period.',
    type: 'system_announcement',
    createdAt: '2026-09-15T00:00:00.000Z',
    read: false,
  },
];

export const INITIAL_FAQS = [
  {
    q: 'How do I earn ₹20 on TalkReward?',
    a: 'Start a call or join with a 6-character code. Both participants engage in a genuine 3-minute voice conversation on the selected topic. Once the full 3 minutes complete and automated quality verification passes, ₹20 is credited.',
  },
  {
    q: 'What is the 15-day holding period?',
    a: 'To guarantee audio quality, prevent duplicate gaming, and maintain institutional integrity, verified rewards enter an automated 15-day holding period before becoming eligible for withdrawal. Once matured, funds move automatically to your withdrawable Current Balance.',
  },
  {
    q: 'How do I withdraw my earnings?',
    a: 'Once your rewards mature in your Current Balance (minimum ₹20), enter your UPI ID or Bank Account details in the Earnings tab and tap Withdraw. Payouts are processed directly via banking rails.',
  },
  {
    q: 'Why did my call fail verification?',
    a: 'Calls require active, audible 2-way microphone participation by both people throughout the 3 minutes on the chosen topic. Sessions with dead air, early disconnects, or single-speaker monopolization fail quality checks. You can submit an appeal if you believe the decision was mistaken.',
  },
  {
    q: 'How is TalkReward funded?',
    a: 'TalkReward rewards are backed by institutional conversational AI research partnerships, sponsored corporate debate topics, and linguistic diversity data grants.',
  },
];

export const INITIAL_TICKETS: SupportTicket[] = [];
