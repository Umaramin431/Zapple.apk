import { TranscriptMessage } from '../types';

interface TopicDialogue {
  keywords: string[];
  exchanges: Array<{
    creator: string;
    joiner: string;
  }>;
}

const TOPIC_DIALOGUES: Record<string, TopicDialogue> = {
  ai: {
    keywords: ['ai', 'artificial intelligence', 'technology', 'jobs', 'future'],
    exchanges: [
      {
        creator: 'I believe artificial intelligence will create significantly more high-skilled opportunities than the jobs it automates.',
        joiner: 'While innovation does open new industries, historical transitions have been painful for entry-level workers who need urgent reskilling.',
      },
      {
        creator: 'That is valid, but look at software engineering and medical diagnostics—AI assistants amplify productivity rather than replace human empathy.',
      joiner: 'The key distinction is pace: AI improves exponentially, which leaves limited transition time for displaced professionals to adapt.',
      },
      {
        creator: 'Policy and universal digital literacy training can balance that gap if tech companies invest proportionally in education.',
        joiner: 'I agree ethical governance is necessary, though strict regulations might slow down crucial breakthroughs in scientific discovery.',
      },
      {
        creator: 'In summary, balanced guardrails allow society to maximize AI benefits while protecting workforce stability.',
        joiner: 'Well stated. Both technological progress and proactive social safety nets must progress hand in hand.',
      },
    ],
  },
  remote: {
    keywords: ['remote', 'work', 'office', 'hybrid', 'commute', 'productivity'],
    exchanges: [
      {
        creator: 'Remote work provides indisputable flexibility and saves workers hours of exhausting daily commuting time.',
        joiner: 'It definitely saves commute time, but in-person spontaneity and organic team mentoring often suffer in fully remote setups.',
      },
      {
        creator: 'Modern collaborative whiteboards and async documentation can replicate mentorship if managers are intentional.',
        joiner: 'True, yet junior team members often report feeling more isolated without spontaneous corridor conversations and casual lunches.',
      },
      {
        creator: 'A structured hybrid model gives employees autonomy during focused workdays and connection on collaboration days.',
        joiner: 'That hybrid compromise seems to yield the best balance between employee well-being and cohesive team culture.',
      },
    ],
  },
  general: {
    keywords: ['debate', 'topic', 'perspective', 'argument'],
    exchanges: [
      {
        creator: 'Starting our discussion on this proposition: there are compelling arguments supporting both structural and individual approaches.',
        joiner: 'I agree. Examining the empirical evidence helps us determine which side delivers sustainable long-term outcomes.',
      },
      {
        creator: 'Taking the affirmative stance, prioritizing practical innovation allows faster adaptation to changing social and economic demands.',
        joiner: 'On the negative stance, caution and risk assessment are critical to prevent unintended negative consequences down the line.',
      },
      {
        creator: 'That is why an iterative approach works best—implement gradual improvements and monitor feedback metrics.',
        joiner: 'Agreed. Weighing both perspectives gives us a much more comprehensive and grounded understanding of the issue.',
      },
    ],
  },
};

export function getSampleTranscriptForTopic(
  topic: string,
  creatorName: string,
  participantName: string
): TranscriptMessage[] {
  const lowerTopic = (topic || '').toLowerCase();

  let selected = TOPIC_DIALOGUES.general;
  if (lowerTopic.includes('ai') || lowerTopic.includes('intelligence') || lowerTopic.includes('robot')) {
    selected = TOPIC_DIALOGUES.ai;
  } else if (lowerTopic.includes('remote') || lowerTopic.includes('office') || lowerTopic.includes('work')) {
    selected = TOPIC_DIALOGUES.remote;
  }

  const messages: TranscriptMessage[] = [];
  let currentSecond = 8;

  selected.exchanges.forEach((ex, idx) => {
    // Creator turn
    messages.push({
      id: `tr_${Date.now()}_c${idx}`,
      speakerId: 'creator_user',
      speakerName: creatorName,
      text: ex.creator,
      timestamp: new Date(Date.now() - (180 - currentSecond) * 1000).toISOString(),
      secondsIntoCall: currentSecond,
      confidence: 0.96,
    });
    currentSecond += 22;

    // Joiner turn
    messages.push({
      id: `tr_${Date.now()}_j${idx}`,
      speakerId: 'joiner_user',
      speakerName: participantName,
      text: ex.joiner,
      timestamp: new Date(Date.now() - (180 - currentSecond) * 1000).toISOString(),
      secondsIntoCall: currentSecond,
      confidence: 0.94,
    });
    currentSecond += 24;
  });

  return messages;
}
