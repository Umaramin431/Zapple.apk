/**
 * Dedicated real microphone manager for Zapple voice calls.
 * ZERO execution occurs on app startup, home screen, earnings, profile, or routing.
 * ONLY triggered when user is on the actual voice call waiting room or joins a call.
 */

let cachedAudioStream: MediaStream | null = null;

export type MicPermissionState = 'prompt' | 'granted' | 'denied' | 'unsupported' | 'unknown';

export interface MicRequestResult {
  success: boolean;
  stream?: MediaStream;
  error?: string;
  isDenied?: boolean;
  errorType?: 'denied' | 'not_found' | 'in_use' | 'security' | 'unsupported' | 'unknown';
}

/**
 * Checks the current browser microphone permission state without triggering a prompt
 */
export async function queryMicrophonePermissionState(): Promise<MicPermissionState> {
  // If we already hold a live active audio track, it's definitely granted
  if (isMicrophoneActive()) {
    return 'granted';
  }

  if (typeof navigator === 'undefined') {
    return 'unsupported';
  }

  if (navigator.permissions && navigator.permissions.query) {
    try {
      const status = await navigator.permissions.query({ name: 'microphone' as PermissionName });
      return (status.state as MicPermissionState) || 'prompt';
    } catch {
      // Some browsers (e.g. Safari) throw on 'microphone' in permissions.query
      return 'unknown';
    }
  }

  return 'unknown';
}

/**
 * Requests real microphone access via navigator.mediaDevices.getUserMedia
 */
export async function requestCallMicrophone(): Promise<MicRequestResult> {
  try {
    // If an active stream track is already alive and valid, reuse it
    if (isMicrophoneActive() && cachedAudioStream) {
      return { success: true, stream: cachedAudioStream };
    }

    if (
      typeof navigator === 'undefined' ||
      !navigator.mediaDevices ||
      !navigator.mediaDevices.getUserMedia
    ) {
      return {
        success: false,
        error: 'Microphone access is not supported or not available in this browser environment.',
        errorType: 'unsupported',
      };
    }

    // Explicitly request user media stream
    const stream = await navigator.mediaDevices.getUserMedia({
      audio: {
        echoCancellation: { ideal: true },
        noiseSuppression: { ideal: true },
        autoGainControl: { ideal: true },
      },
      video: false,
    });

    // Ensure audio tracks actually exist and are live
    const tracks = stream.getAudioTracks();
    if (!tracks || tracks.length === 0 || tracks.every((t) => t.readyState !== 'live')) {
      return {
        success: false,
        error: 'No active audio track was received from your microphone.',
        errorType: 'not_found',
      };
    }

    cachedAudioStream = stream;
    return { success: true, stream };
  } catch (err: any) {
    console.warn('Microphone permission request result:', err);
    let errorMessage = 'Microphone permission is required to participate in voice calls.';
    let errorType: MicRequestResult['errorType'] = 'unknown';
    let isDenied = false;

    if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
      isDenied = true;
      errorType = 'denied';
      errorMessage =
        'Microphone permission was denied. Please allow microphone access in your browser or device settings to start or join voice calls.';
    } else if (err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError') {
      errorType = 'not_found';
      errorMessage = 'No microphone device was detected on your system. Please plug in a microphone.';
    } else if (err.name === 'NotReadableError' || err.name === 'TrackStartError') {
      errorType = 'in_use';
      errorMessage = 'Microphone is already in use by another application or browser tab.';
    } else if (err.name === 'SecurityError') {
      isDenied = true;
      errorType = 'security';
      errorMessage = 'Security policy blocked microphone access. Please ensure permissions are enabled.';
    }

    return {
      success: false,
      error: errorMessage,
      isDenied,
      errorType,
    };
  }
}

/**
 * Returns true if an active audio stream with live tracks exists
 */
export function isMicrophoneActive(): boolean {
  return !!(
    cachedAudioStream &&
    cachedAudioStream.active &&
    cachedAudioStream.getAudioTracks().some((track) => track.readyState === 'live' && track.enabled)
  );
}

/**
 * Returns the active cached MediaStream if available
 */
export function getActiveCallMicrophone(): MediaStream | null {
  if (isMicrophoneActive()) {
    return cachedAudioStream;
  }
  return null;
}

/**
 * Stops all tracks and cleans up cached stream
 */
export function releaseCallMicrophone() {
  if (cachedAudioStream) {
    try {
      cachedAudioStream.getTracks().forEach((track) => track.stop());
    } catch {}
    cachedAudioStream = null;
  }
}
