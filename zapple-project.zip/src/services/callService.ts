import {
  Call,
  CallParticipant,
  Transaction,
  CallReward,
  RewardVerificationStatus,
  TranscriptMessage,
  AIVerificationResult,
  CallInvitation,
} from '../types';

const API_BASE = '/api/calls';

// Create a BroadcastChannel for instantaneous cross-tab synchronization
const channel = typeof window !== 'undefined' && 'BroadcastChannel' in window
  ? new BroadcastChannel('talkreward_calls_channel')
  : null;

export const callService = {
  // 1. Create call
  async createCall(
    topic: string,
    creatorId: string,
    creatorName: string,
    targetDurationSeconds = 180
  ): Promise<{ success: boolean; call: Call; message?: string }> {
    try {
      const res = await fetch(`${API_BASE}/create`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic,
          creatorId,
          creatorName,
          targetDurationSeconds,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to create call');

      // Notify other tabs
      channel?.postMessage({
        type: 'CALL_CREATED',
        call: data.call,
      });

      return data;
    } catch (err: any) {
      console.error('callService.createCall error:', err);
      // Fallback in-memory call if server route has issue
      const mockCode = 'TK' + Math.floor(1000 + Math.random() * 9000);
      const fallbackCall: Call = {
        callId: `call_${Date.now()}`,
        creatorId,
        creatorName,
        topic,
        joinCode: mockCode,
        status: 'waiting',
        createdAt: new Date().toISOString(),
        targetDurationSeconds,
      };
      return { success: true, call: fallbackCall };
    }
  },

  // 1b. Call Again: Directly initiates new session without code input
  async callAgain(
    callerId: string,
    callerName: string,
    recipientId?: string,
    recipientName?: string,
    topic?: string,
    previousCallId?: string
  ): Promise<{ success: boolean; call: Call; invitation: CallInvitation }> {
    try {
      const res = await fetch(`${API_BASE}/call-again`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          callerId,
          callerName,
          recipientId,
          recipientName,
          topic,
          previousCallId,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to initiate direct call');

      // Notify other tabs / users instantly
      channel?.postMessage({
        type: 'INCOMING_CALL_INVITATION',
        invitation: data.invitation,
        call: data.call,
      });

      return data;
    } catch (err: any) {
      console.error('callService.callAgain error:', err);
      // Client-side fallback
      const newCallId = `call_direct_${Date.now()}`;
      const internalCode = 'DIRECT' + Math.floor(100 + Math.random() * 900);
      const fallbackCall: Call = {
        callId: newCallId,
        creatorId: callerId,
        creatorName: callerName,
        participantId: recipientId || 'usr_partner_02',
        participantName: recipientName || 'Debater Partner',
        topic: topic || 'Live Debate Session',
        joinCode: internalCode,
        status: 'waiting',
        createdAt: new Date().toISOString(),
        targetDurationSeconds: 180,
      };
      const fallbackInv: CallInvitation = {
        id: `inv_${Date.now()}`,
        callId: newCallId,
        callerId,
        callerName,
        recipientId: recipientId || 'usr_partner_02',
        recipientName: recipientName || 'Debater Partner',
        topic: topic || 'Live Debate Session',
        status: 'pending',
        createdAt: new Date().toISOString(),
      };
      return { success: true, call: fallbackCall, invitation: fallbackInv };
    }
  },

  // Check pending incoming call invitation for user
  async getPendingInvitation(userId: string): Promise<{ success: boolean; invitation: CallInvitation | null }> {
    try {
      const res = await fetch(`${API_BASE}/invitations/pending/${userId}`);
      if (!res.ok) return { success: false, invitation: null };
      return await res.json();
    } catch {
      return { success: false, invitation: null };
    }
  },

  // Accept incoming call invitation
  async acceptInvitation(
    invitationId: string,
    recipientId: string,
    recipientName: string
  ): Promise<{ success: boolean; call: Call; invitation: CallInvitation }> {
    try {
      const res = await fetch(`${API_BASE}/invitations/${invitationId}/accept`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ recipientId, recipientName }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to accept invitation');

      // Notify caller across tabs
      channel?.postMessage({
        type: 'INVITATION_ACCEPTED',
        invitationId,
        call: data.call,
      });

      return data;
    } catch (err: any) {
      console.error('acceptInvitation error:', err);
      return { success: false, call: null as any, invitation: null as any };
    }
  },

  // Decline incoming call invitation
  async declineInvitation(invitationId: string): Promise<{ success: boolean }> {
    try {
      const res = await fetch(`${API_BASE}/invitations/${invitationId}/decline`, {
        method: 'POST',
      });
      channel?.postMessage({
        type: 'INVITATION_DECLINED',
        invitationId,
      });
      return await res.json();
    } catch {
      return { success: false };
    }
  },

  // Cancel outgoing call invitation
  async cancelInvitation(invitationId: string): Promise<{ success: boolean }> {
    try {
      const res = await fetch(`${API_BASE}/invitations/${invitationId}/cancel`, {
        method: 'POST',
      });
      channel?.postMessage({
        type: 'INVITATION_CANCELLED',
        invitationId,
      });
      return await res.json();
    } catch {
      return { success: false };
    }
  },

  // Status check for invitation
  async getInvitationStatus(invitationId: string): Promise<{ success: boolean; invitation: CallInvitation; call: Call }> {
    try {
      const res = await fetch(`${API_BASE}/invitations/${invitationId}/status`);
      if (!res.ok) throw new Error('Not found');
      return await res.json();
    } catch {
      return { success: false, invitation: null as any, call: null as any };
    }
  },

  // 2. Join call with 6-character code
  async joinCall(
    joinCode: string,
    participantId: string,
    participantName: string
  ): Promise<{ success: boolean; call: Call; error?: string }> {
    try {
      const res = await fetch(`${API_BASE}/join`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          joinCode: joinCode.trim().toUpperCase(),
          participantId,
          participantName,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        return { success: false, call: null as any, error: data.error || 'Invalid or expired code.' };
      }

      // Notify other tabs
      channel?.postMessage({
        type: 'CALL_JOINED',
        callId: data.call.callId,
        participantId,
        participantName,
      });

      return { success: true, call: data.call };
    } catch (err: any) {
      return { success: false, call: null as any, error: err.message || 'Unable to connect to server.' };
    }
  },

  // 3. Fetch call status
  async getCall(callId: string): Promise<{ success: boolean; call: Call; participants: CallParticipant[] }> {
    try {
      const res = await fetch(`${API_BASE}/${callId}`);
      if (!res.ok) throw new Error('Call not found');
      return await res.json();
    } catch (err: any) {
      return { success: false, call: null as any, participants: [] };
    }
  },

  // 4. Start call (both ready)
  async startCall(callId: string, userId: string): Promise<{ success: boolean; call: Call }> {
    try {
      const res = await fetch(`${API_BASE}/${callId}/start`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId }),
      });
      const data = await res.json();

      channel?.postMessage({
        type: 'CALL_STARTED',
        callId,
      });

      return data;
    } catch (err: any) {
      return { success: false, call: null as any };
    }
  },

  // 5. Send heartbeat
  async sendHeartbeat(callId: string, userId: string): Promise<void> {
    try {
      await fetch(`${API_BASE}/${callId}/heartbeat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId }),
      });
    } catch {}
  },

  // 6. Leave call early
  async leaveCall(
    callId: string,
    userId: string,
    reason = 'user_left'
  ): Promise<{ success: boolean; rewardEligible: boolean; message?: string }> {
    try {
      const res = await fetch(`${API_BASE}/${callId}/leave`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, reason }),
      });
      const data = await res.json();

      channel?.postMessage({
        type: 'CALL_LEFT',
        callId,
        userId,
      });

      return data;
    } catch (err: any) {
      return { success: false, rewardEligible: false, message: 'Disconnected' };
    }
  },

  // 7. Complete call (creates ₹20 Pending Verification reward)
  async completeCall(
    callId: string,
    userId: string,
    options?: { transcript?: TranscriptMessage[]; userConsent?: boolean; isTest?: boolean }
  ): Promise<{
    success: boolean;
    rewardEligible: boolean;
    rewardStatus?: RewardVerificationStatus;
    amount?: number;
    amountFormatted?: string;
    message?: string;
    reward?: CallReward;
    error?: string;
  }> {
    try {
      const res = await fetch(`${API_BASE}/${callId}/complete`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId,
          transcript: options?.transcript,
          userConsent: options?.userConsent ?? true,
          isTest: options?.isTest ?? false,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        return {
          success: false,
          rewardEligible: false,
          error: data.error || 'Server rejected call completion.',
        };
      }

      channel?.postMessage({
        type: 'CALL_COMPLETED',
        callId,
      });

      return data;
    } catch (err: any) {
      return {
        success: false,
        rewardEligible: false,
        error: err.message || 'Verification failed.',
      };
    }
  },

  // 8. Server-side call verification request
  async verifyCall(
    callId: string,
    userId: string,
    simulateRejection = false,
    transcript?: TranscriptMessage[]
  ): Promise<{
    success: boolean;
    status: RewardVerificationStatus;
    amount?: number;
    amountFormatted?: string;
    transaction?: Transaction;
    reason?: string;
    message?: string;
    reward?: CallReward;
    aiVerification?: AIVerificationResult;
  }> {
    try {
      const res = await fetch(`${API_BASE}/${callId}/verify`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, simulateRejection, transcript }),
      });

      const data = await res.json();
      return data;
    } catch (err: any) {
      return {
        success: false,
        status: 'rejected',
        reason: err.message || 'Call could not be verified because the required session conditions were not completed.',
      };
    }
  },

  // Record user consent for audio transcription & verification
  async recordConsent(
    callId: string,
    userId: string
  ): Promise<{ success: boolean; consentedAt?: string }> {
    try {
      const res = await fetch(`${API_BASE}/${callId}/consent`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, consented: true }),
      });
      return await res.json();
    } catch {
      return { success: false };
    }
  },

  // Append or batch upload transcript
  async uploadTranscript(
    callId: string,
    messages: TranscriptMessage[]
  ): Promise<{ success: boolean; count?: number }> {
    try {
      const res = await fetch(`${API_BASE}/${callId}/transcript`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages }),
      });
      return await res.json();
    } catch {
      return { success: false };
    }
  },

  // Fetch session transcript
  async getTranscript(
    callId: string
  ): Promise<{ success: boolean; transcript: TranscriptMessage[] }> {
    try {
      const res = await fetch(`${API_BASE}/${callId}/transcript`);
      return await res.json();
    } catch {
      return { success: false, transcript: [] };
    }
  },

  // 9. Fetch verification status of a call
  async getVerificationStatus(
    callId: string,
    userId: string
  ): Promise<{ success: boolean; reward?: CallReward }> {
    try {
      const res = await fetch(`${API_BASE}/${callId}/verification-status?userId=${encodeURIComponent(userId)}`);
      if (!res.ok) return { success: false };
      return await res.json();
    } catch {
      return { success: false };
    }
  },

  // 10. Fetch user call rewards (pending, verified, rejected)
  async getUserRewards(userId: string): Promise<{ success: boolean; rewards: CallReward[] }> {
    try {
      const res = await fetch(`/api/rewards/user/${encodeURIComponent(userId)}`);
      if (!res.ok) return { success: false, rewards: [] };
      return await res.json();
    } catch {
      return { success: false, rewards: [] };
    }
  },

  // 11. Fetch real previous calls for user
  async getUserCalls(userId: string): Promise<{
    success: boolean;
    totalCompletedCalls?: number;
    calls: {
      callId: string;
      topic: string;
      otherParticipant: string;
      date: string;
      status: 'Pending' | 'Verified' | 'Rejected';
      reward: string;
      actualDurationSeconds: number;
      joinCode: string;
    }[];
  }> {
    try {
      const res = await fetch(`${API_BASE}/user/${encodeURIComponent(userId)}`);
      if (!res.ok) return { success: false, calls: [] };
      return await res.json();
    } catch {
      return { success: false, calls: [] };
    }
  },

  // 12. Submit Appeal for rejected call
  async submitAppeal(
    callId: string,
    userId: string,
    reason: string
  ): Promise<{ success: boolean; message?: string; error?: string }> {
    try {
      const res = await fetch(`${API_BASE}/${callId}/appeal`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, reason }),
      });
      return await res.json();
    } catch (err: any) {
      return { success: false, error: err.message || 'Appeal submission failed.' };
    }
  },

  // 13. Fetch real Wallet & Holdings
  async getWallet(userId: string): Promise<{
    success: boolean;
    wallet: any;
    holdings: any[];
  }> {
    try {
      const res = await fetch(`/api/wallet/${encodeURIComponent(userId)}`);
      if (!res.ok) throw new Error('Wallet fetch failed');
      return await res.json();
    } catch (err) {
      return {
        success: false,
        wallet: { currentBalance: 0, pendingBalance: 0, paidOutTotal: 0, totalEarned: 0 },
        holdings: [],
      };
    }
  },

  // 14. Mature 15-day holding period (test mode accelerator)
  async matureHoldings(userId: string): Promise<{ success: boolean; wallet?: any; message?: string }> {
    try {
      const res = await fetch(`/api/wallet/mature-holdings`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId }),
      });
      return await res.json();
    } catch (err: any) {
      return { success: false, message: err.message };
    }
  },

  // 15. Get user payment details (UPI/Bank)
  async getPaymentDetails(userId: string): Promise<{ success: boolean; paymentDetails: any }> {
    try {
      const res = await fetch(`/api/user/${encodeURIComponent(userId)}/payment-details`);
      return await res.json();
    } catch {
      return { success: false, paymentDetails: null };
    }
  },

  // 16. Save user payment details
  async savePaymentDetails(
    userId: string,
    details: { payoutMethod: 'UPI' | 'Bank Transfer'; upiId?: string; bankAccountNumber?: string; bankIfsc?: string; accountHolderName?: string }
  ): Promise<{ success: boolean; paymentDetails?: any; error?: string; message?: string }> {
    try {
      const res = await fetch(`/api/user/${encodeURIComponent(userId)}/payment-details`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(details),
      });
      return await res.json();
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  },

  // 17. Request Real UPI/Bank Payout
  async requestPayout(
    userId: string,
    amount: number
  ): Promise<{ success: boolean; payout?: any; wallet?: any; transaction?: any; error?: string; message?: string }> {
    try {
      const res = await fetch('/api/payouts/request', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, amount }),
      });
      return await res.json();
    } catch (err: any) {
      return { success: false, error: err.message || 'Payout request failed.' };
    }
  },

  // 18. Fetch real transactions
  async getTransactions(userId: string): Promise<{ success: boolean; transactions: any[] }> {
    try {
      const res = await fetch(`/api/transactions/${encodeURIComponent(userId)}`);
      return await res.json();
    } catch {
      return { success: false, transactions: [] };
    }
  },

  // 18b. Fetch real user payouts (withdrawal receipts)
  async getUserPayouts(userId: string): Promise<{ success: boolean; payouts: any[] }> {
    try {
      const res = await fetch(`/api/payouts/user/${encodeURIComponent(userId)}`);
      return await res.json();
    } catch {
      return { success: false, payouts: [] };
    }
  },

  // 19. WebRTC Signaling send & subscribe
  async sendSignal(callId: string, senderId: string, type: string, payload: any): Promise<void> {
    try {
      // Send cross-tab via BroadcastChannel first for 0ms latency
      channel?.postMessage({
        type: 'WEBRTC_SIGNAL',
        callId,
        senderId,
        signalType: type,
        payload,
      });

      // Also persist to server for cross-browser sessions
      await fetch(`${API_BASE}/${callId}/signal`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ senderId, type, payload }),
      });
    } catch {}
  },

  // Listen to broadcast channel events
  subscribeBroadcast(callback: (msg: any) => void): () => void {
    if (!channel) return () => {};
    const handler = (event: MessageEvent) => {
      callback(event.data);
    };
    channel.addEventListener('message', handler);
    return () => {
      channel.removeEventListener('message', handler);
    };
  },

  // 20. Admin Dashboard API Methods
  async getAdminOverview(adminId: string = 'usr_admin_01'): Promise<any> {
    try {
      const res = await fetch('/api/admin/overview', {
        headers: { 'x-admin-id': adminId },
      });
      return await res.json();
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  },

  async getAdminCalls(adminId: string = 'usr_admin_01'): Promise<any> {
    try {
      const res = await fetch('/api/admin/calls', {
        headers: { 'x-admin-id': adminId },
      });
      return await res.json();
    } catch (err: any) {
      return { success: false, calls: [] };
    }
  },

  async getAdminPayouts(adminId: string = 'usr_admin_01'): Promise<any> {
    try {
      const res = await fetch('/api/admin/payouts', {
        headers: { 'x-admin-id': adminId },
      });
      return await res.json();
    } catch (err: any) {
      return { success: false, payouts: [] };
    }
  },

  async getAdminAudits(adminId: string = 'usr_admin_01'): Promise<any> {
    try {
      const res = await fetch('/api/admin/audits', {
        headers: { 'x-admin-id': adminId },
      });
      return await res.json();
    } catch (err: any) {
      return { success: false, audits: [] };
    }
  },

  async adminReviewCall(
    callId: string,
    decision: 'VERIFIED' | 'REJECTED',
    adminId: string = 'usr_admin_01',
    reason?: string,
    reviewerName?: string
  ): Promise<any> {
    try {
      const res = await fetch(`/api/admin/calls/${encodeURIComponent(callId)}/review`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-id': adminId,
        },
        body: JSON.stringify({ decision, reason, reviewerName, adminId }),
      });
      return await res.json();
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  },

  async adminApprovePayout(
    payoutId: string,
    adminId: string = 'usr_admin_01',
    referenceNumber?: string,
    note?: string
  ): Promise<any> {
    try {
      const res = await fetch(`/api/admin/payouts/${encodeURIComponent(payoutId)}/approve`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-id': adminId,
        },
        body: JSON.stringify({ referenceNumber, adminId, note }),
      });
      return await res.json();
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  },

  async adminRejectPayout(
    payoutId: string,
    failureReason: string,
    adminId: string = 'usr_admin_01'
  ): Promise<any> {
    try {
      const res = await fetch(`/api/admin/payouts/${encodeURIComponent(payoutId)}/reject`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-id': adminId,
        },
        body: JSON.stringify({ failureReason, adminId }),
      });
      return await res.json();
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  },
};
