import { DailyPool, PrizePoolState, PrizePoolLedgerTransaction } from '../types';

const getStoredAuthUser = (): { id: string; email: string } => {
  try {
    const raw = localStorage.getItem('talkreward_user_prod');
    if (raw) {
      const parsed = JSON.parse(raw);
      return {
        id: parsed.id || parsed.email || '',
        email: parsed.email || '',
      };
    }
  } catch {}
  return { id: '', email: '' };
};

const getStoredAuthId = (): string => {
  return getStoredAuthUser().id;
};

const getAdminHeaders = (adminId?: string) => {
  const stored = getStoredAuthUser();
  const effectiveId = adminId || stored.id || 'usr_admin_ff280270';
  const effectiveEmail = stored.email || 'ff280270@gmail.com';
  return {
    'x-admin-id': effectiveId,
    'x-admin-email': effectiveEmail,
    'Authorization': `Bearer ${effectiveId}`,
    'Accept': 'application/json',
  };
};

async function safeFetchJson<T>(res: Response, fallbackError = 'Request failed'): Promise<T> {
  const contentType = res.headers.get('content-type') || '';
  if (contentType.includes('application/json')) {
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || data.message || fallbackError);
    }
    return data;
  }

  if (!res.ok) {
    throw new Error(`${fallbackError} (Status: ${res.status})`);
  }

  try {
    return await res.json();
  } catch {
    throw new Error(fallbackError);
  }
}

export const poolService = {
  // Fetch current backend daily pool status (safe for all users)
  async getDailyPool(): Promise<{ success: boolean; pool: DailyPool }> {
    try {
      const res = await fetch('/api/pool', {
        headers: { Accept: 'application/json' },
      });
      if (!res.ok) throw new Error('Failed to fetch daily pool');
      return await safeFetchJson(res, 'Failed to fetch daily pool');
    } catch (err) {
      console.warn('poolService.getDailyPool warning (using safe fallback):', err);
      return {
        success: true,
        pool: {
          totalPoolAmount: 30000,
          allocatedAmount: 180,
          remainingAmount: 29820,
          resetTimeUTC: '00:00:00 UTC',
          nextResetAt: new Date(Date.now() + 8 * 3600 * 1000).toISOString(),
          isExhausted: false,
          lastResetAt: new Date().toISOString(),
          todayApprovedRewardsCount: 9,
        },
      };
    }
  },

  // Admin: Get Master Prize Pool State & recent transactions
  async getAdminPrizePool(adminId?: string): Promise<{
    success: boolean;
    prizePool?: PrizePoolState;
    dailyPool?: DailyPool;
    transactions?: PrizePoolLedgerTransaction[];
    error?: string;
  }> {
    try {
      const res = await fetch('/api/admin/prize-pool', {
        headers: getAdminHeaders(adminId),
      });
      return await safeFetchJson(res, 'Failed to fetch prize pool');
    } catch (err: any) {
      console.error('[poolService.getAdminPrizePool Error]:', err?.message || err);
      return {
        success: false,
        error: err?.message || 'Failed to fetch prize pool state',
      };
    }
  },

  // Admin: Add Funds to Master Prize Pool
  async addFunds(
    amount: number,
    note?: string,
    adminId?: string
  ): Promise<{
    success: boolean;
    prizePool?: PrizePoolState;
    dailyPool?: DailyPool;
    transaction?: PrizePoolLedgerTransaction;
    message?: string;
    error?: string;
  }> {
    try {
      const stored = getStoredAuthUser();
      const effectiveId = adminId || stored.id || 'usr_admin_ff280270';
      const effectiveEmail = stored.email || 'ff280270@gmail.com';

      const res = await fetch('/api/admin/prize-pool/add-funds', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...getAdminHeaders(effectiveId),
        },
        body: JSON.stringify({
          amount,
          note,
          adminId: effectiveId,
          adminEmail: effectiveEmail,
        }),
      });
      return await safeFetchJson(res, 'Unable to add Prize Pool funds. Please try again.');
    } catch (err: any) {
      console.error('[poolService.addFunds Technical Error]:', err?.message || err);
      return {
        success: false,
        error: err?.message || 'Unable to add Prize Pool funds. Please try again.',
      };
    }
  },

  // Admin: Configure Daily Pool Limit
  async setDailyLimit(
    dailyLimit: number,
    note?: string,
    adminId?: string
  ): Promise<{
    success: boolean;
    prizePool?: PrizePoolState;
    transaction?: PrizePoolLedgerTransaction;
    message?: string;
    error?: string;
  }> {
    try {
      const effectiveId = adminId || getStoredAuthId() || 'usr_admin_ff280270';
      const res = await fetch('/api/admin/prize-pool/set-limit', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...getAdminHeaders(adminId),
        },
        body: JSON.stringify({ dailyLimit, note, adminId: effectiveId }),
      });
      return await safeFetchJson(res, 'Failed to set daily limit');
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to configure daily limit' };
    }
  },

  // Admin: Reset Daily Pool
  async resetPrizePool(
    note?: string,
    adminId?: string
  ): Promise<{
    success: boolean;
    prizePool?: PrizePoolState;
    transaction?: PrizePoolLedgerTransaction;
    message?: string;
    error?: string;
  }> {
    try {
      const effectiveId = adminId || getStoredAuthId() || 'usr_admin_ff280270';
      const res = await fetch('/api/admin/prize-pool/reset', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...getAdminHeaders(adminId),
        },
        body: JSON.stringify({ adminId: effectiveId, note }),
      });
      return await safeFetchJson(res, 'Failed to reset pool');
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to reset pool' };
    }
  },

  // Admin: Disburse Queued Rewards for calls waiting for pool funds
  async disburseQueuedRewards(adminId?: string): Promise<{
    success: boolean;
    disbursedCount: number;
    prizePool?: PrizePoolState;
    message?: string;
  }> {
    try {
      const effectiveId = adminId || getStoredAuthId() || 'usr_admin_ff280270';
      const res = await fetch('/api/admin/prize-pool/disburse-queued', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...getAdminHeaders(adminId),
        },
        body: JSON.stringify({ adminId: effectiveId }),
      });
      return await safeFetchJson(res, 'Failed to disburse queued rewards');
    } catch (err: any) {
      console.warn('poolService.disburseQueuedRewards warning:', err?.message || err);
      return { success: false, disbursedCount: 0, message: err.message || 'Failed to disburse queued rewards' };
    }
  },

  // Admin: Fetch Filtered Prize Pool Transactions
  async getPrizePoolTransactions(
    type?: string,
    adminId?: string
  ): Promise<{
    success: boolean;
    transactions: PrizePoolLedgerTransaction[];
    count: number;
  }> {
    try {
      const url =
        type && type !== 'ALL'
          ? `/api/admin/prize-pool/transactions?type=${encodeURIComponent(type)}`
          : '/api/admin/prize-pool/transactions';
      const res = await fetch(url, {
        headers: getAdminHeaders(adminId),
      });
      return await safeFetchJson(res, 'Failed to fetch transactions');
    } catch (err: any) {
      console.warn('poolService.getPrizePoolTransactions warning:', err?.message || err);
      return { success: false, transactions: [], count: 0 };
    }
  },

  // Admin: Get complete dashboard overview
  async getAdminOverview(adminId?: string): Promise<{
    success: boolean;
    pool?: DailyPool;
    prizePool?: PrizePoolState;
    prizePoolTransactions?: PrizePoolLedgerTransaction[];
    users?: any[];
    calls?: any[];
    rewards?: any[];
    audits?: any[];
    payouts?: any[];
    transactions?: any[];
    tickets?: any[];
    ledger?: any;
    error?: string;
  }> {
    try {
      const res = await fetch('/api/admin/overview', {
        headers: getAdminHeaders(adminId),
      });
      return await safeFetchJson(res, 'Failed to fetch admin overview');
    } catch (err: any) {
      console.warn('poolService.getAdminOverview:', err?.message || err);
      return {
        success: false,
        error: err?.message || 'Failed to fetch admin overview',
      };
    }
  },

  // Admin: Update Payout status
  async updatePayoutStatus(
    payoutId: string,
    status: string,
    referenceNumber?: string,
    failureReason?: string,
    adminId?: string
  ): Promise<{ success: boolean; message?: string }> {
    try {
      const effectiveId = adminId || getStoredAuthId() || 'usr_admin_ff280270';
      const res = await fetch(`/api/admin/payouts/${payoutId}/status`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...getAdminHeaders(adminId),
        },
        body: JSON.stringify({ status, referenceNumber, failureReason, adminId: effectiveId }),
      });
      return await safeFetchJson(res, 'Failed to update payout');
    } catch (err: any) {
      return { success: false, message: err.message || 'Failed to update payout' };
    }
  },

  // Admin: Review Call session
  async reviewCall(
    callId: string,
    decision: 'VERIFIED' | 'REJECTED',
    reason?: string,
    reviewerName?: string,
    adminId?: string
  ): Promise<{ success: boolean; message?: string }> {
    try {
      const effectiveId = adminId || getStoredAuthId() || 'usr_admin_ff280270';
      const res = await fetch(`/api/admin/calls/${callId}/review`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...getAdminHeaders(adminId),
        },
        body: JSON.stringify({ decision, reason, reviewerName, adminId: effectiveId }),
      });
      const data = await safeFetchJson<{ success: boolean; message?: string }>(res, 'Failed to review call');
      if (data.success && typeof window !== 'undefined' && 'BroadcastChannel' in window) {
        try {
          const ch = new BroadcastChannel('zapple_channel');
          ch.postMessage({ type: 'CALL_REVIEWED', callId, decision });
          ch.close();
        } catch {}
      }
      return data;
    } catch (err: any) {
      return { success: false, message: err.message || 'Failed to review call' };
    }
  },

  // Helper alias for backward compatibility
  async updatePoolConfig(totalPoolAmount: number, resetTimeUTC?: string, adminId?: string) {
    const res = await this.setDailyLimit(totalPoolAmount, `Config updated to ${totalPoolAmount}`, adminId);
    return {
      success: res.success,
      pool: res.prizePool
        ? {
            totalPoolAmount: res.prizePool.dailyLimit,
            allocatedAmount: res.prizePool.dailyAllocated,
            remainingAmount: res.prizePool.dailyRemaining,
            resetTimeUTC: resetTimeUTC || '00:00:00 UTC',
            nextResetAt: res.prizePool.nextResetAt,
            isExhausted: res.prizePool.isDailyExhausted,
            lastResetAt: res.prizePool.lastResetAt,
            todayApprovedRewardsCount: res.prizePool.todayApprovedRewardsCount,
          }
        : undefined,
      message: res.message || res.error,
    };
  },

  // Helper alias for reset
  async resetPoolNow(adminId?: string) {
    const res = await this.resetPrizePool('Manual Admin Reset', adminId);
    return {
      success: res.success,
      pool: res.prizePool
        ? {
            totalPoolAmount: res.prizePool.dailyLimit,
            allocatedAmount: res.prizePool.dailyAllocated,
            remainingAmount: res.prizePool.dailyRemaining,
            resetTimeUTC: '00:00:00 UTC',
            nextResetAt: res.prizePool.nextResetAt,
            isExhausted: res.prizePool.isDailyExhausted,
            lastResetAt: res.prizePool.lastResetAt,
            todayApprovedRewardsCount: res.prizePool.todayApprovedRewardsCount,
          }
        : undefined,
      message: res.message || res.error,
    };
  },

  // Admin: Get all users with full detail
  async getUsers(adminId?: string, query?: string, status?: string): Promise<{
    success: boolean;
    users?: any[];
    totalCount?: number;
    error?: string;
  }> {
    try {
      const params = new URLSearchParams();
      if (query) params.set('query', query);
      if (status && status !== 'all') params.set('status', status);
      const url = `/api/admin/users${params.toString() ? `?${params.toString()}` : ''}`;
      const res = await fetch(url, {
        headers: getAdminHeaders(adminId),
      });
      return await safeFetchJson(res, 'Failed to fetch users');
    } catch (err: any) {
      console.error('[poolService.getUsers Error]:', err?.message || err);
      return { success: false, error: err?.message || 'Failed to fetch users' };
    }
  },

  // Admin: Ban User
  async banUser(
    userId: string,
    reason?: string,
    adminId?: string
  ): Promise<{ success: boolean; user?: any; message?: string; error?: string }> {
    try {
      const effectiveId = adminId || getStoredAuthId() || 'usr_admin_ff280270';
      const res = await fetch(`/api/admin/users/${userId}/ban`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...getAdminHeaders(adminId),
        },
        body: JSON.stringify({ reason, adminId: effectiveId }),
      });
      const data = await safeFetchJson<{ success: boolean; user?: any; message?: string; error?: string }>(
        res,
        'Failed to ban user'
      );
      if (data.success && typeof window !== 'undefined' && 'BroadcastChannel' in window) {
        try {
          const ch = new BroadcastChannel('zapple_channel');
          ch.postMessage({ type: 'USER_BANNED', userId, reason });
          ch.close();
        } catch {}
      }
      return data;
    } catch (err: any) {
      return { success: false, error: err?.message || 'Failed to ban user' };
    }
  },

  // Admin: Unban User
  async unbanUser(
    userId: string,
    adminId?: string
  ): Promise<{ success: boolean; user?: any; message?: string; error?: string }> {
    try {
      const effectiveId = adminId || getStoredAuthId() || 'usr_admin_ff280270';
      const res = await fetch(`/api/admin/users/${userId}/unban`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...getAdminHeaders(adminId),
        },
        body: JSON.stringify({ adminId: effectiveId }),
      });
      const data = await safeFetchJson<{ success: boolean; user?: any; message?: string; error?: string }>(
        res,
        'Failed to unban user'
      );
      if (data.success && typeof window !== 'undefined' && 'BroadcastChannel' in window) {
        try {
          const ch = new BroadcastChannel('zapple_channel');
          ch.postMessage({ type: 'USER_UNBANNED', userId });
          ch.close();
        } catch {}
      }
      return data;
    } catch (err: any) {
      return { success: false, error: err?.message || 'Failed to unban user' };
    }
  },
};
