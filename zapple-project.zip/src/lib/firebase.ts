import { initializeApp, getApps, getApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';
import { getAuth, GoogleAuthProvider } from 'firebase/auth';
import firebaseConfigJson from '../../firebase-applet-config.json';

const firebaseConfig = {
  apiKey: firebaseConfigJson.apiKey,
  authDomain: firebaseConfigJson.authDomain,
  projectId: firebaseConfigJson.projectId,
  storageBucket: firebaseConfigJson.storageBucket,
  messagingSenderId: firebaseConfigJson.messagingSenderId,
  appId: firebaseConfigJson.appId,
};

// Initialize Firebase App
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
const db = getFirestore(app, firebaseConfigJson.firestoreDatabaseId);
const auth = getAuth(app);
const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: 'select_account' });

/**
 * Checks whether the Email/Password sign-in provider is actually enabled
 * in the connected Firebase project.
 */
export async function checkEmailPasswordProviderEnabled(): Promise<boolean> {
  try {
    const res = await fetch(
      `https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${firebaseConfig.apiKey}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: 'provider-check@example.com',
          password: 'ProbePassword123!',
          returnSecureToken: false,
        }),
      }
    );
    const data = await res.json();
    const msg = data?.error?.message;
    if (msg === 'PASSWORD_LOGIN_DISABLED' || msg === 'OPERATION_NOT_ALLOWED') {
      return false;
    }
    return true;
  } catch (err) {
    console.warn('Could not verify Firebase Email/Password provider status:', err);
    return false;
  }
}

export { app, db, auth, googleProvider, firebaseConfig };

