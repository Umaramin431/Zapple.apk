import { useState, useEffect, useRef, useCallback } from 'react';
import { callService } from '../services/callService';
import {
  requestCallMicrophone,
  getActiveCallMicrophone,
  releaseCallMicrophone,
} from '../utils/microphone';

interface UseWebRTCCallProps {
  callId: string;
  userId: string;
  isCreator: boolean;
  onRemoteJoined?: () => void;
  onCallEnded?: () => void;
}

export function useWebRTCCall({
  callId,
  userId,
  isCreator,
  onRemoteJoined,
  onCallEnded,
}: UseWebRTCCallProps) {
  const [micGranted, setMicGranted] = useState<boolean>(false);
  const [micError, setMicError] = useState<string | null>(null);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [isSpeakerOn, setIsSpeakerOn] = useState<boolean>(true);
  const [localVolume, setLocalVolume] = useState<number>(0);
  const [remoteVolume, setRemoteVolume] = useState<number>(0);
  const [isConnected, setIsConnected] = useState<boolean>(false);

  const rawLocalStreamRef = useRef<MediaStream | null>(null);
  const processedStreamRef = useRef<MediaStream | null>(null);
  const peerConnectionRef = useRef<RTCPeerConnection | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const animationFrameRef = useRef<number | null>(null);
  const remoteAudioRef = useRef<HTMLAudioElement | null>(null);
  const remoteAnalyserRef = useRef<AnalyserNode | null>(null);

  // Silence all device UI sound, synthetic speech, or assistant loops
  const silenceSystemAndAssistantSounds = () => {
    // 1. Cancel speech synthesis immediately if invoked by system or voice assistant
    if (typeof window !== 'undefined' && 'speechSynthesis' in window && window.speechSynthesis) {
      try {
        window.speechSynthesis.cancel();
        window.speechSynthesis.pause();
      } catch {}
    }

    // 2. Pause and mute any stray audio/video elements in document (except remote WebRTC sink)
    if (typeof document !== 'undefined') {
      document.querySelectorAll('audio, video').forEach((el) => {
        if (el.id !== 'webrtc-remote-audio-sink') {
          try {
            const media = el as HTMLMediaElement;
            media.muted = true;
            media.pause();
          } catch {}
        }
      });
    }
  };

  // 1. Request microphone permission with strict participant voice isolation
  const requestMicrophone = useCallback(async (): Promise<boolean> => {
    try {
      setMicError(null);

      // If microphone stream is already active and healthy, reuse without re-requesting
      const existing = getActiveCallMicrophone();
      let rawStream: MediaStream;

      if (
        existing &&
        existing.active &&
        existing.getAudioTracks().some((t) => t.readyState === 'live')
      ) {
        rawStream = existing;
      } else {
        const micResult = await requestCallMicrophone();
        if (!micResult.success || !micResult.stream) {
          throw new Error(micResult.error || 'Microphone access is required for voice calls.');
        }
        rawStream = micResult.stream;
      }

      silenceSystemAndAssistantSounds();

      rawLocalStreamRef.current = rawStream;

      // Build dedicated Web Audio API vocal bandpass filter chain (85 Hz - 3400 Hz)
      // This mathematically eliminates out-of-band Android notification chimes,
      // assistant earcon beeps, and low-frequency rumble before transmission.
      let transmitStream = rawStream;
      try {
        const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
        if (AudioCtx) {
          const audioCtx = new AudioCtx({ latencyHint: 'interactive' });
          audioContextRef.current = audioCtx;

          if (audioCtx.state === 'suspended') {
            await audioCtx.resume().catch(() => {});
          }

          const source = audioCtx.createMediaStreamSource(rawStream);

          // Highpass filter: removes motor hum, low rumble, and vibration below 85 Hz
          const highpass = audioCtx.createBiquadFilter();
          highpass.type = 'highpass';
          highpass.frequency.setValueAtTime(85, audioCtx.currentTime);
          highpass.Q.setValueAtTime(0.707, audioCtx.currentTime);

          // Lowpass filter: cuts high-pitched notification chimes and earcons above 3400 Hz
          const lowpass = audioCtx.createBiquadFilter();
          lowpass.type = 'lowpass';
          lowpass.frequency.setValueAtTime(3400, audioCtx.currentTime);
          lowpass.Q.setValueAtTime(0.707, audioCtx.currentTime);

          // Dynamics Compressor: protects against abrupt volume spikes and prevents howling feedback
          const compressor = audioCtx.createDynamicsCompressor();
          compressor.threshold.setValueAtTime(-24, audioCtx.currentTime);
          compressor.knee.setValueAtTime(30, audioCtx.currentTime);
          compressor.ratio.setValueAtTime(12, audioCtx.currentTime);
          compressor.attack.setValueAtTime(0.003, audioCtx.currentTime);
          compressor.release.setValueAtTime(0.25, audioCtx.currentTime);

          // Visual Analyzer: analyzes clean voice volume for UI ripple and VAD
          const analyser = audioCtx.createAnalyser();
          analyser.fftSize = 256;
          analyserRef.current = analyser;

          // Dedicated destination for WebRTC transmission
          const destination = audioCtx.createMediaStreamDestination();

          // Connect DSP Pipeline:
          // source -> highpass -> lowpass -> compressor -> analyser -> destination
          source.connect(highpass);
          highpass.connect(lowpass);
          lowpass.connect(compressor);
          compressor.connect(analyser);
          compressor.connect(destination);

          // Never connect source or destination to audioCtx.destination to prevent local audio loopback!
          transmitStream = destination.stream;
          processedStreamRef.current = destination.stream;

          // Monitor local vocal levels
          const dataArray = new Uint8Array(analyser.frequencyBinCount);
          const updateVolume = () => {
            if (analyserRef.current) {
              analyserRef.current.getByteFrequencyData(dataArray);
              let sum = 0;
              for (let i = 0; i < dataArray.length; i++) sum += dataArray[i];
              const avg = sum / dataArray.length;
              setLocalVolume(Math.min(100, Math.round((avg / 128) * 100)));
            }
            animationFrameRef.current = requestAnimationFrame(updateVolume);
          };
          updateVolume();
        }
      } catch (e) {
        console.warn('AudioContext DSP fallback to direct stream', e);
        transmitStream = rawStream;
      }

      setMicGranted(true);
      return true;
    } catch (err: any) {
      console.error('Microphone permission error:', err);
      let errorMsg = 'Microphone permission is required to join the voice call.';
      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        errorMsg = 'Microphone permission was denied. Please allow microphone access in your browser settings to join the voice call.';
      } else if (err.name === 'NotFoundError') {
        errorMsg = 'No microphone device was detected on your system.';
      }
      setMicError(errorMsg);
      setMicGranted(false);
      return false;
    }
  }, []);

  // 2. Setup WebRTC PeerConnection
  const initWebRTC = useCallback(() => {
    try {
      silenceSystemAndAssistantSounds();

      const pc = new RTCPeerConnection({
        iceServers: [
          { urls: 'stun:stun.l.google.com:19302' },
          { urls: 'stun:stun1.l.google.com:19302' },
        ],
      });

      peerConnectionRef.current = pc;

      // Add processed vocal stream track to PC
      const streamToSend = processedStreamRef.current || rawLocalStreamRef.current;
      if (streamToSend) {
        streamToSend.getAudioTracks().forEach((track) => {
          pc.addTrack(track, streamToSend);
        });
      }

      // Handle ICE candidates
      pc.onicecandidate = (event) => {
        if (event.candidate) {
          callService.sendSignal(callId, userId, 'CANDIDATE', event.candidate);
        }
      };

      // Handle connection state changes
      pc.onconnectionstatechange = () => {
        if (pc.connectionState === 'connected') {
          setIsConnected(true);
        } else if (pc.connectionState === 'disconnected' || pc.connectionState === 'failed') {
          setIsConnected(false);
        }
      };

      // Handle incoming remote participant audio
      pc.ontrack = (event) => {
        const remoteStream = event.streams[0];
        if (!remoteStream) return;

        if (!remoteAudioRef.current) {
          const audio = document.createElement('audio');
          audio.id = 'webrtc-remote-audio-sink';
          audio.autoplay = true;
          audio.setAttribute('playsinline', 'true');
          (audio as any).playsInline = true;
          // Positioned out of viewport but attached to DOM so Android routes to voice communication audio track
          audio.style.position = 'fixed';
          audio.style.pointerEvents = 'none';
          audio.style.opacity = '0';
          audio.style.width = '1px';
          audio.style.height = '1px';
          audio.style.top = '-100px';
          audio.srcObject = remoteStream;
          audio.muted = !isSpeakerOn;
          document.body.appendChild(audio);
          remoteAudioRef.current = audio;

          audio.play().catch((err) => {
            console.warn('Remote audio waiting for interaction:', err);
          });
        } else {
          remoteAudioRef.current.srcObject = remoteStream;
          remoteAudioRef.current.muted = !isSpeakerOn;
          remoteAudioRef.current.play().catch(() => {});
        }

        // Setup remote volume analyzer for remote partner audio activity
        try {
          const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
          if (AudioCtx && !remoteAnalyserRef.current) {
            const remoteCtx = new AudioCtx({ latencyHint: 'playback' });
            const remoteSource = remoteCtx.createMediaStreamSource(remoteStream);
            const remoteAnalyser = remoteCtx.createAnalyser();
            remoteAnalyser.fftSize = 256;
            remoteSource.connect(remoteAnalyser);
            remoteAnalyserRef.current = remoteAnalyser;

            const remData = new Uint8Array(remoteAnalyser.frequencyBinCount);
            const checkRemote = () => {
              if (remoteAnalyserRef.current) {
                remoteAnalyserRef.current.getByteFrequencyData(remData);
                let sum = 0;
                for (let i = 0; i < remData.length; i++) sum += remData[i];
                setRemoteVolume(Math.min(100, Math.round(((sum / remData.length) / 128) * 100)));
              }
            };
            const interval = setInterval(checkRemote, 150);
            return () => clearInterval(interval);
          }
        } catch {}

        setIsConnected(true);
      };

      return pc;
    } catch (err) {
      console.warn('WebRTC peer connection setup error:', err);
      return null;
    }
  }, [callId, userId, isSpeakerOn]);

  // 3. Listen to Signaling messages
  useEffect(() => {
    const unsubscribe = callService.subscribeBroadcast(async (msg) => {
      if (msg.callId !== callId) return;

      if (msg.type === 'CALL_JOINED') {
        onRemoteJoined?.();
      }

      if (msg.type === 'CALL_LEFT' || msg.type === 'CALL_COMPLETED') {
        onCallEnded?.();
      }

      if (msg.type === 'WEBRTC_SIGNAL' && msg.senderId !== userId) {
        let pc = peerConnectionRef.current;
        if (!pc) {
          pc = initWebRTC();
        }
        if (!pc) return;

        try {
          if (msg.signalType === 'OFFER') {
            await pc.setRemoteDescription(new RTCSessionDescription(msg.payload));
            const answer = await pc.createAnswer();
            await pc.setLocalDescription(answer);
            callService.sendSignal(callId, userId, 'ANSWER', answer);
            setIsConnected(true);
          } else if (msg.signalType === 'ANSWER') {
            await pc.setRemoteDescription(new RTCSessionDescription(msg.payload));
            setIsConnected(true);
          } else if (msg.signalType === 'CANDIDATE') {
            await pc.addIceCandidate(new RTCIceCandidate(msg.payload));
          }
        } catch (e) {
          console.warn('Signaling handle error:', e);
        }
      }
    });

    return () => {
      unsubscribe();
    };
  }, [callId, userId, onRemoteJoined, onCallEnded, initWebRTC]);

  // 4. If creator, start offer negotiation when peer is ready
  const startNegotiation = useCallback(async () => {
    silenceSystemAndAssistantSounds();
    const pc = peerConnectionRef.current || initWebRTC();
    if (!pc) return;

    try {
      const offer = await pc.createOffer({
        offerToReceiveAudio: true,
      });
      await pc.setLocalDescription(offer);
      callService.sendSignal(callId, userId, 'OFFER', offer);
    } catch (err) {
      console.warn('startNegotiation error:', err);
    }
  }, [callId, userId, initWebRTC]);

  // 5. Toggle Mute
  const toggleMute = useCallback(() => {
    const stream = rawLocalStreamRef.current;
    const processed = processedStreamRef.current;
    const newMuted = !isMuted;

    if (stream) {
      stream.getAudioTracks().forEach((track) => {
        track.enabled = !newMuted;
      });
    }
    if (processed) {
      processed.getAudioTracks().forEach((track) => {
        track.enabled = !newMuted;
      });
    }
    setIsMuted(newMuted);
  }, [isMuted]);

  // 6. Toggle Speaker
  const toggleSpeaker = useCallback(() => {
    setIsSpeakerOn((prev) => {
      const next = !prev;
      if (remoteAudioRef.current) {
        remoteAudioRef.current.muted = !next;
      }
      return next;
    });
  }, []);

  // 7. Cleanup audio and connections
  const cleanup = useCallback(() => {
    silenceSystemAndAssistantSounds();

    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
      animationFrameRef.current = null;
    }

    if (rawLocalStreamRef.current) {
      rawLocalStreamRef.current.getTracks().forEach((track) => track.stop());
      rawLocalStreamRef.current = null;
    }

    if (processedStreamRef.current) {
      processedStreamRef.current.getTracks().forEach((track) => track.stop());
      processedStreamRef.current = null;
    }

    if (peerConnectionRef.current) {
      peerConnectionRef.current.close();
      peerConnectionRef.current = null;
    }

    if (audioContextRef.current) {
      audioContextRef.current.close().catch(() => {});
      audioContextRef.current = null;
    }

    if (remoteAudioRef.current) {
      try {
        remoteAudioRef.current.pause();
        remoteAudioRef.current.srcObject = null;
        if (remoteAudioRef.current.parentNode) {
          remoteAudioRef.current.parentNode.removeChild(remoteAudioRef.current);
        }
      } catch {}
      remoteAudioRef.current = null;
    }

    setMicGranted(false);
    setIsConnected(false);
    setLocalVolume(0);
    setRemoteVolume(0);
  }, []);

  useEffect(() => {
    return () => {
      cleanup();
    };
  }, [cleanup]);

  return {
    micGranted,
    micError,
    isMuted,
    isSpeakerOn,
    localVolume,
    remoteVolume,
    isConnected,
    requestMicrophone,
    initWebRTC,
    startNegotiation,
    toggleMute,
    toggleSpeaker,
    cleanup,
  };
}
