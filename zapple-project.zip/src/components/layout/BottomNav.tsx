import React from 'react';
import { useApp } from '../../context/AppContext';
import { Home, Wallet, User } from 'lucide-react';
import { ActiveTab } from '../../types';

interface BottomNavProps {
  onNavigate?: () => void;
  activeTabOverride?: ActiveTab;
  className?: string;
}

export const BottomNav: React.FC<BottomNavProps> = ({ onNavigate, activeTabOverride, className = '' }) => {
  const { currentTab, setCurrentTab } = useApp();

  // Exactly 3 tabs:
  // 1. Home icon
  // 2. Wallet icon
  // 3. Profile icon
  const navItems: { id: ActiveTab; icon: React.FC<{ className?: string }> }[] = [
    { id: 'home', icon: Home },
    { id: 'earnings', icon: Wallet },
    { id: 'profile', icon: User },
  ];

  const activeId = activeTabOverride || currentTab;

  return (
    <nav
      id="bottom-navigation-bar"
      className={`fixed bottom-0 left-0 right-0 z-40 max-w-md mx-auto bg-black border-t border-neutral-900 px-4 py-3 select-none ${className}`}
    >
      <div className="grid grid-cols-3 items-center">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive =
            activeId === item.id || (item.id === 'earnings' && activeId === 'wallet');

          return (
            <button
              key={item.id}
              id={`nav-tab-${item.id}`}
              onClick={() => {
                setCurrentTab(item.id);
                if (onNavigate) onNavigate();
              }}
              className="flex items-center justify-center py-1 transition-colors cursor-pointer"
              aria-label={item.id}
            >
              <Icon
                className={`w-5 h-5 transition-colors ${
                  isActive ? 'text-white' : 'text-neutral-500 hover:text-neutral-300'
                }`}
              />
            </button>
          );
        })}
      </div>
    </nav>
  );
};
