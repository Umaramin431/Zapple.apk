import React from 'react';
import { useApp } from '../../context/AppContext';
import { BrandLogo } from '../common/BrandLogo';
import { ChevronLeft } from 'lucide-react';

interface TopHeaderProps {
  title?: string;
  showBack?: boolean;
  onBack?: () => void;
}

export const TopHeader: React.FC<TopHeaderProps> = ({
  title,
  showBack,
  onBack,
}) => {
  const { setCurrentTab } = useApp();

  return (
    <header className="sticky top-0 z-30 bg-black border-b border-neutral-900 px-4 py-3 select-none">
      <div className="max-w-md mx-auto flex items-center justify-between">
        <div className="flex items-center gap-3">
          {showBack ? (
            <button
              onClick={onBack || (() => setCurrentTab('home'))}
              className="p-1 text-neutral-400 hover:text-white rounded-lg transition-colors cursor-pointer"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
          ) : null}

          {title ? (
            <h1 className="text-sm font-semibold text-white tracking-tight">{title}</h1>
          ) : (
            <button
              onClick={() => setCurrentTab('home')}
              className="text-left focus:outline-hidden rounded-lg cursor-pointer"
            >
              <BrandLogo size="sm" showText={true} />
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
