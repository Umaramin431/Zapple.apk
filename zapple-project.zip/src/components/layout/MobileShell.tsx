import React from 'react';

interface MobileShellProps {
  children: React.ReactNode;
}

export const MobileShell: React.FC<MobileShellProps> = ({ children }) => {
  return (
    <div className="min-h-screen bg-black text-white flex flex-col items-center justify-center">
      {/* Centered mobile container with clean neutral borders */}
      <div className="w-full max-w-md min-h-screen sm:min-h-[860px] bg-black flex flex-col border-0 sm:border sm:border-neutral-900 sm:rounded-3xl overflow-hidden shadow-2xl relative">
        <div className="flex-1 flex flex-col min-h-0 relative bg-black">
          {children}
        </div>
      </div>
    </div>
  );
};
