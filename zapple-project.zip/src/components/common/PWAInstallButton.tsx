import React, { useState } from 'react';
import { usePWAInstall } from '../../hooks/usePWAInstall';
import { PWAInstallModal } from './PWAInstallModal';
import { Download } from 'lucide-react';

interface PWAInstallButtonProps {
  className?: string;
  variant?: 'button' | 'row';
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({
  className = '',
  variant = 'button',
}) => {
  const { isInstalled } = usePWAInstall();
  const [showModal, setShowModal] = useState(false);

  // If running in standalone app mode (already installed), we don't need to show install button unless in settings
  if (isInstalled && variant === 'button') {
    return null;
  }

  if (variant === 'row') {
    return (
      <>
        <button
          id="btn-install-apk-pwa"
          onClick={() => setShowModal(true)}
          className={`w-full bg-neutral-950 hover:bg-neutral-900 active:scale-[0.99] border border-neutral-900 rounded-xl p-3.5 flex items-center justify-between text-left transition-colors cursor-pointer ${className}`}
        >
          <div className="space-y-0.5">
            <div className="text-sm font-medium text-white flex items-center gap-2">
              <span>Convert to APK / Install App</span>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800/60 font-medium">
                ANDROID
              </span>
            </div>
            <div className="text-xs text-neutral-500">
              Install directly to home screen or download signed Android APK
            </div>
          </div>
          <Download className="w-4 h-4 text-neutral-400 shrink-0" />
        </button>

        <PWAInstallModal isOpen={showModal} onClose={() => setShowModal(false)} />
      </>
    );
  }

  return (
    <>
      <button
        id="btn-install-app-header"
        onClick={() => setShowModal(true)}
        className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-neutral-900 hover:bg-neutral-800 active:scale-[0.99] text-white border border-neutral-800 text-xs font-medium transition-colors cursor-pointer shrink-0 ${className}`}
      >
        <Download className="w-3.5 h-3.5" />
        <span>Install App</span>
      </button>

      <PWAInstallModal isOpen={showModal} onClose={() => setShowModal(false)} />
    </>
  );
};
