import React, { useState, useEffect, useRef } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface CallMilestonesProps {
  totalCompletedCalls: number;
}

export const CallMilestones: React.FC<CallMilestonesProps> = ({ totalCompletedCalls }) => {
  const safeTotal = Math.max(0, totalCompletedCalls || 0);

  // Unlimited dynamic buffer: Ensure there are always 50+ milestones ahead
  const [renderedCount, setRenderedCount] = useState<number>(() => Math.max(50, safeTotal + 40));

  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const activeMilestoneRef = useRef<HTMLDivElement>(null);
  const isInitialMount = useRef(true);

  // Expand milestone list whenever user progresses
  useEffect(() => {
    if (safeTotal + 30 > renderedCount) {
      setRenderedCount((prev) => Math.max(prev, safeTotal + 40));
    }
  }, [safeTotal, renderedCount]);

  // Auto-scroll to keep active milestone in view
  useEffect(() => {
    const timer = setTimeout(() => {
      if (activeMilestoneRef.current && scrollContainerRef.current) {
        const container = scrollContainerRef.current;
        const target = activeMilestoneRef.current;
        const targetLeft = target.offsetLeft;
        const targetWidth = target.offsetWidth;
        const containerWidth = container.clientWidth;

        const scrollPos = Math.max(0, targetLeft - containerWidth / 2 + targetWidth / 2);

        container.scrollTo({
          left: scrollPos,
          behavior: isInitialMount.current ? 'auto' : 'smooth',
        });
        isInitialMount.current = false;
      }
    }, 80);

    return () => clearTimeout(timer);
  }, [safeTotal]);

  // Infinite scroll extension
  const handleScroll = (e: React.UIEvent<HTMLDivElement>) => {
    const { scrollLeft, scrollWidth, clientWidth } = e.currentTarget;
    if (scrollWidth - (scrollLeft + clientWidth) < 200) {
      setRenderedCount((prev) => prev + 30);
    }
  };

  const scrollByAmount = (offset: number) => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollBy({ left: offset, behavior: 'smooth' });
    }
  };

  return (
    <div
      id="card-call-milestones"
      className="bg-neutral-950 border border-neutral-900 rounded-2xl p-4 space-y-3 w-full select-none"
    >
      {/* Card Header */}
      <div className="flex items-center justify-between">
        <div className="text-xs font-medium text-neutral-400 uppercase tracking-wider">
          Call Milestone Progress
        </div>
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => scrollByAmount(-180)}
            className="p-1 rounded-md bg-neutral-900 hover:bg-neutral-800 text-neutral-400 hover:text-white border border-neutral-800 transition-colors cursor-pointer"
            aria-label="Scroll milestones left"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => scrollByAmount(180)}
            className="p-1 rounded-md bg-neutral-900 hover:bg-neutral-800 text-neutral-400 hover:text-white border border-neutral-800 transition-colors cursor-pointer"
            aria-label="Scroll milestones right"
          >
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
          <div className="text-[11px] font-medium text-neutral-300 bg-neutral-900 border border-neutral-800 px-2 py-0.5 rounded-full ml-1">
            ₹20 / call
          </div>
        </div>
      </div>

      {/* Horizontally Scrollable Timeline (At least 6 circles visible at once) */}
      <div className="relative w-full">
        {/* Horizontal Scroll Area */}
        <div
          ref={scrollContainerRef}
          onScroll={handleScroll}
          className="overflow-x-auto overflow-y-hidden scroll-smooth touch-pan-x py-1.5 w-full [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]"
        >
          <div className="inline-flex items-center min-w-full">
            {Array.from({ length: renderedCount }).map((_, index) => {
              const milestoneNumber = index + 1;
              const isCompleted = index < safeTotal;
              const isCurrent = index === safeTotal;
              const isLast = index === renderedCount - 1;

              // Styles for the circle based on completion state
              let circleClass = 'bg-neutral-900 border border-neutral-800 text-neutral-400';
              let numberClass = 'text-neutral-500 font-medium';

              if (isCompleted) {
                circleClass = 'bg-white border-white text-black font-bold';
                numberClass = 'text-white font-semibold';
              } else if (isCurrent) {
                circleClass = 'bg-black border-2 border-white ring-2 ring-white/20 text-white font-bold';
                numberClass = 'text-white font-bold';
              }

              return (
                <div
                  key={milestoneNumber}
                  ref={isCurrent ? activeMilestoneRef : null}
                  className="flex flex-col items-center justify-center shrink-0 w-[48px] sm:w-[54px] relative"
                  title={`Milestone ${milestoneNumber}: ₹20 Reward`}
                >
                  {/* Left Half of Horizontal Connecting Line */}
                  {index > 0 && (
                    <div
                      className={`absolute left-0 top-[15px] sm:top-[16px] -translate-y-1/2 w-1/2 h-[2px] z-0 transition-colors duration-200 ${
                        index <= safeTotal ? 'bg-white' : 'bg-neutral-800'
                      }`}
                      aria-hidden="true"
                    />
                  )}

                  {/* Right Half of Horizontal Connecting Line */}
                  {!isLast && (
                    <div
                      className={`absolute right-0 top-[15px] sm:top-[16px] -translate-y-1/2 w-1/2 h-[2px] z-0 transition-colors duration-200 ${
                        index < safeTotal ? 'bg-white' : 'bg-neutral-800'
                      }`}
                      aria-hidden="true"
                    />
                  )}

                  {/* Milestone Circle containing "₹20" */}
                  <div
                    className={`relative z-10 w-7 h-7 sm:w-8 sm:h-8 rounded-full flex items-center justify-center transition-all ${circleClass}`}
                  >
                    <span className="text-[9px] sm:text-[10px] font-bold tracking-tight leading-none">
                      ₹20
                    </span>
                  </div>

                  {/* Milestone Number Directly Below Circle */}
                  <span
                    className={`text-[11px] sm:text-xs mt-1 text-center leading-none transition-colors ${numberClass}`}
                  >
                    {milestoneNumber}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Dynamic Lifetime Completed Calls text */}
      <div className="pt-2 flex items-center justify-between border-t border-neutral-900 text-xs">
        <div className="text-xs font-semibold text-white tracking-tight">
          Your {safeTotal} calls completed
        </div>
        <div className="text-neutral-400 text-[11px] font-medium">
          {safeTotal > 0 ? `Target: Milestone #${safeTotal + 1}` : 'Start Call #1'}
        </div>
      </div>
    </div>
  );
};
