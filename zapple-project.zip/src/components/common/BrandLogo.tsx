import React from 'react';

interface BrandLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
  className?: string;
}

export const BrandLogo: React.FC<BrandLogoProps> = ({
  size = 'md',
  showText = true,
  className = '',
}) => {
  const iconSizes = {
    sm: 'w-7 h-7 text-xs',
    md: 'w-8 h-8 text-sm',
    lg: 'w-11 h-11 text-base',
    xl: 'w-14 h-14 text-lg',
  };

  const textSizes = {
    sm: 'text-sm font-semibold',
    md: 'text-base font-semibold',
    lg: 'text-xl font-bold',
    xl: 'text-2xl font-bold',
  };

  return (
    <div className={`flex items-center gap-2.5 ${className} select-none`}>
      <div
        className={`${iconSizes[size]} flex items-center justify-center rounded-xl bg-white text-black font-bold tracking-tight shrink-0`}
      >
        Z
      </div>

      {showText && (
        <span className={`tracking-tight text-white ${textSizes[size]}`}>
          Zapple
        </span>
      )}
    </div>
  );
};
