import React, { useState, useEffect, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { poolService } from '../../services/poolService';
import { PrizePoolState, PrizePoolLedgerTransaction } from '../../types';
import {
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  Lock,
  Clock,
  Calendar,
  Search,
} from 'lucide-react';

interface PrizePoolManagementProps {
  onPoolUpdated?: () => void;
}

export const PrizePoolManagement: React.FC<PrizePoolManagementProps> = ({ onPoolUpdated }) => {
  const { currentUser, refreshDailyPool, refreshAdminOverview } = useApp();

  const [prizePoolState, setPrizePoolState] = useState<PrizePoolState | null>(null);
  const [transactions, setTransactions] = useState<PrizePoolLedgerTransaction[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [actionSuccessMsg, setActionSuccessMsg] = useState<string | null>(null);
  const [actionErrorMsg, setActionErrorMsg] = useState<string | null>(null);

  // Daily Prize Pool Amount input state
  const [dailyFundAmount, setDailyFundAmount] = useState<string>('10000');
  const [dailyFundNote, setDailyFundNote] = useState<string>('Daily prize pool funding allocation');
  const [isSubmittingFund, setIsSubmittingFund] = useState<boolean>(false);

  // Daily Limit form state
  const [dailyLimitInput, setDailyLimitInput] = useState<string>('30000');
  const [dailyLimitNote, setDailyLimitNote] = useState<string>('Updated daily reward distribution cap');
  const [isSubmittingLimit, setIsSubmittingLimit] = useState<boolean>(false);

  // Reset confirmation state
  const [isResetting, setIsResetting] = useState<boolean>(false);
  const [showResetConfirm, setShowResetConfirm] = useState<boolean>(false);

  // Disbursing queued calls state
  const [isDisbursingQueued, setIsDisbursingQueued] = useState<boolean>(false);

  // Filter & search for transactions
  const [typeFilter, setTypeFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const isAdmin = currentUser?.role === 'admin' || currentUser?.email?.toLowerCase() === 'ff280270@gmail.com';
  const adminId = currentUser?.id || currentUser?.email || 'usr_admin_ff280270';

  const loadPrizePoolData = async (showRefreshSpinner = false) => {
    if (!isAdmin) return;
    if (showRefreshSpinner) setIsRefreshing(true);
    try {
      const data = await poolService.getAdminPrizePool(adminId);
      if (data && data.prizePool) {
        setPrizePoolState(data.prizePool);
        setDailyLimitInput(String(data.prizePool.dailyLimit));
      }
      if (data && data.transactions) {
        setTransactions(data.transactions);
      }
    } catch (err: any) {
      console.warn('Notice: loadPrizePoolData:', err?.message || err);
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  };

  useEffect(() => {
    loadPrizePoolData();
  }, [isAdmin]);

  // Handle adding Daily Prize Pool Amount
  const handleAddDailyPrizePool = async (e: React.FormEvent) => {
    e.preventDefault();
    const amountNum = parseInt(dailyFundAmount, 10);
    if (isNaN(amountNum) || amountNum <= 0) {
      setActionErrorMsg('Please enter a valid positive fund injection amount.');
      return;
    }

    setIsSubmittingFund(true);
    setActionSuccessMsg(null);
    setActionErrorMsg(null);

    try {
      const res = await poolService.addFunds(
        amountNum,
        dailyFundNote || 'Daily Prize Pool Amount added',
        adminId
      );

      if (res.success && res.prizePool) {
        setPrizePoolState(res.prizePool);
        setDailyFundAmount('');
        setDailyFundNote('');
        setActionSuccessMsg(
          res.message || `Prize Pool updated successfully. Added ₹${amountNum.toLocaleString('en-IN')} to the Prize Pool.`
        );
        await loadPrizePoolData(true);
        await refreshDailyPool();
        await refreshAdminOverview();
        if (onPoolUpdated) onPoolUpdated();
      } else {
        console.error('[PrizePool Add Funds Error]:', res.error || res.message);
        setActionErrorMsg(res.error || res.message || 'Unable to add Prize Pool funds. Please try again.');
      }
    } catch (err: any) {
      console.error('[PrizePool Add Funds Exception]:', err);
      setActionErrorMsg(err?.message || 'Unable to add Prize Pool funds. Please try again.');
    } finally {
      setIsSubmittingFund(false);
      setTimeout(() => {
        setActionSuccessMsg(null);
        setActionErrorMsg(null);
      }, 4500);
    }
  };

  // Handle Setting Daily Limit
  const handleSetDailyLimit = async (e: React.FormEvent) => {
    e.preventDefault();
    const limitNum = parseInt(dailyLimitInput, 10);
    if (isNaN(limitNum) || limitNum < 0) {
      setActionErrorMsg('Please enter a valid daily limit.');
      return;
    }

    setIsSubmittingLimit(true);
    setActionSuccessMsg(null);
    setActionErrorMsg(null);

    try {
      const res = await poolService.setDailyLimit(
        limitNum,
        dailyLimitNote || 'Admin daily limit adjustment',
        adminId
      );

      if (res.success && res.prizePool) {
        setPrizePoolState(res.prizePool);
        setActionSuccessMsg(`Daily limit set to ₹${limitNum.toLocaleString('en-IN')}.`);
        await loadPrizePoolData();
        await refreshDailyPool();
        await refreshAdminOverview();
        if (onPoolUpdated) onPoolUpdated();
      } else {
        setActionErrorMsg(res.message || 'Failed to update daily limit.');
      }
    } catch (err: any) {
      setActionErrorMsg(err.message || 'Error updating daily limit.');
    } finally {
      setIsSubmittingLimit(false);
      setTimeout(() => {
        setActionSuccessMsg(null);
        setActionErrorMsg(null);
      }, 4000);
    }
  };

  // Handle Manual Daily Reset
  const handleResetDailyPool = async () => {
    setIsResetting(true);
    setActionSuccessMsg(null);
    setActionErrorMsg(null);
    setShowResetConfirm(false);

    try {
      const res = await poolService.resetPrizePool('Manual admin cycle reset', adminId);
      if (res.success && res.prizePool) {
        setPrizePoolState(res.prizePool);
        setActionSuccessMsg('Daily pool cycle reset.');
        await loadPrizePoolData();
        await refreshDailyPool();
        await refreshAdminOverview();
        if (onPoolUpdated) onPoolUpdated();
      } else {
        setActionErrorMsg(res.error || 'Failed to reset daily pool.');
      }
    } catch (err: any) {
      setActionErrorMsg(err.message || 'Error resetting daily pool.');
    } finally {
      setIsResetting(false);
      setTimeout(() => {
        setActionSuccessMsg(null);
        setActionErrorMsg(null);
      }, 4000);
    }
  };

  // Handle Disbursing Queued Calls
  const handleDisburseQueued = async () => {
    setIsDisbursingQueued(true);
    setActionSuccessMsg(null);
    setActionErrorMsg(null);

    try {
      const res = await poolService.disburseQueuedRewards(adminId);
      if (res.success) {
        if (res.prizePool) setPrizePoolState(res.prizePool);
        setActionSuccessMsg(res.message || 'Queued rewards processed.');
        await loadPrizePoolData();
        await refreshDailyPool();
        await refreshAdminOverview();
        if (onPoolUpdated) onPoolUpdated();
      } else {
        setActionErrorMsg(res.message || 'Failed to disburse queued rewards.');
      }
    } catch (err: any) {
      setActionErrorMsg(err.message || 'Error executing queued disbursement.');
    } finally {
      setIsDisbursingQueued(false);
      setTimeout(() => {
        setActionSuccessMsg(null);
        setActionErrorMsg(null);
      }, 5000);
    }
  };

  const filteredTransactions = useMemo(() => {
    return transactions.filter((tx) => {
      if (typeFilter !== 'ALL' && tx.type !== typeFilter) return false;
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchNote = tx.note?.toLowerCase().includes(query);
        const matchAdmin = tx.adminName?.toLowerCase().includes(query);
        const matchUser = tx.userName?.toLowerCase().includes(query);
        const matchP1 = tx.participant1Name?.toLowerCase().includes(query);
        const matchP2 = tx.participant2Name?.toLowerCase().includes(query);
        const matchId = tx.id.toLowerCase().includes(query);
        const matchCall = tx.callId?.toLowerCase().includes(query);
        return matchNote || matchAdmin || matchUser || matchP1 || matchP2 || matchId || matchCall;
      }
      return true;
    });
  }, [transactions, typeFilter, searchQuery]);

  if (!isAdmin) {
    return (
      <div className="p-6 rounded-xl bg-neutral-950 border border-neutral-900 text-center space-y-3">
        <div className="w-10 h-10 mx-auto rounded-full bg-neutral-900 flex items-center justify-center text-neutral-400">
          <Lock className="w-5 h-5" />
        </div>
        <h3 className="text-sm font-semibold text-white">Access Denied</h3>
        <p className="text-xs text-neutral-400 max-w-sm mx-auto">
          The Prize Pool management console is restricted to administrator accounts.
        </p>
      </div>
    );
  }

  const pool = prizePoolState || {
    totalPoolBalance: 75000,
    totalAllocatedAllTime: 180,
    remainingPoolBalance: 74820,
    dailyLimit: 30000,
    dailyAllocated: 180,
    dailyRemaining: 29820,
    todayApprovedRewardsCount: 9,
    isDailyExhausted: false,
    nextResetAt: new Date().toISOString(),
    lastResetAt: new Date().toISOString(),
    lastUpdated: new Date().toISOString(),
    awaitingPoolFundsCallsCount: 0,
  };

  const dailyUsagePercent = Math.min(100, Math.round((pool.dailyAllocated / (pool.dailyLimit || 1)) * 100));
  const awaitingCount = pool.awaitingPoolFundsCallsCount || 0;

  return (
    <div className="space-y-4 text-white">
      {/* Messages */}
      {actionSuccessMsg && (
        <div className="p-3 rounded-xl bg-neutral-900 border border-neutral-800 text-neutral-200 text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{actionSuccessMsg}</span>
        </div>
      )}

      {actionErrorMsg && (
        <div className="p-3 rounded-xl bg-neutral-900 border border-neutral-800 text-rose-300 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
          <span>{actionErrorMsg}</span>
        </div>
      )}

      {/* Awaiting Funds Queue */}
      {awaitingCount > 0 && (
        <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-900 space-y-3">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <div className="text-xs font-semibold text-white">
                {awaitingCount} Call(s) Awaiting Funds
              </div>
              <div className="text-xs text-neutral-400">
                Requires ₹{awaitingCount * 40} to disburse pending rewards.
              </div>
            </div>
            <button
              onClick={handleDisburseQueued}
              disabled={isDisbursingQueued || pool.remainingPoolBalance < 40}
              className="px-3 py-1.5 bg-white hover:bg-neutral-200 disabled:opacity-40 text-black font-semibold text-xs rounded-xl transition-colors cursor-pointer"
            >
              {isDisbursingQueued ? 'Processing...' : 'Disburse Queued'}
            </button>
          </div>
        </div>
      )}

      {/* Overview Cards */}
      <div className="grid grid-cols-2 gap-3">
        {/* Remaining Prize Pool */}
        <div className="bg-neutral-950 border border-neutral-900 rounded-xl p-4">
          <div className="text-xs font-medium text-neutral-400 uppercase tracking-wider mb-1">
            Prize Pool Balance
          </div>
          <div className="text-2xl font-semibold text-white tracking-tight">
            ₹{pool.remainingPoolBalance.toLocaleString('en-IN')}
          </div>
          <div className="text-[11px] text-neutral-500 mt-1">
            {Math.floor(pool.remainingPoolBalance / 40)} calls remaining
          </div>
        </div>

        {/* Daily Remaining */}
        <div className="bg-neutral-950 border border-neutral-900 rounded-xl p-4">
          <div className="text-xs font-medium text-neutral-400 uppercase tracking-wider mb-1">
            Today's Remaining
          </div>
          <div className="text-2xl font-semibold text-white tracking-tight">
            ₹{pool.dailyRemaining.toLocaleString('en-IN')}
          </div>
          <div className="text-[11px] text-neutral-500 mt-1">
            Cap: ₹{pool.dailyLimit.toLocaleString('en-IN')}
          </div>
        </div>
      </div>

      {/* DAILY PRIZE POOL AMOUNT - Key requirement */}
      <div className="bg-neutral-950 border border-neutral-900 rounded-xl p-4 space-y-3">
        <div className="space-y-0.5">
          <div className="text-xs font-medium text-neutral-400 uppercase tracking-wider">
            Daily Prize Pool Amount
          </div>
          <p className="text-xs text-neutral-400">
            Enter the funding amount to add to the Prize Pool for the day.
          </p>
        </div>

        <form onSubmit={handleAddDailyPrizePool} className="space-y-3">
          <div className="relative">
            <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-neutral-500 text-xs font-medium">
              ₹
            </span>
            <input
              type="number"
              required
              min="1"
              step="1"
              value={dailyFundAmount}
              onChange={(e) => setDailyFundAmount(e.target.value)}
              placeholder="e.g. 10000"
              className="w-full pl-8 pr-3 py-2.5 bg-neutral-900 border border-neutral-800 rounded-xl text-xs text-white focus:outline-hidden focus:border-neutral-600"
            />
          </div>

          {/* Quick preset chips */}
          <div className="flex flex-wrap gap-1.5">
            {[1000, 5000, 10000, 25000, 50000].map((amt) => (
              <button
                key={amt}
                type="button"
                onClick={() => setDailyFundAmount(String(amt))}
                className={`px-2.5 py-1 rounded-lg text-xs transition-colors cursor-pointer border ${
                  dailyFundAmount === String(amt)
                    ? 'bg-white text-black border-white font-medium'
                    : 'bg-neutral-900 text-neutral-400 border-neutral-800 hover:text-white'
                }`}
              >
                +₹{amt.toLocaleString('en-IN')}
              </button>
            ))}
          </div>

          <button
            type="submit"
            disabled={isSubmittingFund || !dailyFundAmount}
            className="w-full py-2.5 px-4 bg-white hover:bg-neutral-200 disabled:opacity-40 text-black font-semibold text-xs rounded-xl transition-colors cursor-pointer"
          >
            {isSubmittingFund ? 'Adding to Prize Pool...' : 'Add to Prize Pool'}
          </button>
        </form>
      </div>

      {/* Daily Distribution Limit & Reset */}
      <div className="bg-neutral-950 border border-neutral-900 rounded-xl p-4 space-y-3">
        <div className="space-y-0.5">
          <div className="text-xs font-medium text-neutral-400 uppercase tracking-wider">
            Daily Distribution Cap
          </div>
          <p className="text-xs text-neutral-400">
            Current daily ceiling for automatic reward allocation.
          </p>
        </div>

        <form onSubmit={handleSetDailyLimit} className="space-y-3">
          <div className="relative">
            <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-neutral-500 text-xs font-medium">
              ₹
            </span>
            <input
              type="number"
              required
              min="0"
              step="1"
              value={dailyLimitInput}
              onChange={(e) => setDailyLimitInput(e.target.value)}
              placeholder="e.g. 30000"
              className="w-full pl-8 pr-3 py-2.5 bg-neutral-900 border border-neutral-800 rounded-xl text-xs text-white focus:outline-hidden focus:border-neutral-600"
            />
          </div>

          <div className="flex gap-2">
            <button
              type="submit"
              disabled={isSubmittingLimit || !dailyLimitInput}
              className="flex-1 py-2 px-3 bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-white font-medium text-xs rounded-xl transition-colors cursor-pointer"
            >
              {isSubmittingLimit ? 'Updating...' : 'Update Daily Cap'}
            </button>

            <button
              type="button"
              onClick={() => setShowResetConfirm(true)}
              className="py-2 px-3 bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-neutral-300 hover:text-white font-medium text-xs rounded-xl transition-colors cursor-pointer"
            >
              Reset Cycle
            </button>
          </div>
        </form>

        {showResetConfirm && (
          <div className="p-3 rounded-xl bg-neutral-900 border border-neutral-800 space-y-2">
            <p className="text-xs text-neutral-300">
              Reset today's allocated pool counter to ₹0?
            </p>
            <div className="flex gap-2 justify-end">
              <button
                type="button"
                onClick={() => setShowResetConfirm(false)}
                className="px-3 py-1 rounded-lg text-xs text-neutral-400 hover:text-white cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleResetDailyPool}
                disabled={isResetting}
                className="px-3 py-1 rounded-lg text-xs bg-white text-black font-semibold hover:bg-neutral-200 cursor-pointer"
              >
                {isResetting ? 'Resetting...' : 'Confirm'}
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Financial Records & Ledger */}
      <div className="bg-neutral-950 border border-neutral-900 rounded-xl p-4 space-y-3">
        <div className="flex items-center justify-between">
          <div className="text-xs font-medium text-neutral-400 uppercase tracking-wider">
            Financial Records
          </div>
          <button
            onClick={() => loadPrizePoolData(true)}
            disabled={isRefreshing}
            className="text-xs text-neutral-400 hover:text-white flex items-center gap-1 transition-colors cursor-pointer"
          >
            <RefreshCw className={`w-3 h-3 ${isRefreshing ? 'animate-spin' : ''}`} />
            <span>Sync</span>
          </button>
        </div>

        {/* Search & Filter */}
        <div className="space-y-2">
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-neutral-500" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search transactions..."
              className="w-full pl-8 pr-3 py-1.5 rounded-xl bg-neutral-900 border border-neutral-800 text-xs text-white placeholder-neutral-500 focus:outline-hidden focus:border-neutral-600"
            />
          </div>

          <div className="flex flex-wrap gap-1">
            {[
              { id: 'ALL', label: 'All' },
              { id: 'FUND_INJECTION', label: 'Inflows' },
              { id: 'REWARD_ALLOCATION', label: 'Rewards' },
              { id: 'LIMIT_UPDATE', label: 'Limits' },
              { id: 'DAILY_RESET', label: 'Resets' },
            ].map((f) => (
              <button
                key={f.id}
                onClick={() => setTypeFilter(f.id)}
                className={`px-2.5 py-0.5 rounded-lg text-[11px] transition-colors cursor-pointer border ${
                  typeFilter === f.id
                    ? 'bg-white text-black border-white font-medium'
                    : 'bg-neutral-900 text-neutral-400 border-neutral-800 hover:text-white'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>

        {/* Transaction Items */}
        {filteredTransactions.length === 0 ? (
          <div className="py-6 text-center text-xs text-neutral-500">
            No financial records found.
          </div>
        ) : (
          <div className="space-y-2 max-h-72 overflow-y-auto">
            {filteredTransactions.map((tx) => {
              const isPositive = tx.amount > 0;
              const isNegative = tx.amount < 0;

              return (
                <div
                  key={tx.id}
                  className="p-3 rounded-xl bg-neutral-900 border border-neutral-800 space-y-1 text-xs"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-medium text-neutral-400 uppercase">
                      {tx.type.replace('_', ' ')}
                    </span>
                    <span
                      className={`font-semibold ${
                        isPositive ? 'text-white' : isNegative ? 'text-neutral-300' : 'text-neutral-400'
                      }`}
                    >
                      {tx.amount !== 0 ? `${isPositive ? '+' : ''}₹${Math.abs(tx.amount).toLocaleString('en-IN')}` : 'RECORD'}
                    </span>
                  </div>

                  <p className="text-neutral-300 text-[11px]">{tx.note}</p>

                  <div className="flex items-center justify-between text-[10px] text-neutral-500 pt-1">
                    <span>Balance: ₹{tx.balanceAfter.toLocaleString('en-IN')}</span>
                    <span>{new Date(tx.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
