import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { PrizePoolManagement } from './PrizePoolManagement';
import { BottomNav } from '../layout/BottomNav';
import { poolService } from '../../services/poolService';
import { User } from '../../types';
import {
  X,
  RefreshCw,
  Search,
  CheckCircle2,
  AlertCircle,
  ChevronDown,
  ChevronUp,
  Lock,
  UserX,
  UserCheck,
  ShieldAlert,
  ShieldCheck,
  Ban,
  Clock,
  Calendar,
  Mail,
  Smartphone,
  PhoneCall,
  Wallet as WalletIcon,
} from 'lucide-react';

interface AdminPanelModalProps {
  isOpen: boolean;
  onClose: () => void;
}

type AdminTab = 'prize-pool' | 'calls' | 'payouts' | 'users' | 'financials' | 'audits';

export const AdminPanelModal: React.FC<AdminPanelModalProps> = ({ isOpen, onClose }) => {
  const {
    currentUser,
    setCurrentTab,
    dailyPool,
    refreshDailyPool,
    adminOverview,
    refreshAdminOverview,
    updatePayoutStatus,
    adminReviewCall,
    users,
  } = useApp();

  const [activeAdminTab, setActiveAdminTab] = useState<AdminTab>('prize-pool');

  // Calls review state
  const [callFilter, setCallFilter] = useState<'all' | 'pending' | 'verified' | 'rejected'>('all');
  const [callSearch, setCallSearch] = useState('');
  const [expandedCallId, setExpandedCallId] = useState<string | null>(null);
  const [rejectingCallId, setRejectingCallId] = useState<string | null>(null);
  const [rejectCallReason, setRejectCallReason] = useState('Bilateral conversational criteria not met.');
  const [isProcessingCall, setIsProcessingCall] = useState(false);

  // Withdrawals state
  const [payoutFilter, setPayoutFilter] = useState<'all' | 'PENDING' | 'PAID' | 'PROCESSING' | 'REJECTED'>('all');
  const [approvingPayoutId, setApprovingPayoutId] = useState<string | null>(null);
  const [payoutRefInput, setPayoutRefInput] = useState('');
  const [rejectingPayoutId, setRejectingPayoutId] = useState<string | null>(null);
  const [rejectPayoutReason, setRejectPayoutReason] = useState('Invalid payout destination or KYC requirement.');
  const [isProcessingPayout, setIsProcessingPayout] = useState(false);

  // Users management state
  const [userSearch, setUserSearch] = useState('');
  const [userStatusFilter, setUserStatusFilter] = useState<'ALL' | 'ACTIVE' | 'BANNED'>('ALL');
  const [banningUser, setBanningUser] = useState<User | null>(null);
  const [banReasonInput, setBanReasonInput] = useState('');
  const [unbanningUser, setUnbanningUser] = useState<User | null>(null);
  const [isProcessingUserAction, setIsProcessingUserAction] = useState(false);

  // Feedback notifications
  const [actionFeedback, setActionFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  useEffect(() => {
    if (isOpen) {
      refreshAdminOverview();
      refreshDailyPool();
    }
  }, [isOpen, refreshAdminOverview, refreshDailyPool]);

  if (!isOpen) return null;

  const isAdmin = currentUser?.role === 'admin' || currentUser?.email?.toLowerCase() === 'ff280270@gmail.com';

  const callsList: any[] = adminOverview?.calls || [];
  const rewardsList: any[] = adminOverview?.rewards || [];
  const payoutsList: any[] = adminOverview?.payouts || [];
  const auditsList: any[] = adminOverview?.adminAuditLogs || adminOverview?.audits || [];
  const ledger = adminOverview?.ledger;
  const allAdminUsers: any[] = adminOverview?.users || users || [];

  const handleBanUser = async () => {
    if (!banningUser) return;
    setIsProcessingUserAction(true);
    try {
      const res = await poolService.banUser(
        banningUser.id,
        banReasonInput.trim() || 'Terms of Service violation',
        currentUser?.id
      );
      if (res.success) {
        setActionFeedback({
          type: 'success',
          text: `Successfully suspended account for ${banningUser.name}.`,
        });
        setBanningUser(null);
        setBanReasonInput('');
        await refreshAdminOverview();
      } else {
        setActionFeedback({ type: 'error', text: res.error || 'Failed to ban user account.' });
      }
    } catch (err: any) {
      setActionFeedback({ type: 'error', text: err?.message || 'Error executing user suspension.' });
    } finally {
      setIsProcessingUserAction(false);
    }
  };

  const handleUnbanUser = async () => {
    if (!unbanningUser) return;
    setIsProcessingUserAction(true);
    try {
      const res = await poolService.unbanUser(unbanningUser.id, currentUser?.id);
      if (res.success) {
        setActionFeedback({
          type: 'success',
          text: `Account reinstated for ${unbanningUser.name}.`,
        });
        setUnbanningUser(null);
        await refreshAdminOverview();
      } else {
        setActionFeedback({ type: 'error', text: res.error || 'Failed to reinstate user account.' });
      }
    } catch (err: any) {
      setActionFeedback({ type: 'error', text: err?.message || 'Error executing user unban.' });
    } finally {
      setIsProcessingUserAction(false);
    }
  };

  // Filter users
  const filteredUsers = allAdminUsers.filter((u) => {
    const status = u.status || 'ACTIVE';
    if (userStatusFilter !== 'ALL' && status !== userStatusFilter) {
      return false;
    }
    if (userSearch.trim()) {
      const q = userSearch.toLowerCase();
      const matchName = u.name?.toLowerCase().includes(q);
      const matchEmail = u.email?.toLowerCase().includes(q);
      const matchId = u.id?.toLowerCase().includes(q);
      const matchMobile = u.mobile?.toLowerCase().includes(q);
      const matchRef = u.referralCode?.toLowerCase().includes(q);
      const matchDevice = u.deviceId?.toLowerCase().includes(q);
      return matchName || matchEmail || matchId || matchMobile || matchRef || matchDevice;
    }
    return true;
  });

  // Filter calls
  const filteredCalls = callsList.filter((c) => {
    const reward = rewardsList.find((r) => r.callId === c.callId);
    const status = reward?.status || c.rewardStatus || 'pending_verification';

    if (callFilter === 'verified') {
      if (status !== 'verified' && status !== 'matured' && status !== 'held') return false;
    } else if (callFilter === 'rejected') {
      if (status !== 'rejected') return false;
    } else if (callFilter === 'pending') {
      if (status !== 'pending_verification' && status !== 'pending_admin_review') return false;
    }

    if (callSearch.trim()) {
      const q = callSearch.toLowerCase();
      const matchTopic = c.topic?.toLowerCase().includes(q);
      const matchCode = c.joinCode?.toLowerCase().includes(q);
      const matchP1 = c.creatorName?.toLowerCase().includes(q);
      const matchP2 = c.participantName?.toLowerCase().includes(q);
      return matchTopic || matchCode || matchP1 || matchP2;
    }

    return true;
  });

  // Filter payouts
  const filteredPayouts = payoutsList.filter((p) => {
    if (payoutFilter !== 'all' && p.status !== payoutFilter) return false;
    return true;
  });

  const pendingCallsCount = callsList.filter((c) => {
    const reward = rewardsList.find((r) => r.callId === c.callId);
    const s = reward?.status || c.rewardStatus || 'pending_verification';
    return s === 'pending_verification' || s === 'pending_admin_review';
  }).length;

  const pendingPayoutsCount = payoutsList.filter((p) => p.status === 'PENDING').length;

  const showFeedback = (type: 'success' | 'error', text: string) => {
    setActionFeedback({ type, text });
    setTimeout(() => setActionFeedback(null), 3500);
  };

  // Call review handlers
  const handleApproveCall = async (callId: string) => {
    setIsProcessingCall(true);
    try {
      const res = await adminReviewCall(callId, 'VERIFIED', 'Manual admin verification');
      if (res.success) {
        showFeedback('success', 'Call approved. ₹20 allocated to each participant.');
      } else {
        showFeedback('error', res.message || 'Failed to approve call.');
      }
    } catch (err: any) {
      showFeedback('error', err.message || 'Error processing call approval.');
    } finally {
      setIsProcessingCall(false);
    }
  };

  const handleConfirmRejectCall = async () => {
    if (!rejectingCallId) return;
    setIsProcessingCall(true);
    try {
      const res = await adminReviewCall(rejectingCallId, 'REJECTED', rejectCallReason);
      if (res.success) {
        showFeedback('success', 'Call rejected.');
        setRejectingCallId(null);
      } else {
        showFeedback('error', res.message || 'Failed to reject call.');
      }
    } catch (err: any) {
      showFeedback('error', err.message || 'Error processing call rejection.');
    } finally {
      setIsProcessingCall(false);
    }
  };

  // Payout review handlers
  const handleConfirmApprovePayout = async () => {
    if (!approvingPayoutId) return;
    setIsProcessingPayout(true);
    try {
      const ref = payoutRefInput.trim() || `UPI/REF/${Date.now().toString().slice(-8)}`;
      const res = await updatePayoutStatus(approvingPayoutId, 'PAID', ref);
      if (res.success) {
        showFeedback('success', 'Withdrawal marked as Paid.');
        setApprovingPayoutId(null);
        setPayoutRefInput('');
      } else {
        showFeedback('error', res.message || 'Failed to approve withdrawal.');
      }
    } catch (err: any) {
      showFeedback('error', err.message || 'Error processing withdrawal.');
    } finally {
      setIsProcessingPayout(false);
    }
  };

  const handleConfirmRejectPayout = async () => {
    if (!rejectingPayoutId) return;
    setIsProcessingPayout(true);
    try {
      const res = await updatePayoutStatus(rejectingPayoutId, 'REJECTED', undefined, rejectPayoutReason);
      if (res.success) {
        showFeedback('success', 'Withdrawal rejected and balance refunded.');
        setRejectingPayoutId(null);
      } else {
        showFeedback('error', res.message || 'Failed to reject withdrawal.');
      }
    } catch (err: any) {
      showFeedback('error', err.message || 'Error processing withdrawal rejection.');
    } finally {
      setIsProcessingPayout(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black text-white flex flex-col">
      {/* Top Header - Simple minimal Home screen style */}
      <header className="sticky top-0 z-20 bg-black border-b border-neutral-900 px-4 py-3.5">
        <div className="max-w-md mx-auto flex items-center justify-between">
          <h1 className="text-sm font-semibold text-white">Admin Management</h1>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                refreshAdminOverview();
                refreshDailyPool();
              }}
              className="p-1.5 text-neutral-400 hover:text-white rounded-lg transition-colors cursor-pointer"
              title="Refresh"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-neutral-400 hover:text-white rounded-lg transition-colors cursor-pointer"
              title="Close"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <div className="flex-1 overflow-y-auto px-4 pt-3 pb-28 max-w-md mx-auto w-full space-y-4">
        {/* Access Restriction Check */}
        {!isAdmin ? (
          <div className="p-8 text-center space-y-3 bg-neutral-950 border border-neutral-900 rounded-2xl">
            <div className="w-10 h-10 mx-auto rounded-full bg-neutral-900 flex items-center justify-center text-neutral-400">
              <Lock className="w-5 h-5" />
            </div>
            <h2 className="text-sm font-semibold text-white">Access Restricted</h2>
            <p className="text-xs text-neutral-400 max-w-xs mx-auto">
              Administrator privileges are required to access this panel.
            </p>
          </div>
        ) : (
          <>
            {/* Feedback message banner */}
            {actionFeedback && (
              <div
                className={`p-3 rounded-xl border text-xs flex items-center gap-2 ${
                  actionFeedback.type === 'success'
                    ? 'bg-neutral-900 border-neutral-800 text-neutral-200'
                    : 'bg-neutral-900 border-neutral-800 text-rose-300'
                }`}
              >
                {actionFeedback.type === 'success' ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                ) : (
                  <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                )}
                <span>{actionFeedback.text}</span>
              </div>
            )}

            {/* Navigation Tabs - Clean, minimalist list */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
              {[
                { id: 'prize-pool', label: 'Prize Pool' },
                {
                  id: 'calls',
                  label: pendingCallsCount > 0 ? `Calls (${pendingCallsCount})` : 'Calls',
                },
                {
                  id: 'payouts',
                  label: pendingPayoutsCount > 0 ? `Withdrawals (${pendingPayoutsCount})` : 'Withdrawals',
                },
                { id: 'users', label: 'Users' },
                { id: 'financials', label: 'Financials' },
                { id: 'audits', label: 'Audits' },
              ].map((tab) => {
                const isActive = activeAdminTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveAdminTab(tab.id as AdminTab)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap transition-colors cursor-pointer border ${
                      isActive
                        ? 'bg-white text-black border-white'
                        : 'bg-neutral-900 text-neutral-400 border-neutral-800 hover:text-white'
                    }`}
                  >
                    {tab.label}
                  </button>
                );
              })}
            </div>

            {/* TAB 1: PRIZE POOL */}
            {activeAdminTab === 'prize-pool' && (
              <PrizePoolManagement
                onPoolUpdated={() => {
                  refreshAdminOverview();
                  refreshDailyPool();
                }}
              />
            )}

            {/* TAB 2: CALL REVIEWS */}
            {activeAdminTab === 'calls' && (
              <div className="space-y-3">
                {/* Search & Status Filters */}
                <div className="space-y-2">
                  <div className="relative">
                    <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-neutral-500" />
                    <input
                      type="text"
                      placeholder="Search by topic, code, or user..."
                      value={callSearch}
                      onChange={(e) => setCallSearch(e.target.value)}
                      className="w-full pl-8 pr-3 py-1.5 rounded-xl bg-neutral-900 border border-neutral-800 text-xs text-white placeholder-neutral-500 focus:outline-hidden focus:border-neutral-600"
                    />
                  </div>

                  <div className="flex gap-1">
                    {(['all', 'pending', 'verified', 'rejected'] as const).map((filter) => (
                      <button
                        key={filter}
                        onClick={() => setCallFilter(filter)}
                        className={`px-2.5 py-1 rounded-lg text-xs capitalize transition-colors cursor-pointer border ${
                          callFilter === filter
                            ? 'bg-white text-black border-white font-medium'
                            : 'bg-neutral-900 text-neutral-400 border-neutral-800 hover:text-white'
                        }`}
                      >
                        {filter}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Reject Call Modal / Prompt */}
                {rejectingCallId && (
                  <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 space-y-3">
                    <div className="text-xs font-semibold text-white">
                      Reject Call Session
                    </div>
                    <input
                      type="text"
                      value={rejectCallReason}
                      onChange={(e) => setRejectCallReason(e.target.value)}
                      placeholder="Reason for rejection..."
                      className="w-full px-3 py-2 bg-neutral-900 border border-neutral-800 rounded-xl text-xs text-white focus:outline-hidden focus:border-neutral-600"
                    />
                    <div className="flex gap-2 justify-end">
                      <button
                        type="button"
                        onClick={() => setRejectingCallId(null)}
                        className="px-3 py-1.5 rounded-xl text-xs text-neutral-400 hover:text-white cursor-pointer"
                      >
                        Cancel
                      </button>
                      <button
                        type="button"
                        onClick={handleConfirmRejectCall}
                        disabled={isProcessingCall}
                        className="px-3 py-1.5 rounded-xl text-xs bg-neutral-900 text-rose-400 border border-neutral-800 hover:bg-rose-950/40 font-medium cursor-pointer"
                      >
                        {isProcessingCall ? 'Rejecting...' : 'Confirm Rejection'}
                      </button>
                    </div>
                  </div>
                )}

                {/* Calls List */}
                {filteredCalls.length === 0 ? (
                  <div className="py-8 text-center text-xs text-neutral-500 bg-neutral-950 border border-neutral-900 rounded-xl">
                    No calls match the selected filter.
                  </div>
                ) : (
                  <div className="space-y-3">
                    {filteredCalls.map((c) => {
                      const reward = rewardsList.find((r) => r.callId === c.callId);
                      const status = reward?.status || c.rewardStatus || 'pending_verification';
                      const isPending = status === 'pending_verification' || status === 'pending_admin_review';
                      const isExpanded = expandedCallId === c.callId;
                      const aiResult = c.aiVerificationResult;

                      return (
                        <div
                          key={c.callId}
                          className="bg-neutral-950 border border-neutral-900 rounded-xl p-4 space-y-3"
                        >
                          <div className="flex items-start justify-between gap-2">
                            <div className="space-y-0.5">
                              <div className="text-xs font-semibold text-white">
                                {c.topic || 'Voice Conversation'}
                              </div>
                              <div className="text-[11px] text-neutral-400">
                                {c.creatorName} &amp; {c.participantName || 'Peer'}
                              </div>
                              <div className="text-[10px] text-neutral-500">
                                Code: {c.joinCode} • {c.actualDurationSeconds || c.durationSeconds || 180}s
                              </div>
                            </div>

                            <span
                              className={`text-[10px] font-medium px-2 py-0.5 rounded-full uppercase ${
                                status === 'verified' || status === 'matured' || status === 'held'
                                  ? 'bg-neutral-900 text-emerald-400 border border-neutral-800'
                                  : status === 'rejected'
                                  ? 'bg-neutral-900 text-rose-400 border border-neutral-800'
                                  : 'bg-neutral-900 text-amber-400 border border-neutral-800'
                              }`}
                            >
                              {status === 'verified' ? 'Approved (₹20)' : status}
                            </span>
                          </div>

                          {/* AI verification metrics */}
                          {aiResult && (
                            <div className="p-2.5 rounded-lg bg-neutral-900 border border-neutral-800 text-[11px] space-y-1">
                              <div className="flex justify-between text-neutral-400 text-[10px]">
                                <span>Speech Balance: {aiResult.speechBalance?.speaker1Ratio || 50}% / {aiResult.speechBalance?.speaker2Ratio || 50}%</span>
                                <span>Silence: {aiResult.speechBalance?.silenceRatio || 10}%</span>
                              </div>
                              {aiResult.summary && (
                                <p className="text-neutral-300 italic text-[10px]">
                                  "{aiResult.summary}"
                                </p>
                              )}
                            </div>
                          )}

                          {reward?.rejectionReason && (
                            <div className="text-[11px] text-rose-400">
                              Reason: {reward.rejectionReason}
                            </div>
                          )}

                          {/* Transcript expander */}
                          {c.transcript && c.transcript.length > 0 && (
                            <div>
                              <button
                                onClick={() => setExpandedCallId(isExpanded ? null : c.callId)}
                                className="text-[11px] text-neutral-400 hover:text-white flex items-center gap-1 transition-colors cursor-pointer"
                              >
                                {isExpanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                                <span>{isExpanded ? 'Hide transcript' : `View transcript (${c.transcript.length} turns)`}</span>
                              </button>

                              {isExpanded && (
                                <div className="mt-2 p-2.5 rounded-lg bg-neutral-900 border border-neutral-800 space-y-1.5 max-h-48 overflow-y-auto text-[11px]">
                                  {c.transcript.map((t: any, idx: number) => (
                                    <div key={idx} className="space-y-0.5">
                                      <span className="font-semibold text-white text-[10px]">{t.speaker}</span>
                                      <p className="text-neutral-300">{t.text}</p>
                                    </div>
                                  ))}
                                </div>
                              )}
                            </div>
                          )}

                          {/* Review buttons */}
                          {isPending && (
                            <div className="flex items-center gap-2 pt-1 border-t border-neutral-900">
                              <button
                                disabled={isProcessingCall}
                                onClick={() => handleApproveCall(c.callId)}
                                className="flex-1 py-2 px-3 bg-white hover:bg-neutral-200 disabled:opacity-40 text-black text-xs font-semibold rounded-xl transition-colors cursor-pointer"
                              >
                                Approve (₹20 each)
                              </button>
                              <button
                                disabled={isProcessingCall}
                                onClick={() => {
                                  setRejectingCallId(c.callId);
                                  setRejectCallReason('Failed 3-minute conversational criteria.');
                                }}
                                className="py-2 px-3 bg-neutral-900 hover:bg-rose-950/40 text-rose-400 border border-neutral-800 text-xs font-medium rounded-xl transition-colors cursor-pointer"
                              >
                                Reject
                              </button>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}

            {/* TAB 3: WITHDRAWALS */}
            {activeAdminTab === 'payouts' && (
              <div className="space-y-3">
                {/* Status Filter */}
                <div className="flex gap-1 overflow-x-auto pb-1">
                  {(['all', 'PENDING', 'PAID', 'PROCESSING', 'REJECTED'] as const).map((filter) => (
                    <button
                      key={filter}
                      onClick={() => setPayoutFilter(filter)}
                      className={`px-2.5 py-1 rounded-lg text-xs capitalize transition-colors cursor-pointer border ${
                        payoutFilter === filter
                          ? 'bg-white text-black border-white font-medium'
                          : 'bg-neutral-900 text-neutral-400 border-neutral-800 hover:text-white'
                      }`}
                    >
                      {filter}
                    </button>
                  ))}
                </div>

                {/* Approve Payout Modal / Dialog */}
                {approvingPayoutId && (
                  <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 space-y-3">
                    <div className="text-xs font-semibold text-white">
                      Approve &amp; Disburse Payout
                    </div>
                    <div>
                      <label className="block text-[10px] font-medium text-neutral-400 mb-1">
                        Bank / UPI Reference Number (UTR)
                      </label>
                      <input
                        type="text"
                        value={payoutRefInput}
                        onChange={(e) => setPayoutRefInput(e.target.value)}
                        placeholder="e.g. UPI/REF/84920481"
                        className="w-full px-3 py-2 bg-neutral-900 border border-neutral-800 rounded-xl text-xs text-white focus:outline-hidden focus:border-neutral-600"
                      />
                    </div>
                    <div className="flex gap-2 justify-end">
                      <button
                        type="button"
                        onClick={() => setApprovingPayoutId(null)}
                        className="px-3 py-1.5 rounded-xl text-xs text-neutral-400 hover:text-white cursor-pointer"
                      >
                        Cancel
                      </button>
                      <button
                        type="button"
                        onClick={handleConfirmApprovePayout}
                        disabled={isProcessingPayout}
                        className="px-3 py-1.5 rounded-xl text-xs bg-white text-black font-semibold hover:bg-neutral-200 cursor-pointer"
                      >
                        {isProcessingPayout ? 'Disbursing...' : 'Confirm Disburse'}
                      </button>
                    </div>
                  </div>
                )}

                {/* Reject Payout Modal / Dialog */}
                {rejectingPayoutId && (
                  <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 space-y-3">
                    <div className="text-xs font-semibold text-white">
                      Reject Payout Request
                    </div>
                    <input
                      type="text"
                      value={rejectPayoutReason}
                      onChange={(e) => setRejectPayoutReason(e.target.value)}
                      placeholder="Reason for rejection..."
                      className="w-full px-3 py-2 bg-neutral-900 border border-neutral-800 rounded-xl text-xs text-white focus:outline-hidden focus:border-neutral-600"
                    />
                    <div className="flex gap-2 justify-end">
                      <button
                        type="button"
                        onClick={() => setRejectingPayoutId(null)}
                        className="px-3 py-1.5 rounded-xl text-xs text-neutral-400 hover:text-white cursor-pointer"
                      >
                        Cancel
                      </button>
                      <button
                        type="button"
                        onClick={handleConfirmRejectPayout}
                        disabled={isProcessingPayout}
                        className="px-3 py-1.5 rounded-xl text-xs bg-neutral-900 text-rose-400 border border-neutral-800 hover:bg-rose-950/40 font-medium cursor-pointer"
                      >
                        {isProcessingPayout ? 'Rejecting...' : 'Reject & Refund'}
                      </button>
                    </div>
                  </div>
                )}

                {/* Payouts list */}
                {filteredPayouts.length === 0 ? (
                  <div className="py-8 text-center text-xs text-neutral-500 bg-neutral-950 border border-neutral-900 rounded-xl">
                    No withdrawal requests recorded.
                  </div>
                ) : (
                  <div className="space-y-3">
                    {filteredPayouts.map((p) => {
                      const isPending = p.status === 'PENDING';
                      return (
                        <div
                          key={p.id}
                          className="bg-neutral-950 border border-neutral-900 rounded-xl p-4 space-y-2.5"
                        >
                          <div className="flex items-start justify-between">
                            <div>
                              <div className="text-base font-semibold text-white">
                                ₹{p.amount}
                              </div>
                              <div className="text-xs text-neutral-300">
                                {p.userName || p.userId}
                              </div>
                              <div className="text-[11px] text-neutral-500">
                                {new Date(p.createdAt).toLocaleDateString()}
                              </div>
                            </div>

                            <span
                              className={`text-[10px] font-medium px-2 py-0.5 rounded-full uppercase ${
                                p.status === 'PAID'
                                  ? 'bg-neutral-900 text-emerald-400 border border-neutral-800'
                                  : p.status === 'REJECTED'
                                  ? 'bg-neutral-900 text-rose-400 border border-neutral-800'
                                  : 'bg-neutral-900 text-amber-400 border border-neutral-800'
                              }`}
                            >
                              {p.status}
                            </span>
                          </div>

                          {/* Destination details */}
                          <div className="p-2.5 rounded-lg bg-neutral-900 border border-neutral-800 text-xs text-neutral-300">
                            {p.destination?.payoutMethod === 'UPI' || p.payoutMethod === 'UPI' ? (
                              <div>UPI ID: {p.destination?.upiId || p.accountDetails || p.destinationDetails}</div>
                            ) : (
                              <div>
                                Bank: {p.destination?.bankAccountNumber || p.accountDetails} ({p.destination?.bankIfsc || 'IFSC'}) • {p.destination?.accountHolderName}
                              </div>
                            )}
                            {p.referenceNumber && (
                              <div className="text-[10px] text-neutral-400 pt-1">
                                Ref: {p.referenceNumber}
                              </div>
                            )}
                            {p.failureReason && (
                              <div className="text-[10px] text-rose-400 pt-1">
                                Note: {p.failureReason}
                              </div>
                            )}
                          </div>

                          {/* Action controls */}
                          {isPending && (
                            <div className="flex items-center gap-2 pt-1 border-t border-neutral-900">
                              <button
                                disabled={isProcessingPayout}
                                onClick={() => {
                                  setApprovingPayoutId(p.id);
                                  setPayoutRefInput(`UPI/UTR/${Date.now().toString().slice(-8)}`);
                                }}
                                className="flex-1 py-2 px-3 bg-white hover:bg-neutral-200 disabled:opacity-40 text-black text-xs font-semibold rounded-xl transition-colors cursor-pointer"
                              >
                                Approve (₹{p.amount})
                              </button>
                              <button
                                disabled={isProcessingPayout}
                                onClick={() => {
                                  setRejectingPayoutId(p.id);
                                  setRejectPayoutReason('Invalid VPA address or KYC issue.');
                                }}
                                className="py-2 px-3 bg-neutral-900 hover:bg-rose-950/40 text-rose-400 border border-neutral-800 text-xs font-medium rounded-xl transition-colors cursor-pointer"
                              >
                                Reject
                              </button>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}

            {/* TAB 4: USERS */}
            {activeAdminTab === 'users' && (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="text-xs font-medium text-neutral-400 uppercase tracking-wider">
                    User Management ({filteredUsers.length})
                  </div>
                  <div className="flex items-center gap-1.5 bg-neutral-950 border border-neutral-900 rounded-lg p-0.5 text-[11px]">
                    {(['ALL', 'ACTIVE', 'BANNED'] as const).map((st) => (
                      <button
                        key={st}
                        onClick={() => setUserStatusFilter(st)}
                        className={`px-2 py-1 rounded-md transition-colors cursor-pointer ${
                          userStatusFilter === st
                            ? 'bg-white text-black font-semibold'
                            : 'text-neutral-400 hover:text-white'
                        }`}
                      >
                        {st}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Search Bar */}
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-500" />
                  <input
                    type="text"
                    placeholder="Search by name, email, user ID, mobile, or code..."
                    value={userSearch}
                    onChange={(e) => setUserSearch(e.target.value)}
                    className="w-full bg-neutral-950 border border-neutral-900 rounded-xl pl-9 pr-3 py-2.5 text-xs text-white placeholder:text-neutral-600 focus:outline-none focus:border-neutral-700"
                  />
                  {userSearch && (
                    <button
                      onClick={() => setUserSearch('')}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-500 hover:text-white text-xs cursor-pointer"
                    >
                      Clear
                    </button>
                  )}
                </div>

                {/* Users List */}
                {filteredUsers.length === 0 ? (
                  <div className="py-10 text-center text-xs text-neutral-500 bg-neutral-950 border border-neutral-900 rounded-xl">
                    No user accounts match your search filter.
                  </div>
                ) : (
                  <div className="space-y-2.5">
                    {filteredUsers.map((u: any) => {
                      const isBanned = (u.status || 'ACTIVE') === 'BANNED';
                      const isSelf = u.id === currentUser?.id || (currentUser?.email && u.email?.toLowerCase() === currentUser?.email?.toLowerCase());
                      const isSuperAdmin = u.role === 'admin' || u.email?.toLowerCase() === 'ff280270@gmail.com';

                      return (
                        <div
                          key={u.id}
                          className={`bg-neutral-950 border rounded-xl p-3.5 space-y-3 transition-colors ${
                            isBanned ? 'border-rose-950/60 bg-rose-950/10' : 'border-neutral-900'
                          }`}
                        >
                          {/* Header row */}
                          <div className="flex items-start justify-between gap-2">
                            <div>
                              <div className="flex items-center gap-2 flex-wrap">
                                <span className="text-xs font-semibold text-white">{u.name || 'Anonymous User'}</span>
                                <span
                                  className={`text-[10px] px-1.5 py-0.5 rounded font-medium ${
                                    isBanned
                                      ? 'bg-rose-950 text-rose-300 border border-rose-800/50'
                                      : 'bg-neutral-900 text-neutral-300 border border-neutral-800'
                                  }`}
                                >
                                  {isBanned ? 'BANNED' : 'ACTIVE'}
                                </span>
                                {isSuperAdmin && (
                                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-white text-black font-semibold">
                                    ADMIN
                                  </span>
                                )}
                              </div>
                              <div className="text-[11px] text-neutral-400 mt-1 flex items-center gap-1.5 flex-wrap">
                                <span className="font-mono text-neutral-500">{u.id}</span>
                                {u.email && (
                                  <>
                                    <span>•</span>
                                    <span>{u.email}</span>
                                  </>
                                )}
                                {u.mobile && (
                                  <>
                                    <span>•</span>
                                    <span>{u.mobile}</span>
                                  </>
                                )}
                              </div>
                            </div>

                            {/* Status badge / action button */}
                            <div>
                              {isSelf || isSuperAdmin ? (
                                <span className="text-[10px] px-2 py-1 rounded bg-neutral-900 text-neutral-500 border border-neutral-800">
                                  Protected
                                </span>
                              ) : isBanned ? (
                                <button
                                  onClick={() => setUnbanningUser(u)}
                                  className="px-3 py-1.5 bg-white text-black hover:bg-neutral-200 text-xs font-semibold rounded-lg transition-colors cursor-pointer flex items-center gap-1.5"
                                >
                                  <UserCheck className="w-3.5 h-3.5" />
                                  Unban
                                </button>
                              ) : (
                                <button
                                  onClick={() => {
                                    setBanningUser(u);
                                    setBanReasonInput('Violation of debate community guidelines or suspicious activity');
                                  }}
                                  className="px-3 py-1.5 bg-neutral-900 hover:bg-rose-950/50 text-rose-400 hover:text-rose-300 border border-neutral-800 hover:border-rose-900 text-xs font-medium rounded-lg transition-colors cursor-pointer flex items-center gap-1.5"
                                >
                                  <Ban className="w-3.5 h-3.5" />
                                  Ban User
                                </button>
                              )}
                            </div>
                          </div>

                          {/* Stats / Metadata Grid */}
                          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 border-t border-neutral-900 text-[11px]">
                            <div className="bg-neutral-900/60 p-2 rounded-lg border border-neutral-900">
                              <div className="text-neutral-500 text-[10px]">Created</div>
                              <div className="text-neutral-300 font-medium mt-0.5">
                                {u.createdAt
                                  ? new Date(u.createdAt).toLocaleDateString([], {
                                      month: 'short',
                                      day: 'numeric',
                                      year: 'numeric',
                                    })
                                  : 'Initial'}
                              </div>
                            </div>

                            <div className="bg-neutral-900/60 p-2 rounded-lg border border-neutral-900">
                              <div className="text-neutral-500 text-[10px]">Total Calls</div>
                              <div className="text-white font-medium mt-0.5">
                                {u.totalCallsCount !== undefined ? u.totalCallsCount : 0} calls
                              </div>
                            </div>

                            <div className="bg-neutral-900/60 p-2 rounded-lg border border-neutral-900">
                              <div className="text-neutral-500 text-[10px]">Total Earned</div>
                              <div className="text-white font-medium mt-0.5">
                                ₹{u.totalEarned !== undefined ? u.totalEarned : (u.points || 0)}
                              </div>
                            </div>

                            <div className="bg-neutral-900/60 p-2 rounded-lg border border-neutral-900">
                              <div className="text-neutral-500 text-[10px]">Referral Code</div>
                              <div className="font-mono text-neutral-300 mt-0.5">
                                {u.referralCode || 'N/A'}
                              </div>
                            </div>
                          </div>

                          {/* Ban Details if suspended */}
                          {isBanned && (
                            <div className="p-2.5 rounded-lg bg-rose-950/20 border border-rose-900/40 text-[11px] space-y-1">
                              <div className="text-rose-300 font-medium flex items-center gap-1.5">
                                <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />
                                Account Suspended
                              </div>
                              {u.banReason && (
                                <div className="text-neutral-300">
                                  <span className="text-neutral-500">Reason:</span> {u.banReason}
                                </div>
                              )}
                              {u.bannedAt && (
                                <div className="text-neutral-500 text-[10px]">
                                  Suspended on {new Date(u.bannedAt).toLocaleString()}
                                  {u.bannedByName && ` by ${u.bannedByName}`}
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}

            {/* TAB 5: FINANCIAL RECORDS */}
            {activeAdminTab === 'financials' && (
              <div className="space-y-3">
                <div className="text-xs font-medium text-neutral-400 uppercase tracking-wider">
                  Financial Records &amp; Reserve
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-neutral-950 border border-neutral-900 rounded-xl p-4">
                    <div className="text-xs text-neutral-400">Total Inflow</div>
                    <div className="text-xl font-semibold text-white mt-1">
                      ₹{ledger?.totalRevenueReceived?.toLocaleString('en-IN') || '75,000'}
                    </div>
                  </div>
                  <div className="bg-neutral-950 border border-neutral-900 rounded-xl p-4">
                    <div className="text-xs text-neutral-400">Available Reserve</div>
                    <div className="text-xl font-semibold text-white mt-1">
                      ₹{ledger?.remainingAvailableReserve?.toLocaleString('en-IN') || '60,000'}
                    </div>
                  </div>
                </div>

                <div className="bg-neutral-950 border border-neutral-900 rounded-xl p-4 space-y-2">
                  <div className="text-xs font-medium text-white">Active Inflows</div>
                  {(ledger?.fundingSources || [
                    { id: '1', sourceName: 'Platform Corporate Reserve', amount: 50000, category: 'Internal' },
                    { id: '2', sourceName: 'Research & Verification Grants', amount: 25000, category: 'External' },
                  ]).map((src: any) => (
                    <div
                      key={src.id}
                      className="flex items-center justify-between p-2 rounded-lg bg-neutral-900 border border-neutral-800 text-xs"
                    >
                      <div>
                        <div className="text-white font-medium">{src.sourceName}</div>
                        <div className="text-[10px] text-neutral-500">{src.category}</div>
                      </div>
                      <span className="font-semibold text-white">₹{src.amount.toLocaleString('en-IN')}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB 6: AUDIT LOGS */}
            {activeAdminTab === 'audits' && (
              <div className="space-y-3">
                <div className="text-xs font-medium text-neutral-400 uppercase tracking-wider">
                  Administrative Audit Logs ({auditsList.length})
                </div>

                {auditsList.length === 0 ? (
                  <div className="py-8 text-center text-xs text-neutral-500 bg-neutral-950 border border-neutral-900 rounded-xl">
                    No operator audits recorded yet.
                  </div>
                ) : (
                  <div className="space-y-2">
                    {auditsList.map((a: any) => (
                      <div
                        key={a.id || Math.random().toString()}
                        className="bg-neutral-950 border border-neutral-900 rounded-xl p-3 text-xs space-y-1.5"
                      >
                        <div className="flex items-center justify-between">
                          <span
                            className={`font-semibold uppercase text-[10px] px-1.5 py-0.5 rounded ${
                              a.action === 'USER_BANNED'
                                ? 'bg-rose-950 text-rose-300 border border-rose-900/50'
                                : a.action === 'USER_UNBANNED'
                                ? 'bg-neutral-900 text-neutral-200 border border-neutral-800'
                                : 'bg-neutral-900 text-white'
                            }`}
                          >
                            {a.action}
                          </span>
                          <span className="text-[10px] text-neutral-500">
                            {a.timestamp
                              ? new Date(a.timestamp).toLocaleString([], {
                                  month: 'short',
                                  day: 'numeric',
                                  hour: '2-digit',
                                  minute: '2-digit',
                                })
                              : 'Recent'}
                          </span>
                        </div>
                        <div className="text-[11px] text-neutral-400">
                          <span className="text-neutral-500">Admin:</span> {a.adminName || a.adminId} •{' '}
                          <span className="text-neutral-500">Target:</span> {a.targetId}
                          {a.metadata?.userEmail && ` (${a.metadata.userEmail})`}
                        </div>
                        {a.reason && (
                          <div className="text-[11px] text-neutral-300 bg-neutral-900/50 p-1.5 rounded border border-neutral-900">
                            <span className="text-neutral-500">Reason:</span> {a.reason}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </>
        )}
      </div>

      {/* BAN USER CONFIRMATION MODAL */}
      {banningUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="w-full max-w-md bg-neutral-950 border border-neutral-800 rounded-2xl p-5 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-rose-950/40 border border-rose-900/50 flex items-center justify-center">
                  <Ban className="w-4 h-4 text-rose-400" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-white">Ban this user?</h3>
                  <p className="text-[11px] text-neutral-400">
                    {banningUser.name} ({banningUser.email || banningUser.id})
                  </p>
                </div>
              </div>
              <button
                onClick={() => setBanningUser(null)}
                className="text-neutral-500 hover:text-white p-1 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-neutral-300 leading-relaxed">
              Banning this user will immediately invalidate their active sessions, disconnect any ongoing calls, and prevent them from signing in or initiating payouts.
            </p>

            <div className="space-y-1.5">
              <label className="text-[11px] font-medium text-neutral-400">
                Reason for suspension (Optional)
              </label>
              <textarea
                value={banReasonInput}
                onChange={(e) => setBanReasonInput(e.target.value)}
                placeholder="e.g. Repeated silence fraud, terms of service violation..."
                rows={3}
                className="w-full bg-neutral-900 border border-neutral-800 rounded-xl p-3 text-xs text-white placeholder:text-neutral-600 focus:outline-none focus:border-neutral-600 resize-none"
              />
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                onClick={() => setBanningUser(null)}
                disabled={isProcessingUserAction}
                className="flex-1 py-2.5 px-4 bg-neutral-900 hover:bg-neutral-800 disabled:opacity-40 text-neutral-300 text-xs font-medium rounded-xl transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleBanUser}
                disabled={isProcessingUserAction}
                className="flex-1 py-2.5 px-4 bg-rose-900 hover:bg-rose-800 disabled:opacity-40 text-white text-xs font-semibold rounded-xl transition-colors cursor-pointer"
              >
                {isProcessingUserAction ? 'Suspending...' : 'Ban User'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* UNBAN USER CONFIRMATION MODAL */}
      {unbanningUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="w-full max-w-md bg-neutral-950 border border-neutral-800 rounded-2xl p-5 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-neutral-900 border border-neutral-800 flex items-center justify-center">
                  <UserCheck className="w-4 h-4 text-white" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-white">Unban User Account?</h3>
                  <p className="text-[11px] text-neutral-400">
                    {unbanningUser.name} ({unbanningUser.email || unbanningUser.id})
                  </p>
                </div>
              </div>
              <button
                onClick={() => setUnbanningUser(null)}
                className="text-neutral-500 hover:text-white p-1 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-neutral-300 leading-relaxed">
              This will restore normal account status to <strong className="text-white">ACTIVE</strong> and allow the user to log in and participate in debate calls again.
            </p>

            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                onClick={() => setUnbanningUser(null)}
                disabled={isProcessingUserAction}
                className="flex-1 py-2.5 px-4 bg-neutral-900 hover:bg-neutral-800 disabled:opacity-40 text-neutral-300 text-xs font-medium rounded-xl transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleUnbanUser}
                disabled={isProcessingUserAction}
                className="flex-1 py-2.5 px-4 bg-white hover:bg-neutral-200 disabled:opacity-40 text-black text-xs font-semibold rounded-xl transition-colors cursor-pointer"
              >
                {isProcessingUserAction ? 'Reinstating...' : 'Confirm Unban'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* BOTTOM NAVIGATION: EXACTLY 3 ICONS (Home, Wallet, Profile) - NO TEXT LABELS */}
      <BottomNav onNavigate={onClose} activeTabOverride="profile" className="z-50" />
    </div>
  );
};
