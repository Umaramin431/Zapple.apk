import React from 'react';
import { useApp } from '../../context/AppContext';
import { AdminPanelModal } from './AdminPanelModal';

export const AdminDashboard: React.FC = () => {
  const { setCurrentTab } = useApp();
  return <AdminPanelModal isOpen={true} onClose={() => setCurrentTab('profile')} />;
};
