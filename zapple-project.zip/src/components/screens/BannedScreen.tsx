import React, { useEffect, useState } from 'react';
import { useApp, safeFetchJson } from '../../context/AppContext';
import { User } from '../../types';

interface BannedScreenProps {
  user?: User | null;
}

export const BannedScreen: React.FC<BannedScreenProps> = ({ user }) => {
  const { currentUser, logout } = useApp();
  const activeUser = user || currentUser;
  const [isChecking, setIsChecking] = useState(false);

  // Periodic check to auto-restore access if an admin unbans the account
  useEffect(() => {
    if (!activeUser?.id) return;

    const checkStatus = async () => {
      try {
        await safeFetchJson(`/api/auth/user/${activeUser.id}`);
        // If unbanned, the global AppContext sync will restore ACTIVE status
      } catch {}
    };

    const interval = setInterval(checkStatus, 3000);
    return () => clearInterval(interval);
  }, [activeUser?.id]);

  const banReason = activeUser?.banReason?.trim();

  return (
    <div
      id="screen-banned"
      className="min-h-screen w-full bg-black text-white flex flex-col justify-between p-6 sm:p-8 select-none"
    >
      {/* Top spacing */}
      <div className="w-full flex items-center justify-end">
        <button
          onClick={() => logout()}
          className="text-xs text-neutral-500 hover:text-neutral-300 transition-colors cursor-pointer py-1 px-2"
        >
          Sign Out
        </button>
      </div>

      {/* Centered Message */}
      <div className="w-full max-w-md mx-auto flex flex-col items-center justify-center text-center space-y-3 my-auto">
        <h1 className="text-xl sm:text-2xl font-semibold text-white tracking-tight">
          Your account has been banned
        </h1>

        {banReason && (
          <p className="text-sm text-neutral-400 max-w-sm leading-relaxed">
            Reason: {banReason}
          </p>
        )}
      </div>

      {/* Subtle bottom area */}
      <div className="w-full text-center text-xs text-neutral-600">
        TalkReward
      </div>
    </div>
  );
};
