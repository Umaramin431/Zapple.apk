import React, { useEffect, useState, useRef, useCallback } from 'react';
import { AlertCircle, RefreshCw } from 'lucide-react';

interface SplashScreenProps {
  onComplete: () => void;
}

type InitStage = 'detecting_network' | 'checking_server' | 'loading_treasury' | 'syncing_user' | 'finalizing' | 'ready' | 'error';

export const SplashScreen: React.FC<SplashScreenProps> = ({ onComplete }) => {
  const [progress, setProgress] = useState<number>(15);
  const [stage, setStage] = useState<InitStage>('detecting_network');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isRetrying, setIsRetrying] = useState<boolean>(false);

  const isInitializingRef = useRef<boolean>(false);
  const isCompletedRef = useRef<boolean>(false);
  const onCompleteRef = useRef(onComplete);

  useEffect(() => {
    onCompleteRef.current = onComplete;
  }, [onComplete]);

  const runStartupSequence = useCallback(async () => {
    if (isCompletedRef.current || isInitializingRef.current) return;
    isInitializingRef.current = true;
    setErrorMessage(null);
    setIsRetrying(false);

    try {
      setStage('detecting_network');
      setProgress(25);

      if (typeof navigator !== 'undefined' && !navigator.onLine) {
        throw new Error('No internet connection. Please check your network and retry.');
      }

      setStage('checking_server');
      setProgress(50);

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 3000);

      try {
        await fetch('/api/health', {
          signal: controller.signal,
          headers: { 'Cache-Control': 'no-cache' },
        });
        clearTimeout(timeoutId);
      } catch {
        clearTimeout(timeoutId);
      }

      setStage('loading_treasury');
      setProgress(75);

      try {
        const poolController = new AbortController();
        const poolTimeout = setTimeout(() => poolController.abort(), 4000);
        await fetch('/api/prize-pool/daily', { signal: poolController.signal }).catch(() => null);
        clearTimeout(poolTimeout);
      } catch {}

      setStage('finalizing');
      setProgress(100);

      await new Promise((resolve) => setTimeout(resolve, 200));

      setStage('ready');
      isCompletedRef.current = true;
      isInitializingRef.current = false;

      setTimeout(() => {
        if (onCompleteRef.current) {
          onCompleteRef.current();
        }
      }, 150);
    } catch (err: any) {
      isInitializingRef.current = false;
      setStage('error');
      setErrorMessage(err.message || 'Check your internet connection and retry.');
    }
  }, []);

  useEffect(() => {
    runStartupSequence();

    const handleOnline = () => {
      if (stage === 'error') {
        runStartupSequence();
      }
    };

    window.addEventListener('online', handleOnline);
    return () => {
      window.removeEventListener('online', handleOnline);
    };
  }, [runStartupSequence, stage]);

  const handleRetry = () => {
    setIsRetrying(true);
    setProgress(20);
    setErrorMessage(null);
    runStartupSequence();
  };

  return (
    <div
      id="zapple-splash-screen"
      className="flex flex-col items-center justify-center min-h-screen h-screen w-full bg-black text-white p-6 select-none"
    >
      <div className="w-full max-w-xs flex flex-col items-center text-center space-y-6">
        {/* Simple Brand Emblem */}
        <div className="w-16 h-16 rounded-2xl bg-white text-black font-bold text-2xl flex items-center justify-center tracking-tight shadow-sm">
          Z
        </div>

        {/* Title & Tagline */}
        <div className="space-y-1">
          <h1 className="text-xl font-bold text-white tracking-tight">Zapple</h1>
          <p className="text-xs text-neutral-400">Talk. Connect. Earn.</p>
        </div>

        {/* Minimal Progress Indicator or Error */}
        {stage !== 'error' ? (
          <div className="w-44 space-y-2 pt-2">
            <div className="w-full h-1 bg-neutral-900 rounded-full overflow-hidden">
              <div
                className="h-full bg-white transition-all duration-300 rounded-full"
                style={{ width: `${progress}%` }}
              />
            </div>
            <p className="text-[11px] text-neutral-500">Loading…</p>
          </div>
        ) : (
          <div className="w-full space-y-3 pt-2">
            <div className="p-3.5 rounded-xl bg-neutral-950 border border-neutral-800 text-xs text-neutral-300 flex items-start gap-2.5 text-left">
              <AlertCircle className="w-4 h-4 text-neutral-400 shrink-0 mt-0.5" />
              <span>{errorMessage}</span>
            </div>

            <button
              onClick={handleRetry}
              disabled={isRetrying}
              className="w-full py-2.5 px-4 rounded-xl bg-white text-black font-semibold text-xs transition-colors hover:bg-neutral-200 cursor-pointer flex items-center justify-center gap-2"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isRetrying ? 'animate-spin' : ''}`} />
              <span>Retry Connection</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
