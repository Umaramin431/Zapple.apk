import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { BrandLogo } from '../common/BrandLogo';
import {
  Eye,
  EyeOff,
  AlertCircle,
  Loader2,
  CheckCircle2,
  ShieldAlert,
  ChevronDown,
  ChevronUp,
  RefreshCw,
} from 'lucide-react';

export const AuthScreen: React.FC = () => {
  const {
    loginWithEmailPassword,
    loginWithGoogle,
    accountDeletedNotice,
    setAccountDeletedNotice,
    isEmailAuthAvailable,
    checkEmailAuthStatus,
  } = useApp();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isLoadingGoogle, setIsLoadingGoogle] = useState(false);
  const [isLoadingEmail, setIsLoadingEmail] = useState(false);
  const [showEmailFallback, setShowEmailFallback] = useState(false);
  const [isCheckingProvider, setIsCheckingProvider] = useState(false);

  const validate = (): boolean => {
    const cleanEmail = email.trim();
    if (!cleanEmail) {
      setError('Please enter your email address.');
      return false;
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(cleanEmail)) {
      setError('Please enter a valid email address (e.g. name@example.com).');
      return false;
    }
    if (!password) {
      setError('Please enter your password.');
      return false;
    }
    if (password.length < 6) {
      setError('Password must be at least 6 characters long.');
      return false;
    }
    return true;
  };

  // Primary Action when Email/Password is available or attempted:
  const handleContinue = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isLoadingEmail || isLoadingGoogle) return;

    setError(null);
    if (!validate()) return;

    setIsLoadingEmail(true);
    try {
      const result = await loginWithEmailPassword(email, password);
      if (!result.success) {
        setError(result.error || 'Authentication failed. Please check your credentials.');
      }
    } catch (err: any) {
      setError(err?.message || 'An unexpected error occurred during sign in.');
    } finally {
      setIsLoadingEmail(false);
    }
  };

  // Google Sign-In Action (Primary real provider configured in Firebase)
  const handleGoogleSignIn = async () => {
    if (isLoadingGoogle || isLoadingEmail) return;
    setError(null);
    setIsLoadingGoogle(true);

    try {
      const result = await loginWithGoogle();
      if (!result.success) {
        setError(result.error || 'Google sign-in could not be completed.');
      }
    } catch (err: any) {
      setError(err?.message || 'Failed to authenticate with Google.');
    } finally {
      setIsLoadingGoogle(false);
    }
  };

  // Manual provider check trigger
  const handleRecheckProvider = async () => {
    setIsCheckingProvider(true);
    setError(null);
    try {
      const enabled = await checkEmailAuthStatus();
      if (enabled) {
        setShowEmailFallback(true);
      } else {
        setError(
          'Email & Password authentication remains disabled in this Firebase project. The project owner must enable it in the Firebase Console (Authentication > Sign-in method).'
        );
      }
    } catch {
      setError('Failed to check Firebase authentication providers.');
    } finally {
      setIsCheckingProvider(false);
    }
  };

  return (
    <div className="min-h-screen bg-black text-white flex flex-col justify-between p-6 select-none">
      {/* Top Branding */}
      <div className="pt-8 flex flex-col items-center">
        <BrandLogo size="lg" />
      </div>

      {/* Main Authentication Card */}
      <div className="w-full max-w-sm mx-auto my-auto space-y-6">
        {accountDeletedNotice && (
          <div
            id="account-deleted-banner"
            className="p-3.5 rounded-xl bg-emerald-950/40 border border-emerald-800/60 text-emerald-300 text-xs flex items-center justify-between gap-2"
          >
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span className="font-medium">{accountDeletedNotice}</span>
            </div>
            <button
              onClick={() => setAccountDeletedNotice(null)}
              className="text-neutral-400 hover:text-white text-xs px-1 cursor-pointer"
            >
              ✕
            </button>
          </div>
        )}

        <div className="space-y-1.5 text-center">
          <h1 className="text-xl font-bold text-white tracking-tight">Sign In to Zapple</h1>
          <p className="text-xs text-neutral-400">
            Voice debate and reward platform. Continue to your account.
          </p>
        </div>

        {/* Global Error Banner */}
        {error && (
          <div
            id="auth-error-message"
            className="p-3.5 rounded-xl bg-rose-950/40 border border-rose-800/60 text-xs text-rose-200 flex items-start gap-2.5 animate-fadeIn"
          >
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
            <div className="leading-relaxed flex-1">{error}</div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* CASE 1: Email/Password provider IS enabled in Firebase Project             */}
        {/* ========================================================================= */}
        {isEmailAuthAvailable ? (
          <form onSubmit={handleContinue} className="space-y-4">
            <div className="space-y-1.5">
              <label htmlFor="email-input" className="block text-xs font-medium text-neutral-300">
                Email
              </label>
              <input
                id="email-input"
                type="email"
                autoComplete="email"
                value={email}
                onChange={(e) => {
                  setEmail(e.target.value);
                  if (error) setError(null);
                }}
                placeholder="name@example.com"
                disabled={isLoadingEmail || isLoadingGoogle}
                className="w-full h-12 px-3.5 rounded-xl bg-neutral-900 border border-neutral-800 text-white placeholder:text-neutral-500 text-sm focus:outline-none focus:border-neutral-500 transition-colors"
              />
            </div>

            <div className="space-y-1.5">
              <label htmlFor="password-input" className="block text-xs font-medium text-neutral-300">
                Password
              </label>
              <div className="relative">
                <input
                  id="password-input"
                  type={showPassword ? 'text' : 'password'}
                  autoComplete="current-password"
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    if (error) setError(null);
                  }}
                  placeholder="••••••••"
                  disabled={isLoadingEmail || isLoadingGoogle}
                  className="w-full h-12 pl-3.5 pr-11 rounded-xl bg-neutral-900 border border-neutral-800 text-white placeholder:text-neutral-500 text-sm focus:outline-none focus:border-neutral-500 transition-colors"
                />
                <button
                  type="button"
                  id="toggle-password-visibility"
                  onClick={() => setShowPassword(!showPassword)}
                  tabIndex={-1}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-white cursor-pointer transition-colors p-1"
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              id="continue-button"
              type="submit"
              disabled={isLoadingEmail || isLoadingGoogle || !email.trim() || !password}
              className="w-full h-12 rounded-xl bg-white text-black font-semibold text-sm hover:bg-neutral-200 active:scale-[0.99] disabled:opacity-50 disabled:pointer-events-none flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              {isLoadingEmail ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin text-black" />
                  <span>Continuing...</span>
                </>
              ) : (
                <span>Continue</span>
              )}
            </button>

            <div className="flex items-center gap-3 my-1">
              <div className="flex-1 h-px bg-neutral-900" />
              <span className="text-[11px] text-neutral-500 uppercase tracking-wider">or</span>
              <div className="flex-1 h-px bg-neutral-900" />
            </div>

            <button
              id="google-signin-button"
              type="button"
              onClick={handleGoogleSignIn}
              disabled={isLoadingGoogle || isLoadingEmail}
              className="w-full h-12 rounded-xl bg-neutral-900 hover:bg-neutral-800 active:scale-[0.99] border border-neutral-800 text-white font-medium text-sm disabled:opacity-50 flex items-center justify-center gap-3 transition-colors cursor-pointer"
            >
              {isLoadingGoogle ? (
                <Loader2 className="w-4 h-4 animate-spin text-white" />
              ) : (
                <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                  <path
                    fill="#EA4335"
                    d="M12 5c1.6 0 3 .6 4.1 1.6l3.1-3.1C17.3 1.7 14.8 1 12 1 7.5 1 3.7 3.6 1.9 7.3l3.7 2.9C6.5 7.3 8.9 5 12 5z"
                  />
                  <path
                    fill="#4285F4"
                    d="M23.5 12.3c0-.8-.1-1.6-.2-2.3H12v4.5h6.5c-.3 1.5-1.1 2.8-2.4 3.7l3.7 2.9c2.2-2 3.7-5 3.7-8.8z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.6 14.8c-.2-.7-.4-1.5-.4-2.3 0-.8.2-1.6.4-2.3L1.9 7.3C.7 9.7 0 12.3 0 15.2s.7 5.5 1.9 7.9l3.7-2.9z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 23.5c3.2 0 6-1.1 8-3l-3.7-2.9c-1.1.7-2.5 1.2-4.3 1.2-3.1 0-5.5-2.1-6.4-5.2L1.9 16.5C3.7 20.2 7.5 23.5 12 23.5z"
                  />
                </svg>
              )}
              <span>Continue with Google</span>
            </button>
          </form>
        ) : (
          /* ========================================================================= */
          /* CASE 2: Email/Password provider is NOT enabled in Firebase Project        */
          /* Google is the primary enabled authentication method                        */
          /* ========================================================================= */
          <div className="space-y-4">
            {/* Primary Action: Google Sign-In */}
            <button
              id="google-signin-button"
              type="button"
              onClick={handleGoogleSignIn}
              disabled={isLoadingGoogle || isLoadingEmail}
              className="w-full h-12 rounded-xl bg-white text-black font-semibold text-sm hover:bg-neutral-200 active:scale-[0.99] disabled:opacity-50 flex items-center justify-center gap-3 transition-all cursor-pointer shadow-sm"
            >
              {isLoadingGoogle ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin text-black" />
                  <span>Connecting with Google...</span>
                </>
              ) : (
                <>
                  <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24">
                    <path
                      fill="#EA4335"
                      d="M12 5c1.6 0 3 .6 4.1 1.6l3.1-3.1C17.3 1.7 14.8 1 12 1 7.5 1 3.7 3.6 1.9 7.3l3.7 2.9C6.5 7.3 8.9 5 12 5z"
                    />
                    <path
                      fill="#4285F4"
                      d="M23.5 12.3c0-.8-.1-1.6-.2-2.3H12v4.5h6.5c-.3 1.5-1.1 2.8-2.4 3.7l3.7 2.9c2.2-2 3.7-5 3.7-8.8z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.6 14.8c-.2-.7-.4-1.5-.4-2.3 0-.8.2-1.6.4-2.3L1.9 7.3C.7 9.7 0 12.3 0 15.2s.7 5.5 1.9 7.9l3.7-2.9z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 23.5c3.2 0 6-1.1 8-3l-3.7-2.9c-1.1.7-2.5 1.2-4.3 1.2-3.1 0-5.5-2.1-6.4-5.2L1.9 16.5C3.7 20.2 7.5 23.5 12 23.5z"
                    />
                  </svg>
                  <span>Continue with Google</span>
                </>
              )}
            </button>

            {/* Clear Requirement 4 Notice: Email/Password must be enabled by project owner */}
            <div className="p-4 rounded-xl bg-neutral-900/90 border border-neutral-800 text-xs space-y-2">
              <div className="flex items-center gap-2 font-medium text-amber-400">
                <ShieldAlert className="w-4 h-4 shrink-0 text-amber-400" />
                <span>Email/Password Provider Disabled</span>
              </div>
              <p className="leading-relaxed text-neutral-300">
                Email/Password authentication must be enabled by the Firebase project owner in the Firebase Console under{' '}
                <span className="text-white font-mono text-[11px] bg-neutral-800 px-1 py-0.5 rounded">
                  Authentication &gt; Sign-in method
                </span>
                .
              </p>
              <p className="text-neutral-400 leading-relaxed">
                Google Sign-In is active and ready. Please use the button above to proceed securely.
              </p>
            </div>

            {/* Expandable toggle for Email + Password options / verification */}
            <div className="pt-1">
              <button
                type="button"
                onClick={() => setShowEmailFallback(!showEmailFallback)}
                className="w-full flex items-center justify-between text-xs text-neutral-400 hover:text-neutral-200 transition-colors py-1.5 cursor-pointer"
              >
                <span>Need Email & Password Sign-In?</span>
                {showEmailFallback ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
              </button>

              {showEmailFallback && (
                <div className="mt-3 p-3.5 rounded-xl bg-neutral-950 border border-neutral-800/80 space-y-3.5 animate-fadeIn">
                  <div className="text-[11px] text-neutral-400 leading-relaxed flex items-start gap-2">
                    <AlertCircle className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                    <span>
                      Because the connected Firebase project currently only has Google sign-in active, submitting with
                      email/password will fail until the Firebase project owner enables it.
                    </span>
                  </div>

                  <form onSubmit={handleContinue} className="space-y-3">
                    <div className="space-y-1">
                      <label htmlFor="email-input" className="block text-[11px] font-medium text-neutral-400">
                        Email Address
                      </label>
                      <input
                        id="email-input"
                        type="email"
                        autoComplete="email"
                        value={email}
                        onChange={(e) => {
                          setEmail(e.target.value);
                          if (error) setError(null);
                        }}
                        placeholder="name@example.com"
                        disabled={isLoadingEmail || isLoadingGoogle}
                        className="w-full h-10 px-3 rounded-lg bg-neutral-900 border border-neutral-800 text-white placeholder:text-neutral-600 text-xs focus:outline-none focus:border-neutral-600"
                      />
                    </div>

                    <div className="space-y-1">
                      <label htmlFor="password-input" className="block text-[11px] font-medium text-neutral-400">
                        Password
                      </label>
                      <div className="relative">
                        <input
                          id="password-input"
                          type={showPassword ? 'text' : 'password'}
                          autoComplete="current-password"
                          value={password}
                          onChange={(e) => {
                            setPassword(e.target.value);
                            if (error) setError(null);
                          }}
                          placeholder="••••••••"
                          disabled={isLoadingEmail || isLoadingGoogle}
                          className="w-full h-10 pl-3 pr-9 rounded-lg bg-neutral-900 border border-neutral-800 text-white placeholder:text-neutral-600 text-xs focus:outline-none focus:border-neutral-600"
                        />
                        <button
                          type="button"
                          id="toggle-password-visibility"
                          onClick={() => setShowPassword(!showPassword)}
                          tabIndex={-1}
                          className="absolute right-2.5 top-1/2 -translate-y-1/2 text-neutral-500 hover:text-neutral-300 p-1 cursor-pointer"
                        >
                          {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                    </div>

                    <div className="flex gap-2 pt-1">
                      <button
                        id="continue-button"
                        type="submit"
                        disabled={isLoadingEmail || isLoadingGoogle || !email.trim() || !password}
                        className="flex-1 h-10 rounded-lg bg-neutral-800 text-white font-medium text-xs hover:bg-neutral-700 disabled:opacity-50 flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                      >
                        {isLoadingEmail ? (
                          <>
                            <Loader2 className="w-3.5 h-3.5 animate-spin" />
                            <span>Verifying...</span>
                          </>
                        ) : (
                          <span>Submit Email & Password</span>
                        )}
                      </button>

                      <button
                        type="button"
                        onClick={handleRecheckProvider}
                        disabled={isCheckingProvider}
                        title="Recheck if Firebase project owner has enabled Email/Password"
                        className="h-10 px-3 rounded-lg bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-neutral-300 text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                      >
                        <RefreshCw className={`w-3.5 h-3.5 ${isCheckingProvider ? 'animate-spin' : ''}`} />
                        <span>Check Status</span>
                      </button>
                    </div>
                  </form>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Footer info */}
      <div className="text-center py-4">
        <p className="text-[11px] text-neutral-500 max-w-xs mx-auto leading-relaxed">
          Zapple Voice Debate & Reward Platform
        </p>
      </div>
    </div>
  );
};
