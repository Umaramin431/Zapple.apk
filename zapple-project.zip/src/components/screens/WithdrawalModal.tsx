import React, { useState } from 'react';
import { motion } from 'motion/react';
import { useApp } from '../../context/AppContext';
import {
  X,
  ShieldAlert,
  AlertTriangle,
  ArrowRight,
  Coins,
  CheckCircle2,
  Building,
  Smartphone,
  Gift,
} from 'lucide-react';

interface WithdrawalModalProps {
  onClose: () => void;
}

export const WithdrawalModal: React.FC<WithdrawalModalProps> = ({ onClose }) => {
  const { wallet, requestDemoWithdrawal, setActiveRole, setCurrentTab } = useApp();

  const [amount, setAmount] = useState<number>(20);
  const [paymentMethod, setPaymentMethod] = useState<'UPI' | 'Bank Transfer' | 'Demo Gift Card'>('UPI');
  const [accountDetails, setAccountDetails] = useState('tester@upi.demo');
  const [statusMessage, setStatusMessage] = useState<{ type: 'error' | 'success'; text: string } | null>(null);

  const quickAmounts = [10, 20, 50, 100];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStatusMessage(null);

    const result = requestDemoWithdrawal(amount, paymentMethod, accountDetails);

    if (result.success) {
      setStatusMessage({ type: 'success', text: result.message });
    } else {
      setStatusMessage({ type: 'error', text: result.message });
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-xs p-0 sm:p-4">
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: 50 }}
        className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-3xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden border border-slate-200 dark:border-slate-800"
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white leading-tight">
                Simulated Demo Withdrawal
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                UI Testing sandbox only — No real money
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {/* Mandatory Prominent Warning Banner */}
          <div className="p-3.5 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-800/60 flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
            <div className="text-xs text-amber-900 dark:text-amber-200 space-y-1">
              <strong className="font-bold block">
                Demo Mode: Real withdrawals are disabled.
              </strong>
              <p className="text-[11px] leading-relaxed opacity-90">
                Submitting this request creates a simulated withdrawal record. No banking or payment gateway is contacted, and no real fiat funds are transferred.
              </p>
            </div>
          </div>

          {statusMessage?.type === 'success' ? (
            <div className="py-6 text-center space-y-4">
              <div className="w-14 h-14 mx-auto rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <div className="space-y-1">
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  Demo Withdrawal Request Logged!
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 max-w-sm mx-auto">
                  ₹{amount} was deducted from your demo balance. You can approve or reject this request anytime inside the Admin Dashboard.
                </p>
              </div>

              <div className="pt-2 flex flex-col gap-2">
                <button
                  id="view-in-admin-btn"
                  onClick={() => {
                    setActiveRole('admin');
                    setCurrentTab('admin');
                    onClose();
                  }}
                  className="w-full py-2.5 px-4 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold transition-all shadow-md flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  Review in Admin Dashboard <ArrowRight className="w-4 h-4" />
                </button>
                <button
                  onClick={onClose}
                  className="w-full py-2 px-4 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-semibold hover:bg-slate-200 transition-colors cursor-pointer"
                >
                  Done
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Available balance summary */}
              <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/60 dark:border-slate-700/60">
                <span className="text-xs text-slate-500 font-medium">Available Demo Balance:</span>
                <span className="text-sm font-bold font-mono text-emerald-600 dark:text-emerald-400">
                  ₹{wallet.demoBalance}
                </span>
              </div>

              {/* Amount Field */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  Withdrawal Amount (₹ Virtual Rupee)
                </label>
                <div className="relative">
                  <Coins className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    id="withdraw-amount-input"
                    type="number"
                    min={1}
                    max={wallet.demoBalance}
                    value={amount}
                    onChange={(e) => setAmount(Number(e.target.value))}
                    className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white text-sm font-mono font-bold focus:outline-none focus:border-emerald-500"
                  />
                </div>

                {/* Quick Chips */}
                <div className="flex items-center gap-2 mt-2">
                  {quickAmounts.map((q) => (
                    <button
                      key={q}
                      type="button"
                      onClick={() => setAmount(q)}
                      className={`px-2.5 py-1 rounded-lg text-xs font-semibold font-mono transition-colors cursor-pointer ${
                        amount === q
                          ? 'bg-emerald-600 text-white'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
                      }`}
                    >
                      ₹{q}
                    </button>
                  ))}
                  <button
                    type="button"
                    onClick={() => setAmount(wallet.demoBalance)}
                    className="px-2.5 py-1 rounded-lg text-[11px] font-semibold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 hover:bg-emerald-100 transition-colors cursor-pointer ml-auto"
                  >
                    Max
                  </button>
                </div>
              </div>

              {/* Payment Method Selector */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  Simulated Payment Method
                </label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setPaymentMethod('UPI');
                      setAccountDetails('tester@upi.demo');
                    }}
                    className={`p-2.5 rounded-xl border text-xs font-semibold flex flex-col items-center gap-1 transition-all cursor-pointer ${
                      paymentMethod === 'UPI'
                        ? 'border-emerald-500 bg-emerald-50/60 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 shadow-xs'
                        : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800/40 text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    <Smartphone className="w-4 h-4" />
                    <span>UPI ID</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setPaymentMethod('Bank Transfer');
                      setAccountDetails('A/C: 9876543210 (IFSC: DEMO0001)');
                    }}
                    className={`p-2.5 rounded-xl border text-xs font-semibold flex flex-col items-center gap-1 transition-all cursor-pointer ${
                      paymentMethod === 'Bank Transfer'
                        ? 'border-emerald-500 bg-emerald-50/60 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 shadow-xs'
                        : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800/40 text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    <Building className="w-4 h-4" />
                    <span>Bank Transfer</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setPaymentMethod('Demo Gift Card');
                      setAccountDetails('voucher-demo-recipient@example.com');
                    }}
                    className={`p-2.5 rounded-xl border text-xs font-semibold flex flex-col items-center gap-1 transition-all cursor-pointer ${
                      paymentMethod === 'Demo Gift Card'
                        ? 'border-emerald-500 bg-emerald-50/60 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 shadow-xs'
                        : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800/40 text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    <Gift className="w-4 h-4" />
                    <span>Gift Voucher</span>
                  </button>
                </div>
              </div>

              {/* Account/UPI Placeholder */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  {paymentMethod === 'UPI'
                    ? 'UPI ID Placeholder'
                    : paymentMethod === 'Bank Transfer'
                    ? 'Bank Account & IFSC Placeholder'
                    : 'Recipient Email for Demo Voucher'}
                </label>
                <input
                  id="withdraw-account-input"
                  type="text"
                  required
                  value={accountDetails}
                  onChange={(e) => setAccountDetails(e.target.value)}
                  placeholder={
                    paymentMethod === 'UPI'
                      ? 'username@bank.demo'
                      : paymentMethod === 'Bank Transfer'
                      ? 'Account Number, IFSC'
                      : 'email@example.com'
                  }
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white text-xs font-medium focus:outline-none focus:border-emerald-500"
                />
              </div>

              {statusMessage?.type === 'error' && (
                <p className="text-xs text-rose-500 font-medium bg-rose-50 dark:bg-rose-950/40 p-2.5 rounded-xl border border-rose-200">
                  {statusMessage.text}
                </p>
              )}

              {/* Action Button */}
              <button
                id="submit-demo-withdraw-btn"
                type="submit"
                className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:scale-[0.98] text-white text-sm font-semibold shadow-md shadow-emerald-600/20 flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                Request Demo Withdrawal
              </button>
            </form>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50 flex items-center justify-between">
          <span className="text-[11px] text-slate-400">
            Simulated Sandbox Environment
          </span>
          <button
            onClick={onClose}
            className="text-xs font-semibold text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 cursor-pointer"
          >
            Cancel
          </button>
        </div>
      </motion.div>
    </div>
  );
};
