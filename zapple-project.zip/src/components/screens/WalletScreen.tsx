import React from 'react';
import { EarningsScreen } from './EarningsScreen';

export const WalletScreen: React.FC = () => {
  return <EarningsScreen />;
};
