import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useApp } from '../../context/AppContext';
import { copyToClipboard } from '../../utils/clipboard';
import { AdminPanelModal } from '../admin/AdminPanelModal';
import {
  ChevronRight,
  Copy,
  Check,
  X,
  Share2,
  AlertTriangle,
  HelpCircle,
  Shield,
  FileText,
  MessageSquare,
  LogOut,
  Trash2,
  Lock,
  Loader2,
} from 'lucide-react';

export const ProfileScreen: React.FC = () => {
  const {
    currentUser,
    wallet,
    logout,
    deleteAccount,
    reauthenticateGoogleAndDelete,
    updateUserProfile,
    paymentDetails,
    transactions,
    userCalls,
  } = useApp();

  // State for modals
  const [isEditing, setIsEditing] = useState(false);
  const [editName, setEditName] = useState(currentUser?.name || 'Debater');
  const [editMobile, setEditMobile] = useState(currentUser?.mobile || currentUser?.email || '');

  const [showReferralModal, setShowReferralModal] = useState(false);
  const [referralCopied, setReferralCopied] = useState(false);

  const [showHowYouGetPaidModal, setShowHowYouGetPaidModal] = useState(false);
  const [showSupportModal, setShowSupportModal] = useState(false);
  const [ticketSubject, setTicketSubject] = useState('');
  const [ticketMessage, setTicketMessage] = useState('');
  const [ticketStatus, setTicketStatus] = useState<string | null>(null);

  const [showTermsModal, setShowTermsModal] = useState(false);
  const [showPrivacyModal, setShowPrivacyModal] = useState(false);
  const [showDeleteConfirmModal, setShowDeleteConfirmModal] = useState(false);
  const [showReauthModal, setShowReauthModal] = useState(false);
  const [reauthProvider, setReauthProvider] = useState<'password' | 'google.com'>('password');
  const [reauthPassword, setReauthPassword] = useState('');
  const [isDeleting, setIsDeleting] = useState(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);
  const [showAdminModal, setShowAdminModal] = useState(false);

  const [exportNotice, setExportNotice] = useState(false);

  // Edit profile submit
  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editName.trim()) return;
    updateUserProfile(editName.trim(), editMobile.trim());
    setIsEditing(false);
  };

  // Export my data (real JSON download)
  const handleExportData = () => {
    const exportPayload = {
      exportedAt: new Date().toISOString(),
      account: {
        id: currentUser?.id,
        name: currentUser?.name || 'UMAR AMIN',
        mobile: currentUser?.mobile,
        role: currentUser?.role,
        referralCode: currentUser?.referralCode,
        createdAt: currentUser?.createdAt,
      },
      wallet: {
        totalEarned: wallet.totalEarned,
        currentBalance: wallet.currentBalance,
        pendingBalance: wallet.pendingBalance,
        paidOutTotal: wallet.paidOutTotal,
      },
      payoutDestination: paymentDetails,
      transactions: transactions.filter((t) => t.userId === currentUser?.id),
      callHistory: userCalls,
    };

    const dataBlob = new Blob([JSON.stringify(exportPayload, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `zapple_user_data_${currentUser?.id || 'account'}_${Date.now()}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    setExportNotice(true);
    setTimeout(() => setExportNotice(false), 3000);
  };

  // Copy referral code
  const handleCopyReferral = async () => {
    const code = currentUser?.referralCode || 'ZAPPLE-USER';
    await copyToClipboard(code);
    setReferralCopied(true);
    setTimeout(() => setReferralCopied(false), 2000);
  };

  // Share referral code
  const handleShareReferral = async () => {
    const code = currentUser?.referralCode || 'ZAPPLE-USER';
    const shareText = `Join me on Zapple! Earn up to ₹150 for participating in voice calls. Use my code: ${code}`;
    if (navigator.share && navigator.canShare && navigator.canShare({ text: shareText })) {
      try {
        await navigator.share({
          title: 'Refer a Friend - Zapple',
          text: shareText,
        });
        return;
      } catch {}
    }
    await copyToClipboard(shareText);
    setReferralCopied(true);
    setTimeout(() => setReferralCopied(false), 2000);
  };

  // Submit problem report
  const handleSubmitTicket = (e: React.FormEvent) => {
    e.preventDefault();
    if (!ticketSubject.trim() || !ticketMessage.trim()) return;
    setTicketStatus('Thank you. Your report has been submitted to support.');
    setTimeout(() => {
      setTicketSubject('');
      setTicketMessage('');
      setTicketStatus(null);
      setShowSupportModal(false);
    }, 1800);
  };

  // Confirm delete account
  const handleConfirmDeleteAccount = async () => {
    setIsDeleting(true);
    setDeleteError(null);
    try {
      const res = await deleteAccount();
      if (res.success) {
        setShowDeleteConfirmModal(false);
      } else if (res.requiresReauth) {
        setShowDeleteConfirmModal(false);
        setReauthProvider(res.authProvider || 'password');
        setDeleteError(null);
        setShowReauthModal(true);
      } else {
        setDeleteError(res.error || 'Failed to delete account. Please try again.');
      }
    } catch (err: any) {
      setDeleteError(err?.message || 'An unexpected error occurred during account deletion.');
    } finally {
      setIsDeleting(false);
    }
  };

  // Submit password for re-authentication
  const handleReauthPasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reauthPassword.trim()) {
      setDeleteError('Please enter your password.');
      return;
    }
    setIsDeleting(true);
    setDeleteError(null);
    try {
      const res = await deleteAccount(reauthPassword.trim());
      if (res.success) {
        setShowReauthModal(false);
        setReauthPassword('');
      } else {
        setDeleteError(res.error || 'Re-authentication failed. Please check your credentials.');
      }
    } catch (err: any) {
      setDeleteError(err?.message || 'Failed to re-authenticate.');
    } finally {
      setIsDeleting(false);
    }
  };

  // Submit Google re-authentication
  const handleReauthGoogleSubmit = async () => {
    setIsDeleting(true);
    setDeleteError(null);
    try {
      const res = await reauthenticateGoogleAndDelete();
      if (res.success) {
        setShowReauthModal(false);
      } else {
        setDeleteError(res.error || 'Google re-authentication failed.');
      }
    } catch (err: any) {
      setDeleteError(err?.message || 'Failed to re-authenticate with Google.');
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <div className="min-h-screen bg-black text-white flex flex-col">
      <div className="flex-1 px-4 pt-6 pb-28 space-y-6 max-w-md mx-auto w-full">
        {/* Export notification banner */}
        <AnimatePresence>
          {exportNotice && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="p-3 bg-neutral-900 border border-neutral-800 rounded-xl text-xs text-neutral-300 flex items-center justify-between"
            >
              <span>Your data file has been downloaded.</span>
              <button
                onClick={() => setExportNotice(false)}
                className="text-neutral-500 hover:text-white"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        {/* SECTION 1: ACCOUNT */}
        <div className="space-y-3">
          <div className="text-xs font-medium text-neutral-400 uppercase tracking-wider px-1">
            ACCOUNT
          </div>

          <div className="space-y-2">
            {/* User Profile Card */}
            <div
              id="card-user-profile"
              className="bg-neutral-950 border border-neutral-900 rounded-xl p-4 flex items-center justify-between"
            >
              <div className="space-y-0.5 min-w-0 pr-3">
                <div className="text-base font-semibold text-white tracking-tight truncate">
                  {currentUser?.name || 'Debater'}
                </div>
                <div className="text-xs text-neutral-400 truncate">
                  {currentUser?.email || currentUser?.mobile || 'user@example.com'}
                </div>
              </div>
              <button
                id="btn-edit-profile"
                onClick={() => {
                  setEditName(currentUser?.name || 'Debater');
                  setEditMobile(currentUser?.mobile || currentUser?.email || '');
                  setIsEditing(true);
                }}
                className="px-3 py-1.5 rounded-lg bg-neutral-900 hover:bg-neutral-800 active:scale-[0.99] text-neutral-200 hover:text-white border border-neutral-800 text-xs font-medium transition-colors cursor-pointer shrink-0"
              >
                Edit Profile
              </button>
            </div>

            {/* Export My Data */}
            <button
              id="btn-export-my-data"
              onClick={handleExportData}
              className="w-full bg-neutral-950 hover:bg-neutral-900 active:scale-[0.99] border border-neutral-900 rounded-xl p-3.5 flex items-center justify-between text-left transition-colors cursor-pointer"
            >
              <div className="space-y-0.5">
                <div className="text-sm font-medium text-white">Export My Data</div>
                <div className="text-xs text-neutral-500">
                  Download personal account, wallet, and call logs (JSON)
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-neutral-500 shrink-0" />
            </button>

            {/* Refer a Friend (Up to ₹150) */}
            <button
              id="btn-refer-a-friend"
              onClick={() => setShowReferralModal(true)}
              className="w-full bg-neutral-950 hover:bg-neutral-900 active:scale-[0.99] border border-neutral-900 rounded-xl p-3.5 flex items-center justify-between text-left transition-colors cursor-pointer"
            >
              <div className="space-y-0.5">
                <div className="text-sm font-medium text-white">Refer a Friend</div>
                <div className="text-xs text-neutral-400">Up to ₹150</div>
              </div>
              <ChevronRight className="w-4 h-4 text-neutral-500 shrink-0" />
            </button>
          </div>
        </div>

        {/* SECTION 2: SUPPORT & LEGAL */}
        <div className="space-y-3">
          <div className="text-xs font-medium text-neutral-400 uppercase tracking-wider px-1">
            SUPPORT & LEGAL
          </div>

          <div className="space-y-2">
            {/* How You Get Paid */}
            <button
              id="btn-how-you-get-paid"
              onClick={() => setShowHowYouGetPaidModal(true)}
              className="w-full bg-neutral-950 hover:bg-neutral-900 active:scale-[0.99] border border-neutral-900 rounded-xl p-3.5 flex items-center justify-between text-left transition-colors cursor-pointer"
            >
              <div className="space-y-0.5">
                <div className="text-sm font-medium text-white">How You Get Paid</div>
                <div className="text-xs text-neutral-500">
                  7-day holding period, automatic withdrawals & UPI/Bank payouts
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-neutral-500 shrink-0" />
            </button>

            {/* Report a Problem */}
            <button
              id="btn-report-a-problem"
              onClick={() => setShowSupportModal(true)}
              className="w-full bg-neutral-950 hover:bg-neutral-900 active:scale-[0.99] border border-neutral-900 rounded-xl p-3.5 flex items-center justify-between text-left transition-colors cursor-pointer"
            >
              <div className="space-y-0.5">
                <div className="text-sm font-medium text-white">Report a Problem</div>
                <div className="text-xs text-neutral-500">
                  Contact support or report call & payment issues
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-neutral-500 shrink-0" />
            </button>

            {/* Terms of Service */}
            <button
              id="btn-terms-of-service"
              onClick={() => setShowTermsModal(true)}
              className="w-full bg-neutral-950 hover:bg-neutral-900 active:scale-[0.99] border border-neutral-900 rounded-xl p-3.5 flex items-center justify-between text-left transition-colors cursor-pointer"
            >
              <div className="space-y-0.5">
                <div className="text-sm font-medium text-white">Terms of Service</div>
                <div className="text-xs text-neutral-500">
                  Rules of participation, call duration & reward eligibility
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-neutral-500 shrink-0" />
            </button>

            {/* Privacy Policy */}
            <button
              id="btn-privacy-policy"
              onClick={() => setShowPrivacyModal(true)}
              className="w-full bg-neutral-950 hover:bg-neutral-900 active:scale-[0.99] border border-neutral-900 rounded-xl p-3.5 flex items-center justify-between text-left transition-colors cursor-pointer"
            >
              <div className="space-y-0.5">
                <div className="text-sm font-medium text-white">Privacy Policy</div>
                <div className="text-xs text-neutral-500">
                  Data handling, audio privacy & encryption policies
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-neutral-500 shrink-0" />
            </button>

            {/* Sign Out */}
            <button
              id="btn-sign-out"
              onClick={logout}
              className="w-full bg-neutral-950 hover:bg-neutral-900 active:scale-[0.99] border border-neutral-900 rounded-xl p-3.5 flex items-center justify-between text-left transition-colors cursor-pointer"
            >
              <div className="text-sm font-medium text-neutral-200">Sign Out</div>
              <ChevronRight className="w-4 h-4 text-neutral-500 shrink-0" />
            </button>

            {/* Delete My Account */}
            <button
              id="btn-delete-my-account"
              onClick={() => setShowDeleteConfirmModal(true)}
              className="w-full bg-neutral-950 hover:bg-neutral-900 active:scale-[0.99] border border-neutral-900 rounded-xl p-3.5 flex items-center justify-between text-left transition-colors cursor-pointer"
            >
              <div className="space-y-0.5">
                <div className="text-sm font-medium text-rose-400">Delete My Account</div>
                <div className="text-xs text-neutral-500">
                  Permanently remove account data and active session
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-rose-500/50 shrink-0" />
            </button>
          </div>
        </div>

        {/* ADMIN DASHBOARD (Only shown to Admin users) */}
        {currentUser?.role === 'admin' && (
          <div className="space-y-3 pt-2">
            <div className="text-xs font-medium text-neutral-400 uppercase tracking-wider px-1">
              ADMINISTRATION
            </div>
            <button
              id="btn-admin-dashboard"
              onClick={() => setShowAdminModal(true)}
              className="w-full bg-neutral-950 hover:bg-neutral-900 active:scale-[0.99] border border-neutral-900 rounded-xl p-3.5 flex items-center justify-between text-left transition-colors cursor-pointer"
            >
              <div className="space-y-0.5">
                <div className="text-sm font-medium text-white flex items-center gap-2">
                  <span>Admin Management Panel</span>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-neutral-800 text-neutral-300 font-medium">
                    ADMIN
                  </span>
                </div>
                <div className="text-xs text-neutral-500">
                  Prize pool control, call approval review & withdrawal audits
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-neutral-500 shrink-0" />
            </button>
          </div>
        )}
      </div>

      {/* Modal: Edit Profile */}
      <AnimatePresence>
        {isEditing && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-sm bg-neutral-950 border border-neutral-900 rounded-2xl p-5 space-y-4"
            >
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-semibold text-white">Edit Profile</h3>
                <button
                  onClick={() => setIsEditing(false)}
                  className="p-1 rounded-lg text-neutral-500 hover:text-white transition-colors cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <form onSubmit={handleSaveProfile} className="space-y-3">
                <div>
                  <label className="block text-xs font-medium text-neutral-400 mb-1">
                    Full Name
                  </label>
                  <input
                    type="text"
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    placeholder="Enter full name"
                    className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white placeholder-neutral-600 focus:outline-hidden focus:border-neutral-600"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-neutral-400 mb-1">
                    Mobile Number
                  </label>
                  <input
                    type="text"
                    value={editMobile}
                    onChange={(e) => setEditMobile(e.target.value)}
                    placeholder="e.g. +91 98765 43210"
                    className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white placeholder-neutral-600 focus:outline-hidden focus:border-neutral-600"
                  />
                </div>

                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setIsEditing(false)}
                    className="flex-1 py-2.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 active:scale-[0.99] text-neutral-300 font-medium text-xs transition-colors cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-2.5 rounded-xl bg-white hover:bg-neutral-200 active:scale-[0.99] text-black font-semibold text-xs transition-colors cursor-pointer"
                  >
                    Save Changes
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Modal: Refer a Friend (Up to ₹150) */}
      <AnimatePresence>
        {showReferralModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-sm bg-neutral-950 border border-neutral-900 rounded-2xl p-5 space-y-4"
            >
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-semibold text-white">Refer a Friend</h3>
                  <p className="text-xs text-neutral-400 mt-0.5">
                    Earn up to ₹150 when friends complete calls
                  </p>
                </div>
                <button
                  onClick={() => setShowReferralModal(false)}
                  className="p-1 rounded-lg text-neutral-500 hover:text-white transition-colors cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-3.5 space-y-2">
                <div className="text-xs text-neutral-400">Your Referral Code</div>
                <div className="text-lg font-mono font-semibold text-white tracking-wider">
                  {currentUser?.referralCode || 'ZAPPLE-USER'}
                </div>
              </div>

              <div className="space-y-1.5 text-xs text-neutral-400 leading-relaxed">
                <p>• Share your code with friends who want to discuss real-world topics.</p>
                <p>• When your friend verifies eligible 3-minute calls, you receive referral rewards.</p>
                <p>• Earn up to ₹150 total in referral rewards.</p>
              </div>

              <div className="flex gap-2 pt-1">
                <button
                  onClick={handleCopyReferral}
                  className="flex-1 py-2.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 active:scale-[0.99] text-white border border-neutral-800 font-medium text-xs transition-colors cursor-pointer flex items-center justify-center gap-1.5"
                >
                  {referralCopied ? <Check className="w-3.5 h-3.5 text-white" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{referralCopied ? 'Copied' : 'Copy Code'}</span>
                </button>
                <button
                  onClick={handleShareReferral}
                  className="flex-1 py-2.5 rounded-xl bg-white hover:bg-neutral-200 active:scale-[0.99] text-black font-semibold text-xs transition-colors cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <Share2 className="w-3.5 h-3.5" />
                  <span>Share</span>
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Modal: How You Get Paid */}
      <AnimatePresence>
        {showHowYouGetPaidModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-sm bg-neutral-950 border border-neutral-900 rounded-2xl p-5 space-y-4 max-h-[85vh] flex flex-col"
            >
              <div className="flex items-center justify-between border-b border-neutral-900 pb-3">
                <h3 className="text-sm font-semibold text-white">How You Get Paid</h3>
                <button
                  onClick={() => setShowHowYouGetPaidModal(false)}
                  className="p-1 rounded-lg text-neutral-500 hover:text-white transition-colors cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="space-y-3 overflow-y-auto text-xs text-neutral-300 leading-relaxed pr-1">
                <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-3 space-y-1">
                  <div className="font-semibold text-white">1. Verified ₹20 Call Rewards</div>
                  <p className="text-neutral-400">
                    Both participants receive ₹20 each when a call meets the 3-minute requirement,
                    passes active speaking verification (20s minimum), and is confirmed genuine.
                  </p>
                </div>

                <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-3 space-y-1">
                  <div className="font-semibold text-white">2. 7-Day Holding Period</div>
                  <p className="text-neutral-400">
                    Rewards enter a mandatory 7-day holding period to protect the prize pool from
                    fraudulent or automated activity.
                  </p>
                </div>

                <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-3 space-y-1">
                  <div className="font-semibold text-white">3. Automatic Withdrawal Queue</div>
                  <p className="text-neutral-400">
                    After 7 days, an automatic withdrawal request is generated and placed into Pending.
                    No manual withdrawal button is needed.
                  </p>
                </div>

                <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-3 space-y-1">
                  <div className="font-semibold text-white">4. Direct UPI & Bank Transfer</div>
                  <p className="text-neutral-400">
                    Once approved by admin supervisors, disbursements are sent directly to your
                    registered UPI ID or bank account with an official reference UTR.
                  </p>
                </div>
              </div>

              <button
                onClick={() => setShowHowYouGetPaidModal(false)}
                className="w-full py-2.5 rounded-xl bg-white hover:bg-neutral-200 active:scale-[0.99] text-black font-semibold text-xs transition-colors cursor-pointer"
              >
                Close
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Modal: Report a Problem */}
      <AnimatePresence>
        {showSupportModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-sm bg-neutral-950 border border-neutral-900 rounded-2xl p-5 space-y-4"
            >
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-semibold text-white">Report a Problem</h3>
                <button
                  onClick={() => setShowSupportModal(false)}
                  className="p-1 rounded-lg text-neutral-500 hover:text-white transition-colors cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <form onSubmit={handleSubmitTicket} className="space-y-3">
                <div>
                  <label className="block text-xs font-medium text-neutral-400 mb-1">
                    Subject
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Call verification question"
                    value={ticketSubject}
                    onChange={(e) => setTicketSubject(e.target.value)}
                    className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white placeholder-neutral-600 focus:outline-hidden focus:border-neutral-600"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-neutral-400 mb-1">
                    Description
                  </label>
                  <textarea
                    rows={4}
                    placeholder="Provide details about what happened..."
                    value={ticketMessage}
                    onChange={(e) => setTicketMessage(e.target.value)}
                    className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white placeholder-neutral-600 focus:outline-hidden focus:border-neutral-600 resize-none"
                  />
                </div>

                {ticketStatus && (
                  <p className="text-xs text-emerald-400 text-center font-medium">
                    {ticketStatus}
                  </p>
                )}

                <button
                  type="submit"
                  className="w-full py-2.5 rounded-xl bg-white hover:bg-neutral-200 active:scale-[0.99] text-black font-semibold text-xs transition-colors cursor-pointer"
                >
                  Submit Report
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Modal: Terms of Service */}
      <AnimatePresence>
        {showTermsModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-sm bg-neutral-950 border border-neutral-900 rounded-2xl p-5 space-y-4 max-h-[85vh] flex flex-col"
            >
              <div className="flex items-center justify-between border-b border-neutral-900 pb-3">
                <h3 className="text-sm font-semibold text-white">Terms of Service</h3>
                <button
                  onClick={() => setShowTermsModal(false)}
                  className="p-1 rounded-lg text-neutral-500 hover:text-white transition-colors cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="space-y-3 overflow-y-auto text-xs text-neutral-300 leading-relaxed pr-1">
                <div>
                  <h4 className="font-semibold text-white mb-1">1. Genuine Conversations</h4>
                  <p className="text-neutral-400">
                    Participants must engage in authentic human dialogue. Automated audio, prerecorded
                    content, background noise looping, or silence will disqualify calls from rewards.
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold text-white mb-1">2. Minimum Speaking Requirement</h4>
                  <p className="text-neutral-400">
                    Each participant must contribute at least 20 seconds of active vocal audio during
                    the 3-minute conversation to be eligible for the ₹20 reward.
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold text-white mb-1">3. Prize Pool & Discretion</h4>
                  <p className="text-neutral-400">
                    Rewards are distributed from the daily prize pool. All pending rewards are subject
                    to a 7-day holding period and supervisor audit verification before disbursement.
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold text-white mb-1">4. Fair Use</h4>
                  <p className="text-neutral-400">
                    Creating multiple accounts or colluding to artificially deplete the prize pool will
                    result in account suspension and forfeiture of unpaid rewards.
                  </p>
                </div>
              </div>

              <button
                onClick={() => setShowTermsModal(false)}
                className="w-full py-2.5 rounded-xl bg-white hover:bg-neutral-200 active:scale-[0.99] text-black font-semibold text-xs transition-colors cursor-pointer"
              >
                Understood
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Modal: Privacy Policy */}
      <AnimatePresence>
        {showPrivacyModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-sm bg-neutral-950 border border-neutral-900 rounded-2xl p-5 space-y-4 max-h-[85vh] flex flex-col"
            >
              <div className="flex items-center justify-between border-b border-neutral-900 pb-3">
                <h3 className="text-sm font-semibold text-white">Privacy Policy</h3>
                <button
                  onClick={() => setShowPrivacyModal(false)}
                  className="p-1 rounded-lg text-neutral-500 hover:text-white transition-colors cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="space-y-3 overflow-y-auto text-xs text-neutral-300 leading-relaxed pr-1">
                <div>
                  <h4 className="font-semibold text-white mb-1">1. Audio Encryption</h4>
                  <p className="text-neutral-400">
                    Voice calls are transmitted over encrypted peer-to-peer WebRTC connections. Raw
                    audio recordings are never saved permanently to disk.
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold text-white mb-1">2. Payment Destination Information</h4>
                  <p className="text-neutral-400">
                    Your UPI ID and bank account details are stored securely solely to process
                    withdrawal disbursements. We never share payment data with external advertisers.
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold text-white mb-1">3. Data Ownership</h4>
                  <p className="text-neutral-400">
                    You maintain the right to export your complete personal account data at any time
                    using the Export My Data tool, or request permanent deletion of your account.
                  </p>
                </div>
              </div>

              <button
                onClick={() => setShowPrivacyModal(false)}
                className="w-full py-2.5 rounded-xl bg-white hover:bg-neutral-200 active:scale-[0.99] text-black font-semibold text-xs transition-colors cursor-pointer"
              >
                Close
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Modal: Delete My Account Confirmation */}
      <AnimatePresence>
        {showDeleteConfirmModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-sm bg-neutral-950 border border-neutral-900 rounded-2xl p-5 space-y-4"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-rose-500/10 border border-rose-500/20 flex items-center justify-center text-rose-400">
                    <Trash2 className="w-4 h-4" />
                  </div>
                  <h3 className="text-sm font-semibold text-white">Delete your account permanently?</h3>
                </div>
                <button
                  disabled={isDeleting}
                  onClick={() => {
                    setDeleteError(null);
                    setShowDeleteConfirmModal(false);
                  }}
                  className="p-1 rounded-lg text-neutral-500 hover:text-white transition-colors cursor-pointer disabled:opacity-50"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <p className="text-xs text-neutral-400 leading-relaxed">
                This action is permanent and cannot be undone. Your Firebase Authentication account will be deleted, and your personal profile, active debate rooms, and private settings will be scrubbed. Regulatory financial audit and ledger records will be preserved anonymously for legal accounting compliance.
              </p>

              {deleteError && (
                <div className="p-3 rounded-xl bg-rose-950/40 border border-rose-800/60 text-rose-300 text-xs flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span className="leading-relaxed">{deleteError}</span>
                </div>
              )}

              <div className="flex gap-2 pt-2">
                <button
                  id="btn-cancel-delete"
                  disabled={isDeleting}
                  onClick={() => {
                    setDeleteError(null);
                    setShowDeleteConfirmModal(false);
                  }}
                  className="flex-1 py-2.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 active:scale-[0.99] text-neutral-300 font-medium text-xs transition-colors cursor-pointer disabled:opacity-50"
                >
                  Cancel
                </button>
                <button
                  id="btn-delete-account-confirm"
                  disabled={isDeleting}
                  onClick={handleConfirmDeleteAccount}
                  className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-semibold text-xs transition-colors cursor-pointer disabled:opacity-50 flex items-center justify-center gap-1.5 shadow-lg shadow-rose-950/50"
                >
                  {isDeleting ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>Deleting Account...</span>
                    </>
                  ) : (
                    <span>Delete Account</span>
                  )}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Modal: Re-Authentication for Account Deletion */}
      <AnimatePresence>
        {showReauthModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-sm bg-neutral-950 border border-neutral-900 rounded-2xl p-5 space-y-4"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
                    <Lock className="w-4 h-4" />
                  </div>
                  <h3 className="text-sm font-semibold text-white">Security Verification</h3>
                </div>
                <button
                  disabled={isDeleting}
                  onClick={() => {
                    setDeleteError(null);
                    setShowReauthModal(false);
                  }}
                  className="p-1 rounded-lg text-neutral-500 hover:text-white transition-colors cursor-pointer disabled:opacity-50"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <p className="text-xs text-neutral-400 leading-relaxed">
                For your security, Firebase requires you to re-authenticate before permanently deleting your account.
              </p>

              {deleteError && (
                <div className="p-3 rounded-xl bg-rose-950/40 border border-rose-800/60 text-rose-300 text-xs flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span className="leading-relaxed">{deleteError}</span>
                </div>
              )}

              {reauthProvider === 'password' ? (
                <form onSubmit={handleReauthPasswordSubmit} className="space-y-4">
                  <div className="space-y-1.5">
                    <label htmlFor="reauth-password-input" className="block text-xs font-medium text-neutral-300">
                      Enter Account Password
                    </label>
                    <input
                      id="reauth-password-input"
                      type="password"
                      autoComplete="current-password"
                      value={reauthPassword}
                      onChange={(e) => {
                        setReauthPassword(e.target.value);
                        if (deleteError) setDeleteError(null);
                      }}
                      placeholder="••••••••"
                      disabled={isDeleting}
                      className="w-full h-11 px-3.5 rounded-xl bg-neutral-900 border border-neutral-800 text-white placeholder:text-neutral-500 text-xs focus:outline-none focus:border-neutral-500 transition-colors"
                      autoFocus
                    />
                  </div>

                  <div className="flex gap-2">
                    <button
                      type="button"
                      disabled={isDeleting}
                      onClick={() => {
                        setDeleteError(null);
                        setShowReauthModal(false);
                      }}
                      className="flex-1 py-2.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 active:scale-[0.99] text-neutral-300 font-medium text-xs transition-colors cursor-pointer disabled:opacity-50"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={isDeleting || !reauthPassword.trim()}
                      className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-semibold text-xs transition-colors cursor-pointer disabled:opacity-50 flex items-center justify-center gap-1.5 shadow-lg shadow-rose-950/50"
                    >
                      {isDeleting ? (
                        <>
                          <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          <span>Verifying...</span>
                        </>
                      ) : (
                        <span>Confirm & Delete</span>
                      )}
                    </button>
                  </div>
                </form>
              ) : (
                <div className="space-y-3">
                  <button
                    onClick={handleReauthGoogleSubmit}
                    disabled={isDeleting}
                    className="w-full py-2.5 rounded-xl bg-white hover:bg-neutral-200 text-black font-semibold text-xs transition-colors cursor-pointer disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {isDeleting ? (
                      <>
                        <Loader2 className="w-3.5 h-3.5 animate-spin text-black" />
                        <span>Verifying with Google...</span>
                      </>
                    ) : (
                      <>
                        <Lock className="w-3.5 h-3.5" />
                        <span>Verify with Google & Delete</span>
                      </>
                    )}
                  </button>

                  <button
                    disabled={isDeleting}
                    onClick={() => {
                      setDeleteError(null);
                      setShowReauthModal(false);
                    }}
                    className="w-full py-2.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-neutral-300 font-medium text-xs transition-colors cursor-pointer disabled:opacity-50"
                  >
                    Cancel
                  </button>
                </div>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Admin Panel Modal */}
      <AdminPanelModal
        isOpen={showAdminModal}
        onClose={() => setShowAdminModal(false)}
      />
    </div>
  );
};
