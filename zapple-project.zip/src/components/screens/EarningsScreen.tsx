import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useApp } from '../../context/AppContext';
import { RefreshCw, X } from 'lucide-react';

export const EarningsScreen: React.FC = () => {
  const {
    wallet,
    refreshWallet,
    transactions,
    userPayouts,
    refreshUserPayouts,
    paymentDetails,
    savePaymentDetails,
    currentUser,
  } = useApp();

  const [showConfigModal, setShowConfigModal] = useState(false);
  const [selectedMethod, setSelectedMethod] = useState<'UPI' | 'Bank Transfer'>('UPI');
  const [upiIdInput, setUpiIdInput] = useState('');
  const [bankAccountInput, setBankAccountInput] = useState('');
  const [bankIfscInput, setBankIfscInput] = useState('');
  const [accountNameInput, setAccountNameInput] = useState('');
  const [configMsg, setConfigMsg] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    refreshWallet();
    refreshUserPayouts();
    if (paymentDetails) {
      setSelectedMethod(paymentDetails.payoutMethod);
      if (paymentDetails.upiId) setUpiIdInput(paymentDetails.upiId);
      if (paymentDetails.bankAccountNumber) setBankAccountInput(paymentDetails.bankAccountNumber);
      if (paymentDetails.bankIfsc) setBankIfscInput(paymentDetails.bankIfsc);
      if (paymentDetails.accountHolderName) setAccountNameInput(paymentDetails.accountHolderName);
    }
  }, [paymentDetails, refreshWallet, refreshUserPayouts]);

  const handleSavePaymentConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    setConfigMsg('');
    setIsSaving(true);
    try {
      const res = await savePaymentDetails({
        payoutMethod: selectedMethod,
        upiId: upiIdInput.trim(),
        bankAccountNumber: bankAccountInput.trim(),
        bankIfsc: bankIfscInput.trim().toUpperCase(),
        accountHolderName: accountNameInput.trim() || currentUser?.name,
      });
      if (res.success) {
        setConfigMsg('Payment details saved successfully.');
        setTimeout(() => {
          setShowConfigModal(false);
          setConfigMsg('');
        }, 1200);
      } else {
        setConfigMsg(res.error || 'Failed to save payment details.');
      }
    } finally {
      setIsSaving(false);
    }
  };

  // Combine real transactions and real payout requests for unified real transaction history
  interface DisplayItem {
    id: string;
    title: string;
    date: string;
    amount: number;
    isCredit: boolean;
    status: 'Pending' | 'Paid Out' | 'Completed' | 'Rejected';
    timestamp: number;
  }

  const items: DisplayItem[] = [];

  // Add all backend ledger transactions
  transactions.forEach((tx) => {
    let statusLabel: DisplayItem['status'] = 'Completed';
    if (tx.status === 'pending') statusLabel = 'Pending';
    else if (tx.status === 'rejected' || tx.status === 'failed') statusLabel = 'Rejected';
    else if (!tx.isCredit) statusLabel = 'Paid Out';

    items.push({
      id: tx.id,
      title: tx.description || (tx.isCredit ? 'Call Reward' : 'Withdrawal'),
      date: tx.createdAt,
      amount: tx.amount,
      isCredit: tx.isCredit,
      status: statusLabel,
      timestamp: new Date(tx.createdAt).getTime(),
    });
  });

  // Add active payout requests from backend ledger that aren't already represented
  userPayouts.forEach((payout) => {
    const existing = items.some((item) => item.id === `tx_payout_${payout.id}` || item.id === payout.id);
    if (!existing) {
      let statusLabel: DisplayItem['status'] = 'Pending';
      if (payout.status === 'PAID') {
        statusLabel = 'Paid Out';
      } else if (payout.status === 'REJECTED' || payout.status === 'FAILED') {
        statusLabel = 'Rejected';
      } else {
        statusLabel = 'Pending';
      }

      items.push({
        id: payout.id,
        title: `Withdrawal (${payout.payoutMethod})`,
        date: payout.requestedAt,
        amount: payout.amount,
        isCredit: false,
        status: statusLabel,
        timestamp: new Date(payout.requestedAt).getTime(),
      });
    }
  });

  // Sort by date descending (most recent first)
  items.sort((a, b) => b.timestamp - a.timestamp);

  return (
    <div className="min-h-screen bg-black text-white flex flex-col">
      <div className="flex-1 px-4 pt-6 pb-28 space-y-4 max-w-md mx-auto w-full">
        {/* TOP: TOTAL EARNED */}
        <div
          id="card-total-earned"
          className="bg-neutral-950 border border-neutral-900 rounded-2xl p-5"
        >
          <div className="text-xs font-medium text-neutral-400 uppercase tracking-wider mb-1">
            TOTAL EARNED
          </div>
          <div className="text-3xl font-semibold text-white tracking-tight">
            ₹{wallet.totalEarned.toLocaleString('en-IN')}
          </div>
        </div>

        {/* UNDER TOTAL EARNED: PENDING & PAID OUT (SIDE-BY-SIDE - NO CARDS/BOXES) */}
        <div className="grid grid-cols-2 gap-4 px-1 py-1">
          {/* PENDING */}
          <div id="pending-earnings" className="space-y-0.5">
            <div className="text-[11px] font-medium text-neutral-500 uppercase tracking-wider">
              PENDING
            </div>
            <div className="text-xl font-semibold text-white tracking-tight">
              ₹{wallet.pendingBalance.toLocaleString('en-IN')}
            </div>
          </div>

          {/* PAID OUT */}
          <div id="paid-out-earnings" className="space-y-0.5">
            <div className="text-[11px] font-medium text-neutral-500 uppercase tracking-wider">
              PAID OUT
            </div>
            <div className="text-xl font-semibold text-white tracking-tight">
              ₹{(wallet.paidOutTotal || 0).toLocaleString('en-IN')}
            </div>
          </div>
        </div>

        {/* Payout Destination Details (Minimal) */}
        <div className="bg-neutral-950 border border-neutral-900 rounded-xl p-3.5 flex items-center justify-between">
          <div className="space-y-0.5 min-w-0 pr-2">
            <div className="text-xs font-medium text-neutral-400 uppercase tracking-wider">
              Payout Destination
            </div>
            <div className="text-xs text-white truncate">
              {paymentDetails?.payoutMethod === 'Bank Transfer' && paymentDetails.bankAccountNumber
                ? `Bank •••• ${paymentDetails.bankAccountNumber.slice(-4)}`
                : paymentDetails?.upiId
                ? `UPI: ${paymentDetails.upiId}`
                : 'UPI (Default)'}
            </div>
          </div>
          <button
            onClick={() => setShowConfigModal(true)}
            className="px-3 py-1.5 rounded-lg bg-neutral-900 hover:bg-neutral-800 active:scale-[0.99] text-neutral-200 hover:text-white border border-neutral-800 text-xs font-medium transition-colors cursor-pointer shrink-0"
          >
            Edit
          </button>
        </div>

        {/* TRANSACTION HISTORY */}
        <div className="space-y-3 pt-2">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold text-white">
              Transaction History
            </h2>
            <button
              onClick={() => {
                refreshWallet();
                refreshUserPayouts();
              }}
              className="text-xs text-neutral-500 hover:text-neutral-300 flex items-center gap-1 transition-colors cursor-pointer"
            >
              <RefreshCw className="w-3 h-3" /> Refresh
            </button>
          </div>

          {items.length === 0 ? (
            <div className="rounded-xl border border-neutral-900 bg-neutral-950 p-6 text-center">
              <p className="text-sm text-neutral-400">No transactions yet</p>
              <p className="text-xs text-neutral-600 mt-1">
                Your reward credits and payouts will appear here
              </p>
            </div>
          ) : (
            <div className="space-y-2">
              {items.map((tx) => {
                const statusBadge = {
                  'Paid Out': 'bg-neutral-900 text-neutral-300 border-neutral-800',
                  Completed: 'bg-emerald-950/60 text-emerald-400 border-emerald-800/50',
                  Pending: 'bg-amber-950/60 text-amber-400 border-amber-800/50',
                  Rejected: 'bg-rose-950/60 text-rose-400 border-rose-800/50',
                }[tx.status] || 'bg-neutral-900 text-neutral-400 border-neutral-800';

                return (
                  <div
                    key={tx.id}
                    className="bg-neutral-950 border border-neutral-900 rounded-xl p-3.5 space-y-1.5"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="space-y-0.5 min-w-0">
                        <div className="text-sm font-medium text-white line-clamp-1">
                          {tx.title}
                        </div>
                        <div className="text-xs text-neutral-500">
                          {new Date(tx.date).toLocaleString(undefined, {
                            month: 'short',
                            day: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </div>
                      </div>

                      <div className="text-right shrink-0">
                        <div
                          className={`text-sm font-semibold ${
                            tx.isCredit ? 'text-white' : 'text-neutral-300'
                          }`}
                        >
                          {tx.isCredit ? `+₹${tx.amount}` : `-₹${tx.amount}`}
                        </div>
                        <span
                          className={`inline-block mt-1 px-2 py-0.5 rounded-full text-[11px] font-medium border ${statusBadge}`}
                        >
                          {tx.status}
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Modal: Payout Destination Configuration */}
      <AnimatePresence>
        {showConfigModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-sm bg-neutral-950 border border-neutral-900 rounded-2xl p-5 space-y-4"
            >
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-semibold text-white">
                  Payout Destination
                </h3>
                <button
                  onClick={() => setShowConfigModal(false)}
                  className="p-1 rounded-lg text-neutral-500 hover:text-white transition-colors cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Method selector */}
              <div className="grid grid-cols-2 gap-2 bg-neutral-900 p-1 rounded-xl border border-neutral-800">
                <button
                  type="button"
                  onClick={() => setSelectedMethod('UPI')}
                  className={`py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                    selectedMethod === 'UPI'
                      ? 'bg-white text-black'
                      : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  UPI
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedMethod('Bank Transfer')}
                  className={`py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                    selectedMethod === 'Bank Transfer'
                      ? 'bg-white text-black'
                      : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  Bank Transfer
                </button>
              </div>

              <form onSubmit={handleSavePaymentConfig} className="space-y-3">
                {selectedMethod === 'UPI' ? (
                  <div>
                    <label className="block text-xs font-medium text-neutral-400 mb-1">
                      UPI ID (VPA)
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. mobile@upi"
                      value={upiIdInput}
                      onChange={(e) => setUpiIdInput(e.target.value)}
                      className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white placeholder-neutral-600 focus:outline-hidden focus:border-neutral-600"
                    />
                  </div>
                ) : (
                  <div className="space-y-2.5">
                    <div>
                      <label className="block text-xs font-medium text-neutral-400 mb-1">
                        Account Holder Name
                      </label>
                      <input
                        type="text"
                        placeholder="Account holder name"
                        value={accountNameInput}
                        onChange={(e) => setAccountNameInput(e.target.value)}
                        className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white placeholder-neutral-600 focus:outline-hidden focus:border-neutral-600"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-neutral-400 mb-1">
                        Bank Account Number
                      </label>
                      <input
                        type="text"
                        placeholder="Account number"
                        value={bankAccountInput}
                        onChange={(e) => setBankAccountInput(e.target.value)}
                        className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white placeholder-neutral-600 focus:outline-hidden focus:border-neutral-600"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-neutral-400 mb-1">
                        IFSC Code
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. HDFC0001234"
                        value={bankIfscInput}
                        onChange={(e) => setBankIfscInput(e.target.value.toUpperCase())}
                        className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-xs uppercase text-white placeholder-neutral-600 focus:outline-hidden focus:border-neutral-600"
                      />
                    </div>
                  </div>
                )}

                {configMsg && (
                  <p className="text-xs text-neutral-300 text-center font-medium">
                    {configMsg}
                  </p>
                )}

                <button
                  type="submit"
                  disabled={isSaving}
                  className="w-full py-2.5 rounded-xl bg-white hover:bg-neutral-200 active:scale-[0.99] text-black font-semibold text-xs transition-colors cursor-pointer"
                >
                  {isSaving ? 'Saving...' : 'Save Details'}
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
