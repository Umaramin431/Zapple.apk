import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useApp } from '../../context/AppContext';
import { copyToClipboard } from '../../utils/clipboard';
import { CallMilestones } from '../common/CallMilestones';
import {
  Copy,
  Check,
  Share2,
  AlertCircle,
  XCircle,
  RefreshCw,
  Send
} from 'lucide-react';

export const HomeScreen: React.FC = () => {
  const {
    currentUser,
    setCurrentTab,
    dailyPool,
    refreshDailyPool,
    userCalls,
    refreshUserCalls,
    createDebateCall,
    joinDebateCall,
    submitAppeal,
    initiateCallAgain,
  } = useApp();

  // Modals state
  const [showStartModal, setShowStartModal] = useState(false);
  const [showJoinModal, setShowJoinModal] = useState(false);
  const [showReferralModal, setShowReferralModal] = useState(false);
  const [showAppealModal, setShowAppealModal] = useState(false);
  const [appealCallId, setAppealCallId] = useState<string | null>(null);
  const [appealReason, setAppealReason] = useState('');
  const [appealStatusMsg, setAppealStatusMsg] = useState('');

  // Start Call state
  const [customTopic, setCustomTopic] = useState('');
  const [selectedPresetTopic, setSelectedPresetTopic] = useState('');
  const [isCreatingCall, setIsCreatingCall] = useState(false);
  const [createdCode, setCreatedCode] = useState<string | null>(null);
  const [codeCopied, setCodeCopied] = useState(false);
  const [codeShared, setCodeShared] = useState(false);
  const [referralCopied, setReferralCopied] = useState(false);

  // Join Call state
  const [inputCode, setInputCode] = useState('');
  const [joinError, setJoinError] = useState<string | null>(null);
  const [isJoining, setIsJoining] = useState(false);

  // Live countdown state for Daily Pool reset
  const [countdownText, setCountdownText] = useState('00h 00m 00s');

  // Suggested Topics
  const suggestedTopics = [
    'Artificial Intelligence: Creative partner or threat?',
    'Should remote work be a permanent legal right?',
    'Electric Vehicles vs Petrol: Environmental truth',
    'Is a cashless economy safer or riskier for citizens?',
  ];

  useEffect(() => {
    refreshUserCalls();
    refreshDailyPool();
  }, [refreshUserCalls, refreshDailyPool]);

  // Live countdown timer for Daily Pool
  useEffect(() => {
    const updateCountdown = () => {
      if (!dailyPool?.nextResetAt) {
        setCountdownText('--:--:--');
        return;
      }
      const target = new Date(dailyPool.nextResetAt).getTime();
      const diff = Math.max(0, target - Date.now());
      const hours = Math.floor(diff / (1000 * 60 * 60));
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((diff % (1000 * 60)) / 1000);
      setCountdownText(
        `${String(hours).padStart(2, '0')}h ${String(minutes).padStart(2, '0')}m ${String(seconds).padStart(2, '0')}s`
      );
    };

    updateCountdown();
    const interval = setInterval(updateCountdown, 1000);
    return () => clearInterval(interval);
  }, [dailyPool?.nextResetAt]);

  // Handle Start Call submit
  const handleStartCall = async () => {
    const topic = (customTopic.trim() || selectedPresetTopic).trim();
    if (!topic) return;

    setIsCreatingCall(true);
    try {
      const call = await createDebateCall(topic);
      setCreatedCode(call.joinCode);
    } catch (err) {
      console.error('Failed to create call', err);
    } finally {
      setIsCreatingCall(false);
    }
  };

  // Copy 6-char code
  const handleCopyCode = async () => {
    if (!createdCode) return;
    await copyToClipboard(createdCode);
    setCodeCopied(true);
    setTimeout(() => setCodeCopied(false), 2000);
  };

  // Share 6-char code
  const handleShareCode = async () => {
    if (!createdCode) return;
    const shareText = `Join my 3-minute voice conversation on Zapple! Use join code: ${createdCode}`;

    if (navigator.share && navigator.canShare && navigator.canShare({ text: shareText })) {
      try {
        await navigator.share({
          title: 'Join my Zapple call',
          text: shareText,
        });
        return;
      } catch {}
    }

    await copyToClipboard(shareText);
    setCodeShared(true);
    setTimeout(() => setCodeShared(false), 2000);
  };

  // Copy referral code
  const handleCopyReferral = async () => {
    const code = currentUser?.referralCode || 'ZAPPLE-NODE';
    await copyToClipboard(code);
    setReferralCopied(true);
    setTimeout(() => setReferralCopied(false), 2000);
  };

  // Handle Join Call submit
  const handleJoinCall = async (e: React.FormEvent) => {
    e.preventDefault();
    setJoinError(null);
    const code = inputCode.trim().toUpperCase();

    if (code.length < 5) {
      setJoinError('Please enter a valid 6-character node code.');
      return;
    }

    setIsJoining(true);
    try {
      const res = await joinDebateCall(code);
      if (res.success) {
        setShowJoinModal(false);
        setInputCode('');
        setCurrentTab('join_call');
      } else {
        setJoinError(res.error || 'Invalid or expired code. Please verify and retry.');
      }
    } catch (err: any) {
      setJoinError(err.message || 'Unable to link session. Check network node.');
    } finally {
      setIsJoining(false);
    }
  };

  // Handle Appeal Submit
  const handleSendAppeal = async () => {
    if (!appealCallId || !appealReason.trim()) return;
    const res = await submitAppeal(appealCallId, appealReason.trim());
    if (res.success) {
      setAppealStatusMsg('Telemetry audit log dispatched for human review.');
      setTimeout(() => {
        setShowAppealModal(false);
        setAppealCallId(null);
        setAppealReason('');
        setAppealStatusMsg('');
      }, 1800);
    } else {
      setAppealStatusMsg(res.error || 'Failed to submit telemetry audit.');
    }
  };

  const poolTotal = dailyPool?.totalPoolAmount || 5000;
  const poolAllocated = dailyPool?.allocatedAmount || 0;
  const poolRemaining = dailyPool?.remainingAmount ?? (poolTotal - poolAllocated);
  const isPoolExhausted = dailyPool?.isExhausted || poolRemaining <= 0;
  const poolUsagePercent = Math.min(100, Math.round((poolAllocated / (poolTotal || 1)) * 100));

  // Calculate real approved / completed calls from authoritative backend history
  const totalCompletedCalls = userCalls.filter(
    (c) => c.status === 'Verified' || (c as any).backendStatus === 'VERIFIED' || (c as any).backendStatus === 'REWARD DISTRIBUTED'
  ).length;

  return (
    <div className="min-h-screen bg-black text-white flex flex-col">
      <div className="flex-1 px-4 pt-6 pb-28 space-y-4 max-w-md mx-auto w-full">
        {/* Top Header Bar */}
        <div className="flex items-center justify-between pb-1">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-white text-black font-bold flex items-center justify-center text-sm">
              Z
            </div>
            <span className="font-semibold text-white tracking-tight text-base">Zapple</span>
          </div>
        </div>

        {/* Simple Prize Pool Section */}
        <div
          id="card-daily-earning-pool"
          className="bg-neutral-950 border border-neutral-900 rounded-2xl p-5"
        >
          <div className="text-xs font-medium text-neutral-400 uppercase tracking-wider mb-1">
            Prize Pool
          </div>
          <div className="text-3xl font-semibold text-white tracking-tight">
            ₹{poolRemaining.toLocaleString('en-IN')}
          </div>
        </div>

        {/* Call Progress Milestone Section (20-circle cycle) */}
        <CallMilestones totalCompletedCalls={totalCompletedCalls} />

        {/* Call Actions */}
        <div className="space-y-2.5">
          {/* Primary Action Button: Start Call */}
          <button
            id="btn-start-call"
            onClick={() => {
              setCreatedCode(null);
              setShowStartModal(true);
            }}
            className="w-full py-3.5 px-4 rounded-xl bg-white hover:bg-neutral-200 active:scale-[0.99] text-black font-semibold text-sm transition-colors cursor-pointer flex items-center justify-center"
          >
            Start Call
          </button>

          {/* Secondary Action: Join Call */}
          <button
            id="btn-join-with-code"
            onClick={() => {
              setJoinError(null);
              setInputCode('');
              setShowJoinModal(true);
            }}
            className="w-full py-3.5 px-4 rounded-xl bg-neutral-900 hover:bg-neutral-800 active:scale-[0.99] text-white border border-neutral-800 font-medium text-sm transition-colors cursor-pointer flex items-center justify-center"
          >
            Join Call
          </button>

          {/* Tertiary Action: Invite Code */}
          <button
            id="btn-refer-friend"
            onClick={() => setShowReferralModal(true)}
            className="w-full py-3.5 px-4 rounded-xl bg-neutral-900 hover:bg-neutral-800 active:scale-[0.99] text-neutral-200 hover:text-white border border-neutral-800 font-medium text-sm transition-colors cursor-pointer flex items-center justify-center"
          >
            Invite Code
          </button>
        </div>

        {/* Simple Call History Section */}
        <div className="space-y-3 pt-2">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold text-white">
              Call History
            </h2>
            <button
              onClick={() => refreshUserCalls()}
              className="text-xs text-neutral-500 hover:text-neutral-300 flex items-center gap-1 transition-colors cursor-pointer"
            >
              <RefreshCw className="w-3 h-3" /> Refresh
            </button>
          </div>

          {userCalls.length === 0 ? (
            <div className="rounded-xl border border-neutral-900 bg-neutral-950 p-6 text-center">
              <p className="text-sm text-neutral-400">No calls yet</p>
              <p className="text-xs text-neutral-600 mt-1">Your recent calls will appear here</p>
            </div>
          ) : (
            <div className="space-y-2">
              {userCalls.map((call) => {
                const displayStatus = call.status || 'Pending';
                const statusBadge = {
                  Verified: 'bg-emerald-950/60 text-emerald-400 border-emerald-800/50',
                  VERIFIED: 'bg-emerald-950/60 text-emerald-400 border-emerald-800/50',
                  'REWARD DISTRIBUTED': 'bg-emerald-950/60 text-emerald-400 border-emerald-800/50',
                  Pending: 'bg-amber-950/60 text-amber-400 border-amber-800/50',
                  PENDING: 'bg-amber-950/60 text-amber-400 border-amber-800/50',
                  'PENDING ADMIN REVIEW': 'bg-amber-950/60 text-amber-400 border-amber-800/50',
                  VERIFYING: 'bg-amber-950/60 text-amber-400 border-amber-800/50',
                  COMPLETED: 'bg-amber-950/60 text-amber-400 border-amber-800/50',
                  Rejected: 'bg-rose-950/60 text-rose-400 border-rose-800/50',
                  REJECTED: 'bg-rose-950/60 text-rose-400 border-rose-800/50',
                }[displayStatus] || 'bg-neutral-900 text-neutral-400 border-neutral-800';

                return (
                  <div
                    key={call.callId}
                    className="bg-neutral-950 border border-neutral-900 rounded-xl p-3.5 space-y-2.5"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="space-y-0.5 min-w-0">
                        <div className="text-sm font-medium text-white line-clamp-1">
                          {call.topic}
                        </div>
                        <div className="text-xs text-neutral-400">
                          With {call.otherParticipant}
                        </div>
                      </div>
                      <span
                        className={`shrink-0 px-2 py-0.5 rounded-full text-xs font-medium border ${statusBadge}`}
                      >
                        {call.status}
                      </span>
                    </div>

                    <div className="flex items-center justify-between pt-2 border-t border-neutral-900 text-xs text-neutral-500">
                      <span>
                        {new Date(call.date).toLocaleString(undefined, {
                          month: 'short',
                          day: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </span>

                      <div className="flex items-center gap-2.5">
                        <span className="font-medium text-white">
                          {call.reward}
                        </span>

                        <button
                          id={`call-again-history-${call.callId}`}
                          onClick={() =>
                            initiateCallAgain(call.callId, call.topic, undefined, call.otherParticipant)
                          }
                          className="px-2.5 py-1 rounded-lg bg-neutral-900 hover:bg-neutral-800 text-neutral-200 border border-neutral-800 text-xs font-medium transition-colors cursor-pointer"
                        >
                          Call Again
                        </button>

                        {call.status === 'Rejected' && (
                          <button
                            onClick={() => {
                              setAppealCallId(call.callId);
                              setShowAppealModal(true);
                            }}
                            className="text-xs text-neutral-400 hover:text-white underline cursor-pointer"
                          >
                            Appeal
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* MODAL: START A CALL */}
      <AnimatePresence>
        {showStartModal && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/80 backdrop-blur-xs">
            <motion.div
              initial={{ y: 50, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 50, opacity: 0 }}
              className="w-full max-w-md bg-neutral-950 border border-neutral-800 rounded-t-3xl sm:rounded-2xl p-5 space-y-4"
            >
              <div className="flex items-center justify-between border-b border-neutral-900 pb-3">
                <h3 className="text-sm font-semibold text-white">
                  Start Call
                </h3>
                <button
                  onClick={() => setShowStartModal(false)}
                  className="p-1 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-900 cursor-pointer"
                >
                  <XCircle className="w-5 h-5" />
                </button>
              </div>

              {!createdCode ? (
                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-medium text-neutral-400 mb-2">
                      Select a topic
                    </label>
                    <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                      {suggestedTopics.map((t) => (
                        <button
                          key={t}
                          type="button"
                          onClick={() => {
                            setSelectedPresetTopic(t);
                            setCustomTopic('');
                          }}
                          className={`w-full text-left p-3 rounded-xl text-xs transition-colors border ${
                            selectedPresetTopic === t
                              ? 'bg-neutral-800 border-neutral-700 text-white font-medium'
                              : 'bg-neutral-900 border-neutral-800/80 text-neutral-300 hover:bg-neutral-850'
                          }`}
                        >
                          {t}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-neutral-400 mb-1.5">
                      Or enter custom topic:
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Universal basic income"
                      value={customTopic}
                      onChange={(e) => {
                        setCustomTopic(e.target.value);
                        setSelectedPresetTopic('');
                      }}
                      className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2.5 text-xs text-white placeholder-neutral-600 focus:outline-hidden focus:border-neutral-700"
                    />
                  </div>

                  <button
                    onClick={handleStartCall}
                    disabled={isCreatingCall || (!customTopic.trim() && !selectedPresetTopic)}
                    className="w-full py-3 rounded-xl bg-white hover:bg-neutral-200 disabled:opacity-40 text-black font-semibold text-sm flex items-center justify-center gap-2 cursor-pointer transition-colors"
                  >
                    {isCreatingCall ? 'Generating Code...' : 'Create Code & Wait'}
                  </button>
                </div>
              ) : (
                /* Created Code Screen */
                <div className="space-y-4 text-center py-2">
                  <div className="space-y-1">
                    <p className="text-sm font-semibold text-white">
                      Call Code Generated
                    </p>
                    <p className="text-xs text-neutral-400">
                      Share this code with your partner to begin the call
                    </p>
                  </div>

                  {/* 6-character Code Display */}
                  <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-4">
                    <div className="font-mono text-3xl font-bold tracking-widest text-white">
                      {createdCode}
                    </div>
                  </div>

                  {/* Actions: Copy & Share */}
                  <div className="grid grid-cols-2 gap-2.5">
                    <button
                      onClick={handleCopyCode}
                      className="py-2.5 px-3 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-neutral-200 text-xs font-medium flex items-center justify-center gap-1.5 border border-neutral-800 cursor-pointer"
                    >
                      {codeCopied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                      <span>{codeCopied ? 'Copied' : 'Copy Code'}</span>
                    </button>

                    <button
                      onClick={handleShareCode}
                      className="py-2.5 px-3 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-neutral-200 text-xs font-medium flex items-center justify-center gap-1.5 border border-neutral-800 cursor-pointer"
                    >
                      {codeShared ? <Check className="w-4 h-4 text-emerald-400" /> : <Share2 className="w-4 h-4" />}
                      <span>{codeShared ? 'Shared' : 'Share Code'}</span>
                    </button>
                  </div>

                  {/* Enter Waiting Room */}
                  <button
                    onClick={() => {
                      setShowStartModal(false);
                      setCurrentTab('call_waiting');
                    }}
                    className="w-full py-3 rounded-xl bg-white hover:bg-neutral-200 text-black font-semibold text-sm flex items-center justify-center gap-2 cursor-pointer transition-colors"
                  >
                    <span>Enter Waiting Room</span>
                  </button>
                </div>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* MODAL: JOIN WITH CODE */}
      <AnimatePresence>
        {showJoinModal && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/80 backdrop-blur-xs">
            <motion.div
              initial={{ y: 50, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 50, opacity: 0 }}
              className="w-full max-w-md bg-neutral-950 border border-neutral-800 rounded-t-3xl sm:rounded-2xl p-5 space-y-4"
            >
              <div className="flex items-center justify-between border-b border-neutral-900 pb-3">
                <h3 className="text-sm font-semibold text-white">
                  Join Call
                </h3>
                <button
                  onClick={() => setShowJoinModal(false)}
                  className="p-1 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-900 cursor-pointer"
                >
                  <XCircle className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleJoinCall} className="space-y-4">
                <div>
                  <label className="block text-xs font-medium text-neutral-400 mb-2">
                    Enter 6-Digit Code
                  </label>
                  <input
                    type="text"
                    maxLength={6}
                    placeholder="e.g. 7K9X2P"
                    value={inputCode}
                    onChange={(e) => {
                      setInputCode(e.target.value.toUpperCase());
                      setJoinError(null);
                    }}
                    className="w-full text-center font-mono text-3xl font-bold tracking-widest bg-neutral-900 border border-neutral-800 focus:border-neutral-600 rounded-xl py-3.5 text-white uppercase focus:outline-hidden"
                  />
                  {joinError && (
                    <p className="mt-2 text-xs text-rose-400 flex items-center justify-center gap-1">
                      <AlertCircle className="w-3.5 h-3.5" />
                      <span>{joinError}</span>
                    </p>
                  )}
                </div>

                <button
                  type="submit"
                  disabled={isJoining || inputCode.trim().length < 5}
                  className="w-full py-3 rounded-xl bg-white hover:bg-neutral-200 disabled:opacity-40 text-black font-semibold text-sm flex items-center justify-center gap-2 cursor-pointer transition-colors"
                >
                  {isJoining ? 'Joining...' : 'Join Call'}
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* MODAL: REFER A FRIEND / INVITE CODE */}
      <AnimatePresence>
        {showReferralModal && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/80 backdrop-blur-xs">
            <motion.div
              initial={{ y: 50, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 50, opacity: 0 }}
              className="w-full max-w-md bg-neutral-950 border border-neutral-800 rounded-t-3xl sm:rounded-2xl p-5 space-y-4"
            >
              <div className="flex items-center justify-between border-b border-neutral-900 pb-3">
                <h3 className="text-sm font-semibold text-white">
                  Invite Code
                </h3>
                <button
                  onClick={() => setShowReferralModal(false)}
                  className="p-1 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-900 cursor-pointer"
                >
                  <XCircle className="w-5 h-5" />
                </button>
              </div>

              <p className="text-xs text-neutral-400 leading-relaxed">
                Share your invite code with friends to connect and earn rewards.
              </p>

              <div className="p-4 rounded-xl bg-neutral-900 border border-neutral-800 text-center space-y-1">
                <span className="text-xs text-neutral-400 uppercase font-medium">Your Invite Code</span>
                <div className="font-mono text-2xl font-bold text-white tracking-wider">
                  {currentUser?.referralCode || 'ZAPPLE-CODE'}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <button
                  onClick={handleCopyReferral}
                  className="py-2.5 px-3 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-neutral-200 text-xs font-medium flex items-center justify-center gap-1.5 border border-neutral-800 cursor-pointer"
                >
                  {referralCopied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                  <span>{referralCopied ? 'Copied' : 'Copy Code'}</span>
                </button>

                <button
                  onClick={async () => {
                    const shareText = `Use my Zapple invite code ${currentUser?.referralCode} to join!`;
                    if (navigator.share) {
                      try {
                        await navigator.share({ text: shareText });
                        return;
                      } catch {}
                    }
                    await copyToClipboard(shareText);
                    setReferralCopied(true);
                    setTimeout(() => setReferralCopied(false), 2000);
                  }}
                  className="py-2.5 px-3 rounded-xl bg-white hover:bg-neutral-200 text-black text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
                >
                  <Share2 className="w-4 h-4" />
                  <span>Share</span>
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* MODAL: APPEAL / MANUAL REVIEW */}
      <AnimatePresence>
        {showAppealModal && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/80 backdrop-blur-xs">
            <motion.div
              initial={{ y: 50, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 50, opacity: 0 }}
              className="w-full max-w-md bg-neutral-950 border border-neutral-800 rounded-t-3xl sm:rounded-2xl p-5 space-y-4"
            >
              <div className="flex items-center justify-between border-b border-neutral-900 pb-3">
                <h3 className="text-sm font-semibold text-white">
                  Appeal Call Review
                </h3>
                <button
                  onClick={() => setShowAppealModal(false)}
                  className="p-1 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-900 cursor-pointer"
                >
                  <XCircle className="w-5 h-5" />
                </button>
              </div>

              <p className="text-xs text-neutral-400">
                If your 3-minute discussion was rejected, explain the conversation details for manual review.
              </p>

              <textarea
                rows={3}
                placeholder="Explain the conversation specifics..."
                value={appealReason}
                onChange={(e) => setAppealReason(e.target.value)}
                className="w-full bg-neutral-900 border border-neutral-800 rounded-xl p-3 text-xs text-white placeholder-neutral-600 focus:outline-hidden focus:border-neutral-700"
              />

              {appealStatusMsg && (
                <p className="text-xs text-emerald-400 text-center font-medium">{appealStatusMsg}</p>
              )}

              <button
                onClick={handleSendAppeal}
                disabled={!appealReason.trim()}
                className="w-full py-2.5 rounded-xl bg-white hover:bg-neutral-200 disabled:opacity-40 text-black font-semibold text-xs flex items-center justify-center gap-2 cursor-pointer transition-colors"
              >
                <Send className="w-3.5 h-3.5" /> Submit Appeal
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
