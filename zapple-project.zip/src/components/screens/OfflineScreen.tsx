import React, { useState } from 'react';
import { WifiOff, RefreshCw } from 'lucide-react';

interface OfflineScreenProps {
  onRetry: () => Promise<void> | void;
}

export const OfflineScreen: React.FC<OfflineScreenProps> = ({ onRetry }) => {
  const [isRetrying, setIsRetrying] = useState(false);

  const handleRetryClick = async () => {
    setIsRetrying(true);
    try {
      await onRetry();
    } finally {
      setIsRetrying(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black text-white flex flex-col items-center justify-center p-6 z-[9999]">
      <div className="max-w-md w-full text-center space-y-6">
        <div className="w-16 h-16 mx-auto rounded-full bg-zinc-900 border border-zinc-800 flex items-center justify-center text-zinc-400">
          <WifiOff className="w-8 h-8" />
        </div>

        <div className="space-y-2">
          <h1 className="text-2xl font-semibold tracking-tight text-white">
            No Internet Connection
          </h1>
          <p className="text-zinc-400 text-sm leading-relaxed">
            Please connect to the internet to use Zapple.
          </p>
        </div>

        <button
          onClick={handleRetryClick}
          disabled={isRetrying}
          className="w-full py-3 px-4 bg-white text-black font-medium rounded-lg hover:bg-zinc-200 transition-colors flex items-center justify-center space-x-2 disabled:opacity-50"
        >
          <RefreshCw className={`w-4 h-4 ${isRetrying ? 'animate-spin' : ''}`} />
          <span>{isRetrying ? 'Checking connection...' : 'Retry'}</span>
        </button>
      </div>
    </div>
  );
};
