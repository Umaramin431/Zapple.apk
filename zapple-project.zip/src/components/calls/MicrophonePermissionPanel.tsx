import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Mic,
  MicOff,
  AlertCircle,
  CheckCircle2,
  RefreshCw,
  Settings,
  X,
  Volume2,
  Loader2,
} from 'lucide-react';
import {
  requestCallMicrophone,
  isMicrophoneActive,
  getActiveCallMicrophone,
  queryMicrophonePermissionState,
} from '../../utils/microphone';

interface MicrophonePermissionPanelProps {
  onPermissionGranted?: (stream: MediaStream) => void;
  onPermissionDenied?: (error: string) => void;
  isCallStarting?: boolean;
}

export const MicrophonePermissionPanel: React.FC<MicrophonePermissionPanelProps> = ({
  onPermissionGranted,
  onPermissionDenied,
  isCallStarting = false,
}) => {
  const [permissionState, setPermissionState] = useState<
    'idle' | 'requesting' | 'granted' | 'denied' | 'error'
  >('idle');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [showSettingsModal, setShowSettingsModal] = useState<boolean>(false);
  const [audioLevel, setAudioLevel] = useState<number>(0);
  const [activeDeviceLabel, setActiveDeviceLabel] = useState<string>('');

  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const animFrameRef = useRef<number | null>(null);

  const setupAudioMeter = (stream: MediaStream) => {
    try {
      const tracks = stream.getAudioTracks();
      if (tracks.length > 0 && tracks[0].label) {
        setActiveDeviceLabel(tracks[0].label);
      } else {
        setActiveDeviceLabel('Microphone Active');
      }

      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        if (audioContextRef.current) {
          audioContextRef.current.close().catch(() => {});
        }
        const audioCtx = new AudioCtx();
        audioContextRef.current = audioCtx;
        const source = audioCtx.createMediaStreamSource(stream);
        const analyser = audioCtx.createAnalyser();
        analyser.fftSize = 128;
        analyserRef.current = analyser;
        source.connect(analyser);

        const dataArray = new Uint8Array(analyser.frequencyBinCount);
        const loop = () => {
          if (analyserRef.current) {
            analyserRef.current.getByteFrequencyData(dataArray);
            let sum = 0;
            for (let i = 0; i < dataArray.length; i++) sum += dataArray[i];
            const avg = sum / dataArray.length;
            setAudioLevel(Math.min(100, Math.round((avg / 128) * 100)));
          }
          animFrameRef.current = requestAnimationFrame(loop);
        };
        loop();
      }
    } catch (e) {
      console.warn('Audio meter initialization notice:', e);
    }
  };

  useEffect(() => {
    let isMounted = true;

    async function checkState() {
      if (isMicrophoneActive()) {
        const stream = getActiveCallMicrophone();
        if (stream && isMounted) {
          setPermissionState('granted');
          setupAudioMeter(stream);
          onPermissionGranted?.(stream);
          return;
        }
      }

      const qState = await queryMicrophonePermissionState();
      if (!isMounted) return;

      if (qState === 'granted') {
        setPermissionState('idle');
      } else if (qState === 'denied') {
        setPermissionState('denied');
        setErrorMessage(
          'Microphone permission was denied in your browser. Please allow microphone access to participate.'
        );
      } else {
        setPermissionState('idle');
      }
    }

    checkState();

    return () => {
      isMounted = false;
      if (animFrameRef.current) {
        cancelAnimationFrame(animFrameRef.current);
      }
      if (audioContextRef.current) {
        audioContextRef.current.close().catch(() => {});
      }
    };
  }, []);

  const handleRequestMicrophone = async () => {
    setPermissionState('requesting');
    setErrorMessage(null);

    try {
      const res = await requestCallMicrophone();
      if (res.success && res.stream) {
        setPermissionState('granted');
        setupAudioMeter(res.stream);
        onPermissionGranted?.(res.stream);
      } else {
        const isDenied = res.isDenied || res.errorType === 'denied';
        setPermissionState(isDenied ? 'denied' : 'error');
        setErrorMessage(
          res.error ||
            'Microphone access is required for voice calls. Please grant permission to continue.'
        );
        onPermissionDenied?.(res.error || 'Permission denied');
      }
    } catch (err: any) {
      setPermissionState('error');
      const msg = err?.message || 'An unexpected error occurred while requesting microphone access.';
      setErrorMessage(msg);
      onPermissionDenied?.(msg);
    }
  };

  return (
    <div className="space-y-3">
      {/* 1. GRANTED STATE */}
      {permissionState === 'granted' && (
        <div className="p-3.5 rounded-xl bg-neutral-950 border border-neutral-900 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-neutral-900 text-white flex items-center justify-center">
              <Mic className="w-4 h-4" />
            </div>
            <div>
              <div className="text-xs font-semibold text-white flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-white" />
                <span>Microphone Connected</span>
              </div>
              <div className="text-[11px] text-neutral-400 truncate max-w-[180px]">
                {activeDeviceLabel || 'Ready for call'}
              </div>
            </div>
          </div>

          {/* Live Audio Level Meter */}
          <div className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-neutral-900 border border-neutral-800">
            <Volume2 className="w-3.5 h-3.5 text-neutral-400" />
            <div className="flex items-center gap-0.5 h-3">
              {[15, 30, 50, 75, 90].map((threshold, idx) => (
                <span
                  key={idx}
                  className={`w-1 rounded-full transition-all duration-75 ${
                    audioLevel >= threshold ? 'bg-white h-3' : 'bg-neutral-800 h-1.5'
                  }`}
                />
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 2. PROMPT / IDLE STATE */}
      {(permissionState === 'idle' || permissionState === 'requesting') && (
        <div className="bg-neutral-950 border border-neutral-900 rounded-xl p-4 space-y-3">
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 rounded-xl bg-neutral-900 text-neutral-300 flex items-center justify-center shrink-0">
              <Mic className="w-4 h-4" />
            </div>
            <div className="space-y-0.5">
              <h4 className="text-xs font-semibold text-white">
                Microphone Access
              </h4>
              <p className="text-[11px] text-neutral-400 leading-relaxed">
                Microphone permission is required for voice conversation.
              </p>
            </div>
          </div>

          <button
            id="allow-microphone-btn"
            type="button"
            onClick={handleRequestMicrophone}
            disabled={permissionState === 'requesting' || isCallStarting}
            className="w-full py-2.5 px-4 rounded-xl bg-white hover:bg-neutral-200 active:scale-[0.99] text-black text-xs font-semibold disabled:opacity-50 transition-colors cursor-pointer flex items-center justify-center gap-2"
          >
            {permissionState === 'requesting' ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin text-black" />
                <span>Checking Permission…</span>
              </>
            ) : (
              <>
                <Mic className="w-4 h-4" />
                <span>Enable Microphone</span>
              </>
            )}
          </button>
        </div>
      )}

      {/* 3. DENIED / ERROR STATE */}
      {(permissionState === 'denied' || permissionState === 'error') && (
        <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 space-y-3">
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 rounded-xl bg-neutral-900 text-neutral-400 flex items-center justify-center shrink-0">
              <MicOff className="w-4 h-4" />
            </div>
            <div className="space-y-1 flex-1">
              <h4 className="text-xs font-semibold text-white flex items-center gap-1.5">
                <AlertCircle className="w-3.5 h-3.5 text-neutral-400" />
                <span>Microphone Access Blocked</span>
              </h4>
              <p className="text-[11px] text-neutral-400 leading-relaxed">
                {errorMessage ||
                  'Microphone permission blocked. Please enable browser microphone access to enter call.'}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 pt-1">
            <button
              id="mic-try-again-btn"
              type="button"
              onClick={handleRequestMicrophone}
              className="py-2 px-3 rounded-lg bg-white hover:bg-neutral-200 text-black text-xs font-medium transition-colors cursor-pointer flex items-center justify-center gap-1.5"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Try Again</span>
            </button>

            <button
              id="open-browser-settings-btn"
              type="button"
              onClick={() => setShowSettingsModal(true)}
              className="py-2 px-3 rounded-lg bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-neutral-300 hover:text-white text-xs font-medium transition-colors cursor-pointer flex items-center justify-center gap-1.5"
            >
              <Settings className="w-3.5 h-3.5" />
              <span>Instructions</span>
            </button>
          </div>
        </div>
      )}

      {/* 4. SETTINGS INSTRUCTIONS MODAL */}
      <AnimatePresence>
        {showSettingsModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-sm rounded-2xl bg-neutral-950 border border-neutral-800 p-5 space-y-4 text-white"
            >
              <div className="flex items-center justify-between border-b border-neutral-900 pb-3">
                <h3 className="text-xs font-semibold text-white">
                  Enable Microphone
                </h3>
                <button
                  onClick={() => setShowSettingsModal(false)}
                  className="p-1 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-900 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="space-y-3 text-xs text-neutral-300">
                <div className="p-3 rounded-xl bg-neutral-900 border border-neutral-800 space-y-1.5">
                  <div className="font-semibold text-white text-[11px]">
                    Chrome / Edge / Brave
                  </div>
                  <ol className="list-decimal list-inside space-y-1 text-[11px] text-neutral-400">
                    <li>Click the lock icon in the address bar.</li>
                    <li>Toggle Microphone to Allow.</li>
                    <li>Click Try Again.</li>
                  </ol>
                </div>

                <div className="p-3 rounded-xl bg-neutral-900 border border-neutral-800 space-y-1.5">
                  <div className="font-semibold text-white text-[11px]">
                    Safari / iOS
                  </div>
                  <ol className="list-decimal list-inside space-y-1 text-[11px] text-neutral-400">
                    <li>Tap Website Settings in the address bar.</li>
                    <li>Set Microphone to Allow.</li>
                  </ol>
                </div>
              </div>

              <div className="pt-1 flex gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setShowSettingsModal(false);
                    handleRequestMicrophone();
                  }}
                  className="flex-1 py-2 px-3 rounded-xl bg-white hover:bg-neutral-200 text-black text-xs font-semibold transition-colors cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Try Again Now</span>
                </button>
                <button
                  type="button"
                  onClick={() => setShowSettingsModal(false)}
                  className="py-2 px-4 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-neutral-300 text-xs font-medium transition-colors cursor-pointer"
                >
                  Close
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
