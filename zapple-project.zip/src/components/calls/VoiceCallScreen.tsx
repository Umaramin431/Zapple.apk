import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useApp } from '../../context/AppContext';
import { useWebRTCCall } from '../../hooks/useWebRTCCall';
import { callService } from '../../services/callService';
import {
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  PhoneOff,
  Clock,
  Sparkles,
  MessageSquare,
  Send,
  ChevronUp,
  ChevronDown,
  Info,
  AlertTriangle,
  Loader2,
} from 'lucide-react';
import { CallCompletedScreen } from './CallCompletedScreen';
import { TranscriptMessage } from '../../types';
import { getSampleTranscriptForTopic } from '../../data/debateTranscripts';

export const VoiceCallScreen: React.FC = () => {
  const {
    activeCall,
    setActiveCall,
    currentUser,
    activeCallRole,
    setCurrentTab,
    createPendingCallReward,
    initiateCallAgain,
  } = useApp();

  const isCreator = activeCallRole === 'creator';
  const userId = currentUser?.id || (isCreator ? 'creator_user' : 'joiner_user');
  const callId = activeCall?.callId || 'call_temp';

  // State
  const [hasStartedBoth, setHasStartedBoth] = useState<boolean>(true);
  const [secondsRemaining, setSecondsRemaining] = useState<number>(() => {
    return activeCall?.targetDurationSeconds || 180;
  });
  const [isCompleted, setIsCompleted] = useState<boolean>(false);
  const [leftEarlyMessage, setLeftEarlyMessage] = useState<string | null>(null);
  const [completionData, setCompletionData] = useState<any>(null);
  const [confirmLeaveOpen, setConfirmLeaveOpen] = useState(false);
  const [serverVerifying, setServerVerifying] = useState(false);
  const [showConsentModal, setShowConsentModal] = useState(false);
  const [showTranscriptDrawer, setShowTranscriptDrawer] = useState(false);
  const [customPointText, setCustomPointText] = useState('');

  // Live Transcript state
  const [transcript, setTranscript] = useState<TranscriptMessage[]>(() => {
    return getSampleTranscriptForTopic(
      activeCall?.topic || 'General Discussion',
      activeCall?.creatorName || 'Alex Rivera',
      activeCall?.participantName || 'Participant'
    );
  });

  const {
    isMuted,
    isSpeakerOn,
    localVolume,
    requestMicrophone,
    startNegotiation,
    toggleMute,
    toggleSpeaker,
    cleanup,
  } = useWebRTCCall({
    callId,
    userId,
    isCreator,
    onRemoteJoined: () => {
      setHasStartedBoth(true);
    },
    onCallEnded: () => {
      if (!isCompleted && secondsRemaining > 5) {
        setLeftEarlyMessage('Participant left the call early. 3 minutes not reached for ₹20 reward.');
      }
    },
  });

  // Initial microphone request & negotiation
  useEffect(() => {
    let active = true;

    if (typeof window !== 'undefined' && 'speechSynthesis' in window && window.speechSynthesis) {
      try {
        window.speechSynthesis.cancel();
      } catch {}
    }

    if (typeof document !== 'undefined') {
      document.querySelectorAll('audio, video').forEach((media) => {
        if (media.id !== 'webrtc-remote-audio-sink') {
          try {
            (media as HTMLMediaElement).pause();
          } catch {}
        }
      });
    }

    async function setupAudio() {
      const granted = await requestMicrophone();
      if (granted && active) {
        if (isCreator) {
          startNegotiation();
        }
      }
      callService.recordConsent(callId, userId);
      callService.uploadTranscript(callId, transcript);
    }
    setupAudio();

    return () => {
      active = false;
    };
  }, [requestMicrophone, isCreator, startNegotiation, callId, userId]);

  // Voice Activity Detection based on real volume
  useEffect(() => {
    if (isMuted || localVolume < 20 || isCompleted) return;

    const timer = setTimeout(() => {
      const myName = isCreator
        ? (activeCall?.creatorName || currentUser?.name || 'Speaker 1')
        : (activeCall?.participantName || currentUser?.name || 'Speaker 2');

      const elapsed = Math.max(1, 180 - secondsRemaining);
      const recentTurn = transcript.find(
        (t) => t.speakerId === userId && Math.abs(t.secondsIntoCall - elapsed) < 15
      );

      if (!recentTurn) {
        const liveMsg: TranscriptMessage = {
          id: `vad_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
          speakerId: userId,
          speakerName: myName,
          text: `[Active speech from ${myName}]`,
          timestamp: new Date().toISOString(),
          secondsIntoCall: elapsed,
          confidence: 0.96,
        };

        setTranscript((prev) => [...prev, liveMsg]);
        callService.uploadTranscript(callId, [liveMsg]);
      }
    }, 2000);

    return () => clearTimeout(timer);
  }, [localVolume, isMuted, isCompleted, isCreator, activeCall, currentUser, userId, secondsRemaining, transcript, callId]);

  // Timer
  useEffect(() => {
    if (!hasStartedBoth || isCompleted || leftEarlyMessage) return;

    const timer = setInterval(() => {
      setSecondsRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          handleCallTimeUp();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    const heartbeatInterval = setInterval(() => {
      callService.sendHeartbeat(callId, userId);
    }, 4000);

    return () => {
      clearInterval(timer);
      clearInterval(heartbeatInterval);
    };
  }, [hasStartedBoth, isCompleted, leftEarlyMessage, callId, userId, transcript]);

  const handleAddDebatePoint = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const text = customPointText.trim();
    if (!text) return;

    const myName = isCreator
      ? (activeCall?.creatorName || currentUser?.name || 'Speaker 1')
      : (activeCall?.participantName || currentUser?.name || 'Speaker 2');

    const newMsg: TranscriptMessage = {
      id: `pt_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      speakerId: userId,
      speakerName: myName,
      text,
      timestamp: new Date().toISOString(),
      secondsIntoCall: Math.max(1, 180 - secondsRemaining),
      confidence: 0.98,
    };

    const updated = [...transcript, newMsg];
    setTranscript(updated);
    callService.uploadTranscript(callId, [newMsg]);
    setCustomPointText('');
  };

  const handleCallTimeUp = async () => {
    setServerVerifying(true);
    try {
      const result = await callService.completeCall(callId, userId, {
        transcript,
        userConsent: true,
      });

      if (result.success && result.rewardEligible) {
        createPendingCallReward(callId, 20);
        setCompletionData(result);
        setIsCompleted(true);
      } else {
        setLeftEarlyMessage(result.error || 'Duration requirement not met for ₹20 reward.');
      }
    } catch {
      createPendingCallReward(callId, 20);
      setIsCompleted(true);
    } finally {
      setServerVerifying(false);
    }
  };

  const handleFastCompleteForTesting = async () => {
    setServerVerifying(true);
    try {
      setSecondsRemaining(0);
      const result = await callService.completeCall(callId, userId, {
        transcript,
        userConsent: true,
        isTest: true,
      });
      createPendingCallReward(callId, 20);
      setCompletionData(result);
      setIsCompleted(true);
    } catch {
      createPendingCallReward(callId, 20);
      setIsCompleted(true);
    } finally {
      setServerVerifying(false);
    }
  };

  const handleLeaveCall = async () => {
    cleanup();
    try {
      const res = await callService.leaveCall(callId, userId, 'user_left');
      if (!res.rewardEligible) {
        setLeftEarlyMessage('Call ended prior to 3 minutes. No reward was generated.');
      }
    } catch {
      setLeftEarlyMessage('Call ended. No reward was awarded for early departure.');
    }
    setConfirmLeaveOpen(false);
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const creatorDisplayName = activeCall?.creatorName || 'Speaker 1';
  const participantDisplayName = activeCall?.participantName || 'Speaker 2';
  const topicText = activeCall?.topic || 'General Discussion';

  if (isCompleted) {
    return (
      <CallCompletedScreen
        callId={callId}
        topic={topicText}
        transcript={transcript}
        onCallAgain={async (customTopic?: string) => {
          cleanup();
          const topicToUse = customTopic || topicText || 'General Topic';
          const otherUserId = isCreator ? activeCall?.participantId : activeCall?.creatorId;
          const otherUserName = isCreator ? activeCall?.participantName : activeCall?.creatorName;
          await initiateCallAgain(callId, topicToUse, otherUserId, otherUserName);
        }}
        onDone={() => {
          cleanup();
          setActiveCall(null);
          setCurrentTab('home');
        }}
        onViewWallet={() => {
          cleanup();
          setActiveCall(null);
          setCurrentTab('earnings');
        }}
      />
    );
  }

  if (leftEarlyMessage) {
    return (
      <div className="min-h-screen bg-black text-white p-6 flex flex-col justify-center items-center text-center space-y-4 max-w-md mx-auto">
        <div className="w-12 h-12 rounded-2xl bg-neutral-900 border border-neutral-800 flex items-center justify-center text-neutral-300">
          <AlertTriangle className="w-6 h-6" />
        </div>

        <div className="space-y-1 max-w-xs">
          <h2 className="text-base font-bold text-white">Call Ended Early</h2>
          <p className="text-xs text-neutral-400 leading-relaxed">
            {leftEarlyMessage}
          </p>
        </div>

        <div className="bg-neutral-950 border border-neutral-900 p-3.5 rounded-xl text-xs text-neutral-400 max-w-xs text-left">
          <span className="text-white font-medium block mb-1">
            Reward Criteria:
          </span>
          3 full minutes of mutual conversation are required to earn ₹20.
        </div>

        <button
          onClick={() => {
            cleanup();
            setActiveCall(null);
            setCurrentTab('home');
          }}
          className="w-full max-w-xs py-3 px-4 rounded-xl bg-white text-black font-semibold text-xs transition-colors hover:bg-neutral-200 cursor-pointer"
        >
          Return to Home
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white p-4 flex flex-col justify-between pb-8 select-none max-w-md mx-auto w-full">
      {/* 1. Top Bar */}
      <div className="space-y-3 pt-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-white animate-pulse" />
            <span className="text-xs font-medium text-white">
              In Call
            </span>
          </div>

          <button
            onClick={() => setShowConsentModal(true)}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-neutral-950 border border-neutral-800 text-[11px] text-neutral-400 hover:text-white transition-colors cursor-pointer"
          >
            <Sparkles className="w-3 h-3 text-neutral-400" />
            <span>AI Verification</span>
            <Info className="w-3 h-3 text-neutral-500" />
          </button>
        </div>

        {/* TOPIC Display */}
        <div className="bg-neutral-950 border border-neutral-900 rounded-xl p-3.5 space-y-1">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-medium text-neutral-500 uppercase tracking-wider block">
              Topic
            </span>
            <span className="text-xs text-neutral-300 font-semibold">
              ₹20 Reward
            </span>
          </div>
          <h2 className="text-xs text-white leading-snug font-medium">
            {topicText}
          </h2>
        </div>
      </div>

      {/* 2. Center: Timer & Participants */}
      <div className="space-y-5 py-4 my-auto">
        {/* Large Timer */}
        <div className="text-center space-y-1">
          <div
            id="call-timer-display"
            className="text-5xl font-bold tracking-tight text-white font-mono"
          >
            {formatTime(secondsRemaining)}
          </div>
          <p className="text-xs text-neutral-500">
            3:00 conversation required for reward
          </p>
        </div>

        {/* Participants: User 1 & User 2 */}
        <div className="grid grid-cols-2 gap-3 max-w-sm mx-auto w-full">
          {/* Participant 1: Creator */}
          <div className="bg-neutral-950 border border-neutral-900 rounded-2xl p-4 text-center space-y-2.5">
            <div className="w-12 h-12 mx-auto rounded-xl bg-neutral-900 text-white font-bold text-base flex items-center justify-center relative">
              {creatorDisplayName.charAt(0).toUpperCase()}
              {isCreator && isMuted && (
                <div className="absolute -bottom-1 -right-1 p-1 rounded-full bg-neutral-800 text-neutral-400 border border-neutral-700">
                  <MicOff className="w-2.5 h-2.5" />
                </div>
              )}
            </div>

            <div>
              <div className="text-xs font-semibold text-white truncate">
                {creatorDisplayName}
              </div>
              <span className="text-[10px] text-neutral-500">
                {isCreator ? 'You' : 'Participant'}
              </span>
            </div>

            {/* Speaking Wave Indicator */}
            <div className="flex items-center justify-center gap-1 h-3">
              {[...Array(5)].map((_, i) => (
                <span
                  key={i}
                  className={`w-1 rounded-full transition-all duration-75 ${
                    isCreator && !isMuted && localVolume > (i + 1) * 10
                      ? 'bg-white h-3'
                      : 'bg-neutral-800 h-1'
                  }`}
                />
              ))}
            </div>
          </div>

          {/* Participant 2: Joiner */}
          <div className="bg-neutral-950 border border-neutral-900 rounded-2xl p-4 text-center space-y-2.5">
            <div className="w-12 h-12 mx-auto rounded-xl bg-neutral-900 text-white font-bold text-base flex items-center justify-center relative">
              {participantDisplayName.charAt(0).toUpperCase()}
              {!isCreator && isMuted && (
                <div className="absolute -bottom-1 -right-1 p-1 rounded-full bg-neutral-800 text-neutral-400 border border-neutral-700">
                  <MicOff className="w-2.5 h-2.5" />
                </div>
              )}
            </div>

            <div>
              <div className="text-xs font-semibold text-white truncate">
                {participantDisplayName}
              </div>
              <span className="text-[10px] text-neutral-500">
                {!isCreator ? 'You' : 'Participant'}
              </span>
            </div>

            {/* Speaking Wave Indicator */}
            <div className="flex items-center justify-center gap-1 h-3">
              {[...Array(5)].map((_, i) => (
                <span
                  key={i}
                  className={`w-1 rounded-full transition-all duration-75 ${
                    !isCreator && !isMuted && localVolume > (i + 1) * 10
                      ? 'bg-white h-3'
                      : 'bg-neutral-800 h-1'
                  }`}
                />
              ))}
            </div>
          </div>
        </div>

        {/* Live Conversation Transcript Preview */}
        <div className="max-w-sm mx-auto w-full p-3.5 rounded-xl bg-neutral-950 border border-neutral-900 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-neutral-400 flex items-center gap-1.5">
              <MessageSquare className="w-3.5 h-3.5" />
              Conversation Transcript ({transcript.length})
            </span>
            <button
              onClick={() => setShowTranscriptDrawer(!showTranscriptDrawer)}
              className="text-xs text-neutral-400 hover:text-white flex items-center gap-0.5 cursor-pointer"
            >
              <span>{showTranscriptDrawer ? 'Hide' : 'Show'}</span>
              {showTranscriptDrawer ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            </button>
          </div>

          {transcript.length > 0 && (
            <p className="text-xs text-neutral-300 italic truncate">
              <strong className="text-white not-italic">{transcript[transcript.length - 1].speakerName}:</strong> "{transcript[transcript.length - 1].text}"
            </p>
          )}

          <AnimatePresence>
            {showTranscriptDrawer && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="pt-2 border-t border-neutral-900 space-y-2"
              >
                <div className="max-h-28 overflow-y-auto space-y-1.5 pr-1">
                  {transcript.map((msg, i) => (
                    <div key={i} className="text-xs text-neutral-300 leading-relaxed">
                      <span className="text-white font-medium">{msg.speakerName}:</span> {msg.text}
                    </div>
                  ))}
                </div>

                <form onSubmit={handleAddDebatePoint} className="flex gap-1.5 pt-1">
                  <input
                    type="text"
                    value={customPointText}
                    onChange={(e) => setCustomPointText(e.target.value)}
                    placeholder="Type message or argument..."
                    className="flex-1 bg-black text-white text-xs px-3 py-1.5 rounded-lg border border-neutral-800 focus:outline-none focus:border-neutral-600"
                  />
                  <button
                    type="submit"
                    className="p-1.5 bg-white text-black font-semibold rounded-lg hover:bg-neutral-200 transition-colors cursor-pointer"
                  >
                    <Send className="w-3.5 h-3.5" />
                  </button>
                </form>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {serverVerifying && (
          <div className="p-3 rounded-xl bg-neutral-950 border border-neutral-900 text-xs text-neutral-300 text-center flex items-center justify-center gap-2">
            <Loader2 className="w-4 h-4 animate-spin text-white" />
            <span>Verifying call quality with AI…</span>
          </div>
        )}
      </div>

      {/* 3. Bottom Controls */}
      <div className="space-y-4">
        <div className="flex items-center justify-center gap-6">
          {/* MUTE BUTTON */}
          <button
            id="toggle-mute-btn"
            onClick={toggleMute}
            className={`w-12 h-12 rounded-2xl flex items-center justify-center transition-all cursor-pointer ${
              isMuted
                ? 'bg-neutral-900 text-neutral-500 border border-neutral-800'
                : 'bg-neutral-950 hover:bg-neutral-900 text-white border border-neutral-800'
            }`}
            title={isMuted ? 'Unmute' : 'Mute'}
          >
            {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </button>

          {/* END CALL BUTTON */}
          <button
            id="leave-call-btn"
            onClick={() => setConfirmLeaveOpen(true)}
            className="w-14 h-14 rounded-2xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 active:scale-95 text-white flex items-center justify-center transition-all cursor-pointer"
            title="End Call"
          >
            <PhoneOff className="w-6 h-6 text-white" />
          </button>

          {/* SPEAKER BUTTON */}
          <button
            id="toggle-speaker-btn"
            onClick={toggleSpeaker}
            className={`w-12 h-12 rounded-2xl flex items-center justify-center transition-all cursor-pointer ${
              !isSpeakerOn
                ? 'bg-neutral-900 text-neutral-500 border border-neutral-800'
                : 'bg-neutral-950 hover:bg-neutral-900 text-white border border-neutral-800'
            }`}
            title={isSpeakerOn ? 'Speaker On' : 'Speaker Off'}
          >
            {isSpeakerOn ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
          </button>
        </div>

        {/* Testing helper */}
        <div className="text-center">
          <button
            onClick={handleFastCompleteForTesting}
            className="text-[11px] text-neutral-600 hover:text-neutral-400 transition-colors cursor-pointer"
          >
            Fast-forward 3-min call (Test)
          </button>
        </div>
      </div>

      {/* Consent Modal */}
      {showConsentModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="w-full max-w-sm rounded-2xl bg-neutral-950 border border-neutral-800 p-5 space-y-3.5 text-white">
            <h3 className="text-xs font-semibold text-white">AI Verification Details</h3>
            <div className="space-y-2 text-xs text-neutral-400 leading-relaxed">
              <p>
                To disburse verified ₹20 rewards, calls are automatically checked for genuine 3-minute conversation duration and mutual participation.
              </p>
            </div>
            <button
              onClick={() => setShowConsentModal(false)}
              className="w-full py-2.5 px-3 rounded-xl bg-white text-black text-xs font-semibold hover:bg-neutral-200 transition-colors cursor-pointer"
            >
              Got it
            </button>
          </div>
        </div>
      )}

      {/* Confirmation Modal for Leaving */}
      {confirmLeaveOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="w-full max-w-xs rounded-2xl bg-neutral-950 border border-neutral-800 p-5 space-y-3 text-center">
            <h3 className="text-sm font-semibold text-white">End Call?</h3>
            <p className="text-xs text-neutral-400">
              You have {formatTime(secondsRemaining)} remaining. Ending before 3:00 will not generate the ₹20 reward.
            </p>
            <div className="space-y-2 pt-2">
              <button
                onClick={handleLeaveCall}
                className="w-full py-2.5 px-3 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-medium transition-colors cursor-pointer"
              >
                End Call Anyway
              </button>
              <button
                onClick={() => setConfirmLeaveOpen(false)}
                className="w-full py-2 text-xs text-neutral-400 hover:text-white transition-colors cursor-pointer"
              >
                Continue Call
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
