import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import confetti from 'canvas-confetti';
import {
  Trophy,
  Wallet as WalletIcon,
  ShieldCheck,
  CheckCircle2,
  Clock,
  AlertTriangle,
  XCircle,
  RefreshCw,
  Sparkles,
  ChevronDown,
  ChevronUp,
  PhoneCall,
  Home,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { RewardVerificationStatus, TranscriptMessage, AICallVerificationResult } from '../../types';
import { callService } from '../../services/callService';

interface CallCompletedScreenProps {
  callId: string;
  topic: string;
  transcript?: TranscriptMessage[];
  onDone: () => void;
  onViewWallet: () => void;
  onCallAgain?: (customTopic?: string) => Promise<void> | void;
}

export const CallCompletedScreen: React.FC<CallCompletedScreenProps> = ({
  callId,
  topic,
  transcript: initialTranscript,
  onDone,
  onViewWallet,
  onCallAgain,
}) => {
  const { callRewards, createPendingCallReward, verifyCallSession, currentUser } = useApp();

  const [isVerifying, setIsVerifying] = useState(false);
  const [isStartingCallAgain, setIsStartingCallAgain] = useState(false);
  const [showAiAudit, setShowAiAudit] = useState(true);
  const [loadedTranscript, setLoadedTranscript] = useState<TranscriptMessage[]>(initialTranscript || []);

  const [localStatus, setLocalStatus] = useState<RewardVerificationStatus | null>(null);
  const [localAiResult, setLocalAiResult] = useState<AICallVerificationResult | undefined>(undefined);
  const [rejectionReason, setRejectionReason] = useState<string | undefined>(undefined);
  const [verificationError, setVerificationError] = useState<string | null>(null);
  const hasTriggeredVerification = useRef(false);

  // Find or create pending reward for this call
  const reward = callRewards.find(
    (r) => r.callId === callId && r.userId === (currentUser?.id || 'demo_user')
  ) || {
    id: `rwd_${callId}`,
    callId,
    userId: currentUser?.id || 'demo_user',
    userName: currentUser?.name || 'User',
    amount: 20,
    currency: 'INR' as const,
    status: 'pending_verification' as RewardVerificationStatus,
    createdAt: new Date().toISOString(),
    checks: {
      bothJoined: true,
      durationMet: true,
      voiceActive: true,
      sessionCompleted: true,
      qualityRulesMet: true,
    },
  };

  const status = localStatus || reward.status;
  const aiResult: AICallVerificationResult | undefined = localAiResult || reward.aiVerification;
  const effectiveRejectionReason = rejectionReason || reward.rejectionReason;

  useEffect(() => {
    if (!callRewards.some((r) => r.callId === callId && r.userId === currentUser?.id)) {
      createPendingCallReward(callId, 20);
    }
  }, [callId, currentUser?.id]);

  useEffect(() => {
    if ((!loadedTranscript || loadedTranscript.length === 0) && callId) {
      callService.getTranscript(callId).then((res) => {
        if (res.transcript && res.transcript.length > 0) {
          setLoadedTranscript(res.transcript);
        }
      }).catch(() => {});
    }
  }, [callId, loadedTranscript]);

  useEffect(() => {
    if (status === 'verified') {
      try {
        confetti({
          particleCount: 70,
          spread: 70,
          origin: { y: 0.6 },
        });
      } catch {}
    }
  }, [status]);

  const executeAutomatedVerification = async () => {
    setIsVerifying(true);
    setVerificationError(null);
    try {
      const transcriptToUse =
        loadedTranscript && loadedTranscript.length > 0 ? loadedTranscript : initialTranscript;
      const res = await verifyCallSession(callId, false, transcriptToUse);
      if (res.status) {
        setLocalStatus(res.status);
      }
      if (res.aiVerification) {
        setLocalAiResult(res.aiVerification);
      }
      if (!res.success && res.reason) {
        setRejectionReason(res.reason);
      }
    } catch (err: any) {
      console.error('Automated call verification error:', err);
      setVerificationError(err.message || 'Verification process encountered an unexpected issue.');
    } finally {
      setIsVerifying(false);
    }
  };

  useEffect(() => {
    if (status === 'pending_verification' && !hasTriggeredVerification.current) {
      hasTriggeredVerification.current = true;
      executeAutomatedVerification();
    }
  }, [status, callId]);

  const handleCallAgain = async () => {
    if (!onCallAgain) {
      onDone();
      return;
    }
    setIsStartingCallAgain(true);
    try {
      await onCallAgain(topic);
    } catch (e) {
      console.error('Failed to start new call session:', e);
      setIsStartingCallAgain(false);
    }
  };

  return (
    <div className="min-h-screen bg-black text-white p-4 flex flex-col justify-between pb-8 space-y-4 select-none max-w-md mx-auto w-full">
      <div className="space-y-4 my-auto pt-2">
        {/* Header Icon & Title */}
        <div className="text-center space-y-2">
          <div className="w-12 h-12 mx-auto rounded-2xl bg-neutral-900 border border-neutral-800 flex items-center justify-center text-white">
            {status === 'verified' || status === 'held' ? (
              <Trophy className="w-6 h-6 text-white" />
            ) : status === 'rejected' ? (
              <XCircle className="w-6 h-6 text-neutral-400" />
            ) : status === 'pending_admin_review' ? (
              <ShieldCheck className="w-6 h-6 text-white" />
            ) : (
              <RefreshCw className="w-6 h-6 animate-spin text-neutral-400" />
            )}
          </div>

          <h1 className="text-lg font-bold text-white tracking-tight">
            {status === 'verified' || status === 'held'
              ? 'Call Approved'
              : status === 'rejected'
              ? 'Call Ineligible'
              : status === 'pending_admin_review'
              ? 'Waiting for Admin Review'
              : 'Verifying Call'}
          </h1>
          <p className="text-xs text-neutral-400 max-w-xs mx-auto">
            {status === 'verified' || status === 'held'
              ? 'Session approved. ₹20 has entered the 7-day holding period.'
              : status === 'rejected'
              ? (effectiveRejectionReason || 'Session did not meet quality benchmarks.')
              : status === 'pending_admin_review'
              ? 'Call completed • AI verification passed • Waiting for admin review'
              : 'Call completed • Verifying conversation duration…'}
          </p>
        </div>

        {/* Reward Status Card */}
        <div className="bg-neutral-950 border border-neutral-900 rounded-2xl p-5 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-neutral-400 uppercase tracking-wider">
              Reward Status
            </span>
            <span
              className={`text-[11px] font-medium px-2.5 py-0.5 rounded-full border flex items-center gap-1.5 ${
                status === 'verified' || status === 'held'
                  ? 'bg-neutral-900 text-white border-neutral-800'
                  : status === 'rejected'
                  ? 'bg-neutral-900 text-neutral-400 border-neutral-800'
                  : 'bg-neutral-900 text-neutral-300 border-neutral-800'
              }`}
            >
              {status === 'verified' || status === 'held' ? (
                <>
                  <CheckCircle2 className="w-3 h-3 text-white" />
                  Approved (Held)
                </>
              ) : status === 'rejected' ? (
                <>
                  <XCircle className="w-3 h-3 text-neutral-400" />
                  Ineligible
                </>
              ) : status === 'pending_admin_review' ? (
                <>
                  <Clock className="w-3 h-3 text-neutral-400" />
                  In Review
                </>
              ) : (
                <>
                  <RefreshCw className="w-3 h-3 animate-spin" />
                  Verifying
                </>
              )}
            </span>
          </div>

          <div className="py-2 text-center border-y border-neutral-900">
            <div className="text-3xl font-bold tracking-tight text-white">
              {status === 'rejected' ? '₹0' : '₹20'}
            </div>
            <div className="text-xs text-neutral-400 mt-1">
              {(status === 'verified' || status === 'held') && 'Call Reward +₹20 (7-Day Holding Period)'}
              {status === 'pending_admin_review' && 'Waiting for admin review'}
              {status === 'pending_verification' && 'Verification in progress'}
              {status === 'rejected' && '₹0 • Benchmark not met'}
            </div>
          </div>

          <div className="text-xs text-neutral-400 leading-relaxed bg-black border border-neutral-900 rounded-xl p-3">
            {(status === 'verified' || status === 'held') && (
              <p>
                <strong>Reward Approved:</strong> ₹20 has entered your 7-day holding period. Once matured, it moves automatically to your withdrawable balance.
              </p>
            )}
            {status === 'pending_admin_review' && (
              <p>
                <strong>Waiting for admin review:</strong> Call completed and AI checks passed. The session is currently in the review queue.
              </p>
            )}
            {status === 'pending_verification' && (
              <p>
                <strong>Verification pending:</strong> AI is validating duration and reciprocal dialogue.
              </p>
            )}
            {status === 'rejected' && (
              <p>
                {effectiveRejectionReason || 'Session failed duration or reciprocal engagement benchmarks.'}
              </p>
            )}
          </div>

          <div className="pt-1">
            <span className="text-[10px] font-medium text-neutral-500 uppercase tracking-wider block">
              Topic
            </span>
            <p className="text-xs text-neutral-300 mt-0.5 truncate">
              {topic}
            </p>
          </div>
        </div>

        {/* AI Neural Quality Audit Card */}
        <div className="bg-neutral-950 border border-neutral-900 rounded-2xl p-4 space-y-3">
          <button
            onClick={() => setShowAiAudit(!showAiAudit)}
            className="w-full flex items-center justify-between text-left cursor-pointer"
          >
            <div className="flex items-center gap-2.5">
              <ShieldCheck className="w-4 h-4 text-neutral-400" />
              <div>
                <span className="text-xs font-semibold text-white block">
                  AI Quality Verification
                </span>
                <span className="text-[11px] text-neutral-400">
                  Duration & Dialogue Analysis
                </span>
              </div>
            </div>
            {showAiAudit ? (
              <ChevronUp className="w-4 h-4 text-neutral-400" />
            ) : (
              <ChevronDown className="w-4 h-4 text-neutral-400" />
            )}
          </button>

          <AnimatePresence>
            {showAiAudit && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="space-y-2 pt-2 border-t border-neutral-900 text-xs"
              >
                {aiResult ? (
                  <div className="space-y-2">
                    <div className="flex items-center justify-between p-2.5 rounded-xl bg-black border border-neutral-900">
                      <span className="text-neutral-400">Confidence Score</span>
                      <span className="font-semibold text-white">
                        {aiResult.confidenceScore || 94}%
                      </span>
                    </div>

                    <div className="space-y-1.5">
                      <div className="p-2.5 rounded-xl bg-black border border-neutral-900 flex items-center justify-between text-[11px]">
                        <span className="text-neutral-400">1. Mutual Dialogue Participation</span>
                        <span className="text-white font-medium">Passed</span>
                      </div>
                      <div className="p-2.5 rounded-xl bg-black border border-neutral-900 flex items-center justify-between text-[11px]">
                        <span className="text-neutral-400">2. Topical Coherence</span>
                        <span className="text-white font-medium">Passed</span>
                      </div>
                      <div className="p-2.5 rounded-xl bg-black border border-neutral-900 flex items-center justify-between text-[11px]">
                        <span className="text-neutral-400">3. Anti-Gaming Filter</span>
                        <span className="text-white font-medium">Passed</span>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-1.5 text-neutral-400 text-[11px]">
                    <p>Verified against 3-minute conversation duration and mutual speech activity.</p>
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Action Navigation */}
      <div className="space-y-2 pt-3">
        <button
          id="call-again-btn"
          onClick={handleCallAgain}
          disabled={isStartingCallAgain}
          className="w-full py-3 px-4 rounded-xl bg-white hover:bg-neutral-200 active:scale-[0.99] text-black text-xs font-semibold shadow-sm disabled:opacity-60 transition-colors cursor-pointer flex items-center justify-center gap-2"
        >
          <PhoneCall className="w-4 h-4" />
          <span>{isStartingCallAgain ? 'Starting Call…' : 'Call Again'}</span>
        </button>

        <button
          id="back-to-home-btn"
          onClick={onDone}
          disabled={isStartingCallAgain}
          className="w-full py-2.5 px-4 rounded-xl bg-neutral-950 hover:bg-neutral-900 border border-neutral-900 text-neutral-300 hover:text-white text-xs font-medium transition-colors cursor-pointer flex items-center justify-center gap-2"
        >
          <Home className="w-4 h-4" />
          <span>Return to Home</span>
        </button>

        <button
          id="view-wallet-btn"
          onClick={onViewWallet}
          className="w-full py-1 text-center text-xs text-neutral-500 hover:text-neutral-300 transition-colors cursor-pointer flex items-center justify-center gap-1.5"
        >
          <WalletIcon className="w-3.5 h-3.5" />
          <span>View in Wallet</span>
        </button>
      </div>
    </div>
  );
};
