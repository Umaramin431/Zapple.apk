import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Phone, PhoneOff, CheckCircle2, Shield, Sparkles, UserCheck } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const DirectCallingScreen: React.FC = () => {
  const {
    outgoingInvitation,
    activeCall,
    setActiveCallRole,
    setCurrentTab,
    cancelOutgoingCall,
  } = useApp();

  const [step, setStep] = useState<'calling' | 'accepted' | 'connected'>('calling');
  const [autoAcceptCountdown, setAutoAcceptCountdown] = useState<number>(3);
  const [isSimulatingAccept, setIsSimulatingAccept] = useState<boolean>(false);

  const recipientName = outgoingInvitation?.recipientName || activeCall?.participantName || 'Debater Partner';
  const recipientAvatar =
    outgoingInvitation?.recipientAvatar ||
    'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80';
  const topic = outgoingInvitation?.topic || activeCall?.topic || 'General Discussion';

  useEffect(() => {
    if (outgoingInvitation?.status === 'accepted') {
      triggerConnectedFlow();
    }
  }, [outgoingInvitation?.status]);

  useEffect(() => {
    if (step !== 'calling') return;
    const interval = setInterval(() => {
      setAutoAcceptCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          handleSimulateAccept();
          return 0;
        }
        return prev - 1;
      });
    }, 1200);
    return () => clearInterval(interval);
  }, [step]);

  const triggerConnectedFlow = () => {
    setStep('accepted');
    setTimeout(() => {
      setStep('connected');
      setTimeout(() => {
        setActiveCallRole('creator');
        setCurrentTab('voice_call');
      }, 700);
    }, 900);
  };

  const handleSimulateAccept = async () => {
    if (isSimulatingAccept || step !== 'calling') return;
    setIsSimulatingAccept(true);

    if (outgoingInvitation) {
      try {
        await fetch(`/api/calls/invitations/${outgoingInvitation.id}/accept`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            recipientId: outgoingInvitation.recipientId,
            recipientName: outgoingInvitation.recipientName,
          }),
        });
      } catch {}
    }

    triggerConnectedFlow();
  };

  return (
    <div className="min-h-screen flex flex-col justify-between bg-black text-white p-6 select-none max-w-md mx-auto w-full">
      {/* Top Bar */}
      <div className="flex items-center justify-between pt-2">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-white animate-pulse" />
          <span className="text-xs font-medium text-white">
            {step === 'calling' && 'Calling…'}
            {step === 'accepted' && 'Call Accepted'}
            {step === 'connected' && 'Connecting'}
          </span>
        </div>
        <span className="text-xs text-neutral-400">
          Direct Call
        </span>
      </div>

      {/* Main Calling Card */}
      <div className="flex flex-col items-center justify-center my-auto py-8 text-center">
        {/* Avatar */}
        <div className="relative mb-5">
          <div className="relative w-24 h-24 rounded-full overflow-hidden border border-neutral-800">
            <img
              src={recipientAvatar}
              alt={recipientName}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
          </div>

          <div className="absolute -bottom-1 -right-1 p-2 rounded-full border border-black bg-white text-black">
            {step === 'calling' && <Phone className="w-3.5 h-3.5" />}
            {step === 'accepted' && <CheckCircle2 className="w-3.5 h-3.5" />}
            {step === 'connected' && <CheckCircle2 className="w-3.5 h-3.5" />}
          </div>
        </div>

        {/* Recipient & Status Labels */}
        <h2 className="text-lg font-bold text-white tracking-tight mb-1">{recipientName}</h2>

        <div className="text-xs text-neutral-400 mb-5">
          {step === 'calling' && 'Ringing…'}
          {step === 'accepted' && `${recipientName} accepted the call`}
          {step === 'connected' && 'Starting 3-minute call…'}
        </div>

        {/* Topic Pill */}
        <div className="max-w-sm px-4 py-2.5 rounded-xl bg-neutral-950 border border-neutral-900 text-xs text-neutral-300 mb-5">
          <span className="text-neutral-500 mr-1.5">Topic:</span>
          <span className="text-white font-medium">{topic}</span>
        </div>

        {/* Reward & Target Duration */}
        <div className="w-full max-w-xs p-3.5 rounded-xl bg-neutral-950 border border-neutral-900 text-left space-y-1.5 text-xs text-neutral-400">
          <div className="flex justify-between">
            <span>Duration:</span>
            <span className="text-white font-medium">3 Minutes</span>
          </div>
          <div className="flex justify-between">
            <span>Reward:</span>
            <span className="text-white font-medium">₹20 upon completion</span>
          </div>
        </div>

        {/* Simulate Accept helper for solo testing */}
        {step === 'calling' && (
          <div className="mt-5 flex flex-col items-center gap-1">
            <button
              id="simulate-partner-accept-btn"
              onClick={handleSimulateAccept}
              disabled={isSimulatingAccept}
              className="text-xs px-3.5 py-1.5 rounded-lg bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-neutral-300 transition-colors cursor-pointer flex items-center gap-1.5"
            >
              <UserCheck className="w-3.5 h-3.5" />
              <span>Simulate Accept ({autoAcceptCountdown}s)</span>
            </button>
          </div>
        )}
      </div>

      {/* Bottom Controls */}
      <div className="flex flex-col items-center gap-3 pb-4">
        {step === 'calling' && (
          <button
            id="cancel-outgoing-call-btn"
            onClick={cancelOutgoingCall}
            className="w-full max-w-xs py-3 px-6 rounded-xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-white font-medium text-xs transition-colors cursor-pointer flex items-center justify-center gap-2"
          >
            <PhoneOff className="w-4 h-4 text-neutral-400" />
            <span>Cancel Call</span>
          </button>
        )}
      </div>
    </div>
  );
};
