import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  ArrowLeft,
  KeyRound,
  CheckCircle2,
  AlertCircle,
  Clock,
  PhoneCall,
  Loader2,
  Lock,
} from 'lucide-react';
import { Call } from '../../types';
import { callService } from '../../services/callService';
import {
  requestCallMicrophone,
  isMicrophoneActive,
} from '../../utils/microphone';
import { MicrophonePermissionPanel } from './MicrophonePermissionPanel';

export const JoinCallScreen: React.FC = () => {
  const {
    joinDebateCall,
    setCurrentTab,
    currentUser,
    activeCall,
  } = useApp();

  const [code, setCode] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [matchedCall, setMatchedCall] = useState<Call | null>(activeCall || null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [joinMicError, setJoinMicError] = useState<string | null>(null);
  const [isJoining, setIsJoining] = useState(false);
  const [hasMicAccess, setHasMicAccess] = useState<boolean>(() => isMicrophoneActive());

  useEffect(() => {
    if (activeCall && (!matchedCall || matchedCall.callId !== activeCall.callId)) {
      setMatchedCall(activeCall);
    }
  }, [activeCall]);

  useEffect(() => {
    setHasMicAccess(isMicrophoneActive());
  }, []);

  const handleJoinClick = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanCode = code.trim().toUpperCase();
    if (cleanCode.length !== 6) {
      setErrorMessage('Please enter a 6-character code.');
      return;
    }

    setIsSearching(true);
    setErrorMessage(null);
    setMatchedCall(null);

    try {
      const res = await joinDebateCall(cleanCode);
      if (res.success && res.call) {
        setMatchedCall(res.call);
      } else {
        setErrorMessage(res.error || 'Invalid or expired code.');
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Invalid or expired code.');
    } finally {
      setIsSearching(false);
    }
  };

  const handlePermissionGranted = () => {
    setHasMicAccess(true);
    setJoinMicError(null);
  };

  const handlePermissionDenied = () => {
    setHasMicAccess(false);
  };

  const handleReadyToJoin = async () => {
    setJoinMicError(null);

    if (!hasMicAccess || !isMicrophoneActive()) {
      setIsJoining(true);
      const micResult = await requestCallMicrophone();
      setIsJoining(false);
      if (!micResult.success || !micResult.stream) {
        setJoinMicError(
          micResult.error ||
            'Microphone access is required for voice calls. Please allow microphone access to proceed.'
        );
        return;
      }
      setHasMicAccess(true);
    }

    setIsJoining(true);
    try {
      if (!matchedCall) return;
      await callService.startCall(matchedCall.callId, currentUser?.id || 'demo_user_joiner');
      setCurrentTab('voice_call');
    } catch (err: any) {
      setJoinMicError(
        err?.message ||
          'Microphone access is required for voice calls. Please allow microphone permission to continue.'
      );
    } finally {
      setIsJoining(false);
    }
  };

  return (
    <div className="min-h-screen bg-black text-white p-4 space-y-5 pb-24 select-none max-w-md mx-auto w-full">
      {/* Top Header */}
      <div className="flex items-center justify-between pt-2">
        <button
          onClick={() => setCurrentTab('home')}
          className="p-2 rounded-xl bg-neutral-950 border border-neutral-900 text-neutral-400 hover:text-white transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>
        <span className="text-xs font-medium text-neutral-400">
          Join Call
        </span>
      </div>

      {/* Screen Title */}
      <div className="space-y-1">
        <h1 className="text-xl font-bold text-white tracking-tight">
          Join Call
        </h1>
        <p className="text-xs text-neutral-400">
          Enter the 6-character invite code to connect.
        </p>
      </div>

      {/* Form or Matched Call State */}
      {!matchedCall ? (
        <form onSubmit={handleJoinClick} className="space-y-4">
          <div className="bg-neutral-950 border border-neutral-900 rounded-2xl p-6 space-y-4">
            <div className="text-center space-y-1">
              <label className="block text-xs font-semibold text-white uppercase tracking-wider">
                Enter 6-Character Code
              </label>
              <p className="text-xs text-neutral-500">
                e.g. A7K29P
              </p>
            </div>

            {/* Code Input Field */}
            <div className="flex justify-center">
              <input
                id="join-code-input"
                type="text"
                maxLength={6}
                value={code}
                onChange={(e) => {
                  setCode(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, ''));
                  setErrorMessage(null);
                }}
                placeholder="A7K29P"
                autoFocus
                className="w-full max-w-[240px] text-center tracking-[0.3em] font-mono font-bold text-2xl py-3 px-4 rounded-xl bg-black border border-neutral-800 text-white placeholder-neutral-700 focus:outline-none focus:border-neutral-500 transition-colors uppercase"
              />
            </div>

            {errorMessage && (
              <div className="p-3 rounded-xl bg-neutral-900 border border-neutral-800 text-neutral-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-neutral-400" />
                <span>{errorMessage}</span>
              </div>
            )}
          </div>

          <button
            id="submit-join-call-btn"
            type="submit"
            disabled={isSearching || code.length < 6}
            className="w-full py-3.5 px-4 rounded-xl bg-white hover:bg-neutral-200 active:scale-[0.99] text-black text-xs font-semibold disabled:opacity-40 disabled:cursor-not-allowed transition-colors cursor-pointer flex items-center justify-center gap-2"
          >
            {isSearching ? (
              <Loader2 className="w-4 h-4 animate-spin text-black" />
            ) : (
              <>
                <KeyRound className="w-4 h-4" />
                <span>Join Call</span>
              </>
            )}
          </button>
        </form>
      ) : (
        /* Matched Call State */
        <div className="space-y-4">
          <div className="bg-neutral-950 border border-neutral-900 rounded-2xl p-4 space-y-3">
            <div className="flex items-center gap-2 text-white text-xs font-semibold">
              <CheckCircle2 className="w-4 h-4" />
              <span>Call Found</span>
            </div>

            {/* Topic preview */}
            <div className="p-3 rounded-xl bg-black border border-neutral-900 space-y-1">
              <span className="text-[10px] font-medium text-neutral-500 uppercase">
                Topic
              </span>
              <p className="text-xs font-medium text-white leading-snug">
                {matchedCall.topic}
              </p>
            </div>

            {/* Creator / Joiner Status */}
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="p-2.5 rounded-xl bg-black border border-neutral-900 space-y-1">
                <span className="text-[10px] text-neutral-500 block">Host</span>
                <span className="font-semibold text-white truncate block">
                  {matchedCall.creatorName}
                </span>
                <span className="inline-flex items-center gap-1 text-[10px] text-neutral-400">
                  <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
                  Waiting
                </span>
              </div>

              <div className="p-2.5 rounded-xl bg-black border border-neutral-900 space-y-1">
                <span className="text-[10px] text-neutral-500 block">You</span>
                <span className="font-semibold text-white truncate block">
                  {currentUser?.name || 'Debater'}
                </span>
                <span className="inline-flex items-center gap-1 text-[10px] text-neutral-400">
                  <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
                  Joining
                </span>
              </div>
            </div>

            {/* Call Info */}
            <div className="flex items-center justify-between text-xs text-neutral-400 p-2.5 rounded-xl bg-black border border-neutral-900">
              <span className="flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-neutral-400" /> Duration: 3 Minutes
              </span>
              <span className="text-white font-medium">₹20 Reward</span>
            </div>
          </div>

          {/* Microphone Permission Panel */}
          <MicrophonePermissionPanel
            onPermissionGranted={handlePermissionGranted}
            onPermissionDenied={handlePermissionDenied}
            isCallStarting={isJoining}
          />

          {joinMicError && (
            <div className="p-3 rounded-xl bg-neutral-900 border border-neutral-800 text-neutral-300 text-xs flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 text-neutral-400 shrink-0 mt-0.5" />
              <div className="flex-1 space-y-1">
                <p className="font-semibold text-white">Microphone Error</p>
                <p className="text-xs leading-relaxed text-neutral-400">{joinMicError}</p>
              </div>
            </div>
          )}

          {/* Action: Ready to Join Button */}
          <button
            id="ready-to-join-btn"
            onClick={handleReadyToJoin}
            disabled={isJoining || !hasMicAccess}
            className={`w-full py-3.5 px-4 rounded-xl text-xs font-semibold transition-colors cursor-pointer flex items-center justify-center gap-2 ${
              hasMicAccess
                ? 'bg-white hover:bg-neutral-200 text-black'
                : 'bg-neutral-900 text-neutral-500 border border-neutral-800 cursor-not-allowed'
            }`}
          >
            {isJoining ? (
              <Loader2 className="w-4 h-4 animate-spin text-black" />
            ) : hasMicAccess ? (
              <>
                <PhoneCall className="w-4 h-4" />
                <span>Enter Call</span>
              </>
            ) : (
              <>
                <Lock className="w-4 h-4 text-neutral-500" />
                <span>Enable Microphone to Join</span>
              </>
            )}
          </button>

          <button
            type="button"
            onClick={() => setMatchedCall(null)}
            className="w-full py-2 text-xs text-neutral-400 hover:text-white transition-colors cursor-pointer"
          >
            Use a different code
          </button>
        </div>
      )}
    </div>
  );
};
