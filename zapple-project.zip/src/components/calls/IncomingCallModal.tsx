import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Phone, PhoneOff, Sparkles, Shield, Bell } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const IncomingCallModal: React.FC = () => {
  const { incomingInvitation, acceptIncomingCall, declineIncomingCall } = useApp();

  if (!incomingInvitation) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
        <motion.div
          initial={{ scale: 0.9, opacity: 0, y: 20 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.9, opacity: 0, y: 20 }}
          className="w-full max-w-sm rounded-3xl bg-neutral-950 border border-neutral-800 p-6 text-center shadow-2xl shadow-emerald-500/10"
        >
          {/* Incoming Header */}
          <div className="flex items-center justify-center gap-2 mb-4">
            <span className="relative flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500" />
            </span>
            <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider">
              Incoming Voice Call
            </span>
          </div>

          {/* Caller Avatar */}
          <div className="relative mx-auto w-24 h-24 mb-4">
            <div className="absolute inset-0 rounded-full bg-emerald-500/20 animate-ping duration-1000 scale-110" />
            <div className="relative w-24 h-24 rounded-full overflow-hidden border-2 border-emerald-500 shadow-lg">
              <img
                src={
                  incomingInvitation.callerAvatar ||
                  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'
                }
                alt={incomingInvitation.callerName}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="absolute bottom-0 right-0 p-1.5 rounded-full bg-emerald-500 text-black border-2 border-neutral-950">
              <Phone className="w-3.5 h-3.5 animate-bounce" />
            </div>
          </div>

          {/* Caller Name */}
          <h3 className="text-lg font-bold text-white mb-1">{incomingInvitation.callerName}</h3>
          <p className="text-xs text-neutral-400 mb-4">wants to start a verified debate with you</p>

          {/* Topic */}
          <div className="inline-flex items-center gap-2 max-w-xs px-3.5 py-2 rounded-xl bg-neutral-900 border border-neutral-800 text-xs text-neutral-300 mb-4">
            <Sparkles className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            <span className="truncate">{incomingInvitation.topic}</span>
          </div>

          {/* Details */}
          <div className="p-3 rounded-xl bg-neutral-900/60 border border-neutral-800/80 text-xs text-neutral-400 space-y-1 mb-6">
            <div className="flex justify-between">
              <span>Duration:</span>
              <span className="text-white font-medium">3 Minutes</span>
            </div>
            <div className="flex justify-between">
              <span>Reward upon completion:</span>
              <span className="text-emerald-400 font-bold">₹20.00</span>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="grid grid-cols-2 gap-3">
            <button
              id="decline-incoming-call-btn"
              onClick={() => declineIncomingCall(incomingInvitation.id)}
              className="py-3 px-4 rounded-xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-neutral-300 hover:text-white font-medium text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              <PhoneOff className="w-4 h-4 text-rose-400" />
              <span>Decline</span>
            </button>
            <button
              id="accept-incoming-call-btn"
              onClick={() => acceptIncomingCall(incomingInvitation.id)}
              className="py-3 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black font-semibold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-lg shadow-emerald-500/20"
            >
              <Phone className="w-4 h-4" />
              <span>Accept Call</span>
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
