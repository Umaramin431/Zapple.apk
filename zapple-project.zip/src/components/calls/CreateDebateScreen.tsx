import React, { useState } from 'react';
import { motion } from 'motion/react';
import { useApp } from '../../context/AppContext';
import { copyToClipboard } from '../../utils/clipboard';
import {
  ArrowLeft,
  Sparkles,
  Copy,
  Check,
  Share2,
  Users,
  Clock,
  Coins,
  Shield,
  MessageSquare,
  AlertCircle,
  HelpCircle,
} from 'lucide-react';
import { Call } from '../../types';

export const CreateDebateScreen: React.FC = () => {
  const {
    createDebateCall,
    setCurrentTab,
    callDurationSeconds,
    setCallDurationSeconds,
  } = useApp();

  const [topic, setTopic] = useState('');
  const [isCreating, setIsCreating] = useState(false);
  const [createdCall, setCreatedCall] = useState<Call | null>(null);
  const [copied, setCopied] = useState(false);
  const [shared, setShared] = useState(false);

  const sampleTopics = [
    'Is online education better than classroom education?',
    'Will Artificial Intelligence create more jobs than it destroys?',
    'Should remote work be a permanent legal right?',
    'Are electric vehicles truly the best future for transportation?',
  ];

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!topic.trim()) return;

    setIsCreating(true);
    try {
      const call = await createDebateCall(topic.trim(), callDurationSeconds);
      setCreatedCall(call);
    } catch (err) {
      console.error('Failed to create call', err);
    } finally {
      setIsCreating(false);
    }
  };

  const handleCopyCode = async () => {
    if (!createdCall) return;
    await copyToClipboard(createdCall.joinCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShareCode = async () => {
    if (!createdCall) return;
    const shareText = `Join my 3-minute debate on TalkReward! Topic: "${createdCall.topic}". Use join code: ${createdCall.joinCode}`;

    if (navigator.share && navigator.canShare && navigator.canShare({ text: shareText })) {
      try {
        await navigator.share({
          title: 'Join TalkReward Debate',
          text: shareText,
          url: window.location.href,
        });
        return;
      } catch {}
    }

    await copyToClipboard(shareText);
    setShared(true);
    setTimeout(() => setShared(false), 2000);
  };

  const handleStartWaiting = () => {
    setCurrentTab('call_waiting');
  };

  return (
    <div className="min-h-full bg-black text-white p-4 space-y-5 pb-24">
      {/* Top Header */}
      <div className="flex items-center justify-between pt-1">
        <button
          onClick={() => setCurrentTab('home')}
          className="p-2 rounded-xl bg-neutral-900 border border-neutral-800 text-neutral-400 hover:text-white transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <span className="text-xs font-mono font-bold px-2.5 py-1 rounded-full bg-orange-500/10 text-orange-400 border border-orange-500/20 flex items-center gap-1.5">
          <Coins className="w-3.5 h-3.5" /> ₹20 REWARD
        </span>
      </div>

      {/* Screen Title */}
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-white">
          Create a Debate
        </h1>
        <p className="text-xs text-neutral-400 mt-1">
          Pick a topic, generate your 6-character code, and debate for 3 minutes.
        </p>
      </div>

      {/* STATE A: Topic Form */}
      {!createdCall ? (
        <form onSubmit={handleCreate} className="space-y-4">
          <div className="p-4 rounded-3xl bg-neutral-900/90 border border-neutral-800 space-y-3">
            <label className="block text-xs font-semibold text-neutral-300">
              Debate Topic
            </label>

            <textarea
              required
              rows={3}
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="Enter any debate topic..."
              className="w-full p-3.5 rounded-2xl bg-neutral-950 border border-neutral-800 text-white placeholder-neutral-500 text-sm font-medium focus:outline-none focus:border-orange-500 transition-colors leading-relaxed"
            />

            <div className="text-[11px] text-neutral-400 flex items-start gap-1.5">
              <span className="text-orange-400 font-semibold">Example:</span>
              <span>"Is online education better than classroom education?"</span>
            </div>
          </div>

          {/* Quick Topic Suggestions */}
          <div className="space-y-2">
            <div className="text-xs font-semibold text-neutral-400 px-1">
              Or pick an instant debate topic:
            </div>
            <div className="space-y-1.5">
              {sampleTopics.map((sample, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setTopic(sample)}
                  className="w-full p-2.5 rounded-xl bg-neutral-900/60 hover:bg-neutral-900 border border-neutral-800/80 text-left text-xs text-neutral-300 hover:text-white transition-all cursor-pointer flex items-center gap-2"
                >
                  <MessageSquare className="w-3.5 h-3.5 text-orange-400 shrink-0" />
                  <span className="truncate">{sample}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Call Duration & Reward Details */}
          <div className="p-3.5 rounded-2xl bg-neutral-900/60 border border-neutral-800/80 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2 text-neutral-300">
              <Clock className="w-4 h-4 text-orange-400" />
              <span>Call Duration</span>
            </div>

            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => setCallDurationSeconds(180)}
                className={`px-2.5 py-1 rounded-lg text-xs font-mono font-bold transition-all cursor-pointer ${
                  callDurationSeconds === 180
                    ? 'bg-orange-500 text-white'
                    : 'bg-neutral-800 text-neutral-400 hover:text-white'
                }`}
              >
                03:00 (Standard)
              </button>

              <button
                type="button"
                onClick={() => setCallDurationSeconds(15)}
                className={`px-2 py-1 rounded-lg text-[11px] font-mono font-bold transition-all cursor-pointer ${
                  callDurationSeconds === 15
                    ? 'bg-orange-500 text-white'
                    : 'bg-neutral-800 text-neutral-400 hover:text-white'
                }`}
                title="15s Demo Fast Testing Mode"
              >
                15s (Test Mode)
              </button>
            </div>
          </div>

          {/* Submit Button */}
          <button
            id="create-call-btn"
            type="submit"
            disabled={isCreating || !topic.trim()}
            className="w-full py-3.5 px-4 rounded-2xl bg-orange-500 hover:bg-orange-600 active:scale-[0.98] text-white text-sm font-bold shadow-lg shadow-orange-500/20 disabled:opacity-50 disabled:cursor-not-allowed transition-all cursor-pointer flex items-center justify-center gap-2"
          >
            {isCreating ? (
              <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <span>Create Call</span>
            )}
          </button>
        </form>
      ) : (
        /* STATE B: "Your call is ready" Screen */
        <motion.div
          initial={{ opacity: 0, scale: 0.96 }}
          animate={{ opacity: 1, scale: 1 }}
          className="space-y-4"
        >
          {/* Ready Card */}
          <div className="p-5 rounded-3xl bg-neutral-900 border border-neutral-800 text-center space-y-4 shadow-xl">
            <div className="w-12 h-12 mx-auto rounded-2xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 flex items-center justify-center">
              <Sparkles className="w-6 h-6" />
            </div>

            <div>
              <h2 className="text-xl font-extrabold text-white tracking-tight">
                Your call is ready
              </h2>
              <p className="text-xs text-neutral-400 mt-1">
                Send this code to your friend to join the debate.
              </p>
            </div>

            {/* Topic Display */}
            <div className="p-3.5 rounded-2xl bg-black/60 border border-neutral-800/80 text-left">
              <span className="text-[10px] font-bold text-neutral-500 uppercase tracking-wider block">
                TOPIC
              </span>
              <p className="text-xs font-semibold text-neutral-200 mt-0.5 leading-relaxed">
                {createdCall.topic}
              </p>
            </div>

            {/* 6-Character Join Code Box */}
            <div className="p-4 rounded-2xl bg-black border-2 border-orange-500/60 space-y-1">
              <div className="text-[11px] font-bold text-orange-400 uppercase tracking-widest">
                JOIN CODE
              </div>
              <div className="text-4xl font-extrabold font-mono tracking-widest text-white select-all">
                {createdCall.joinCode}
              </div>
              <p className="text-[10px] text-neutral-400">
                6-Character Unique Security Code
              </p>
            </div>

            {/* Action Buttons: Copy Code & Share Code */}
            <div className="grid grid-cols-2 gap-2.5 pt-1">
              <button
                id="copy-call-code-btn"
                onClick={handleCopyCode}
                className="py-2.5 px-3 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-white text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer"
              >
                {copied ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-400" />
                    <span>Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4" />
                    <span>Copy Code</span>
                  </>
                )}
              </button>

              <button
                id="share-call-code-btn"
                onClick={handleShareCode}
                className="py-2.5 px-3 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-white text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer"
              >
                {shared ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-400" />
                    <span>Shared!</span>
                  </>
                ) : (
                  <>
                    <Share2 className="w-4 h-4" />
                    <span>Share Code</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Prompt instruction */}
          <p className="text-xs text-center text-neutral-400 font-medium">
            Send this code to your friend.
          </p>

          {/* Primary Action Button: Start Waiting */}
          <button
            id="start-waiting-btn"
            onClick={handleStartWaiting}
            className="w-full py-3.5 px-4 rounded-2xl bg-orange-500 hover:bg-orange-600 active:scale-[0.98] text-white text-sm font-bold shadow-lg shadow-orange-500/20 transition-all cursor-pointer flex items-center justify-center gap-2"
          >
            <Users className="w-4 h-4" />
            <span>Start Waiting</span>
          </button>
        </motion.div>
      )}
    </div>
  );
};
