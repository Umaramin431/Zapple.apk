import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { useApp } from '../../context/AppContext';
import { callService } from '../../services/callService';
import { copyToClipboard } from '../../utils/clipboard';
import {
  requestCallMicrophone,
  isMicrophoneActive,
  getActiveCallMicrophone,
} from '../../utils/microphone';
import { MicrophonePermissionPanel } from './MicrophonePermissionPanel';
import {
  ArrowLeft,
  Copy,
  Check,
  Share2,
  Users,
  Mic,
  Loader2,
  Phone,
  Clock,
  AlertCircle,
  Bot,
} from 'lucide-react';

export const CallWaitingRoomScreen: React.FC = () => {
  const {
    activeCall,
    setActiveCall,
    setCurrentTab,
    currentUser,
    callDurationSeconds,
  } = useApp();

  const [copied, setCopied] = useState(false);
  const [friendJoined, setFriendJoined] = useState(false);
  const [participantName, setParticipantName] = useState<string>('');
  const [isStarting, setIsStarting] = useState(false);
  const [simulating, setSimulating] = useState(false);
  const [hasMicAccess, setHasMicAccess] = useState<boolean>(() => isMicrophoneActive());
  const [micStream, setMicStream] = useState<MediaStream | null>(() => getActiveCallMicrophone());
  const [startError, setStartError] = useState<string | null>(null);

  // Poll call state and listen to BroadcastChannel
  useEffect(() => {
    if (!activeCall) return;

    if (activeCall.status === 'joined' || activeCall.participantId) {
      setFriendJoined(true);
      setParticipantName(activeCall.participantName || 'Participant');
    }

    const interval = setInterval(async () => {
      try {
        const res = await callService.getCall(activeCall.callId);
        if (res.success && res.call) {
          setActiveCall(res.call);
          if (res.call.status === 'joined' || res.call.participantId) {
            setFriendJoined(true);
            setParticipantName(res.call.participantName || 'Participant');
          }
          if (res.call.status === 'active') {
            setCurrentTab('voice_call');
          }
        }
      } catch {}
    }, 1500);

    const unsubscribe = callService.subscribeBroadcast((msg) => {
      if (msg.callId === activeCall.callId) {
        if (msg.type === 'CALL_JOINED') {
          setFriendJoined(true);
          setParticipantName(msg.participantName || 'Participant');
        } else if (msg.type === 'CALL_STARTED') {
          setCurrentTab('voice_call');
        }
      }
    });

    return () => {
      clearInterval(interval);
      unsubscribe();
    };
  }, [activeCall, setActiveCall, setCurrentTab]);

  useEffect(() => {
    setHasMicAccess(isMicrophoneActive());
  }, []);

  const handleCopyCode = async () => {
    if (!activeCall) return;
    await copyToClipboard(activeCall.joinCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSimulateFriend = async () => {
    if (!activeCall) return;
    setSimulating(true);
    try {
      const res = await callService.joinCall(
        activeCall.joinCode,
        'simulated_friend_id',
        'Alex Sharma'
      );
      if (res.success) {
        setFriendJoined(true);
        setParticipantName('Alex Sharma');
        setActiveCall(res.call);
      }
    } finally {
      setSimulating(false);
    }
  };

  const handlePermissionGranted = (stream: MediaStream) => {
    setMicStream(stream);
    setHasMicAccess(true);
    setStartError(null);
  };

  const handlePermissionDenied = (error: string) => {
    setHasMicAccess(false);
    setMicStream(null);
  };

  const handleStartCallClick = async () => {
    setStartError(null);

    if (!hasMicAccess || !isMicrophoneActive()) {
      setIsStarting(true);
      const res = await requestCallMicrophone();
      setIsStarting(false);
      if (!res.success || !res.stream) {
        setStartError(
          res.error || 'Microphone access is required to start the voice call.'
        );
        return;
      }
      setHasMicAccess(true);
      setMicStream(res.stream);
    }

    setIsStarting(true);
    try {
      if (!activeCall) return;
      await callService.startCall(activeCall.callId, currentUser?.id || 'demo_user');
      setCurrentTab('voice_call');
    } catch (err: any) {
      setStartError(err?.message || 'Failed to start voice call.');
    } finally {
      setIsStarting(false);
    }
  };

  const handleCancelCall = async () => {
    if (activeCall) {
      await callService.leaveCall(activeCall.callId, currentUser?.id || 'demo_user', 'cancelled');
      setActiveCall(null);
    }
    setCurrentTab('home');
  };

  if (!activeCall) {
    return (
      <div className="min-h-screen bg-black text-white p-6 flex flex-col items-center justify-center text-center space-y-4">
        <p className="text-sm text-neutral-400">No active call found.</p>
        <button
          onClick={() => setCurrentTab('home')}
          className="px-4 py-2 rounded-xl bg-white text-black font-semibold text-xs transition-colors hover:bg-neutral-200 cursor-pointer"
        >
          Return to Home
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white p-4 space-y-4 pb-28 max-w-md mx-auto w-full">
      {/* Top Bar */}
      <div className="flex items-center justify-between pt-2">
        <button
          onClick={handleCancelCall}
          className="p-2 rounded-xl bg-neutral-950 hover:bg-neutral-900 border border-neutral-800 text-neutral-300 hover:text-white transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>
        <span className="text-xs font-medium text-neutral-400">
          Waiting Room
        </span>
      </div>

      {/* Header Info */}
      <div className="text-center space-y-1.5 py-3">
        <h1 className="text-lg font-bold text-white tracking-tight">
          {friendJoined ? 'Participant Connected' : 'Waiting for Participant'}
        </h1>
        <p className="text-xs text-neutral-400 max-w-xs mx-auto">
          {friendJoined
            ? `${participantName} has joined. Check microphone to start call.`
            : 'Share the invite code with someone to start talking.'}
        </p>
      </div>

      {/* Invite Code Card */}
      <div className="bg-neutral-950 border border-neutral-900 rounded-2xl p-5 text-center space-y-3">
        <div className="text-xs font-medium text-neutral-400 uppercase tracking-wider">
          Invite Code
        </div>

        <div className="flex items-center justify-center gap-3 bg-black border border-neutral-800 rounded-xl py-2.5 px-4">
          <span className="text-2xl font-bold tracking-widest text-white font-mono">
            {activeCall.joinCode}
          </span>
          <button
            id="copy-waiting-code-btn"
            onClick={handleCopyCode}
            className="p-2 rounded-lg bg-neutral-900 hover:bg-neutral-800 text-neutral-300 hover:text-white transition-colors cursor-pointer"
            title="Copy Code"
          >
            {copied ? <Check className="w-4 h-4 text-white" /> : <Copy className="w-4 h-4" />}
          </button>
        </div>

        {/* Topic Preview */}
        <div className="p-3 rounded-xl bg-black border border-neutral-900 text-left space-y-1">
          <span className="text-[10px] font-medium text-neutral-500 uppercase tracking-wider block">
            Topic
          </span>
          <p className="text-xs text-white">
            {activeCall.topic}
          </p>
        </div>
      </div>

      {/* Status indicator */}
      <div className="bg-neutral-950 border border-neutral-900 rounded-xl p-3.5 flex items-center justify-between text-xs">
        <div className="flex items-center gap-2">
          <span
            className={`w-2 h-2 rounded-full ${
              friendJoined ? 'bg-white' : 'bg-neutral-600 animate-pulse'
            }`}
          />
          <span className="text-neutral-300">
            {friendJoined ? (
              <span className="text-white font-medium">
                2 of 2 participants ready
              </span>
            ) : (
              'Waiting for 2nd participant…'
            )}
          </span>
        </div>

        <span className="text-neutral-400 font-medium flex items-center gap-1">
          <Clock className="w-3.5 h-3.5 text-neutral-500" /> 3 Minutes
        </span>
      </div>

      {/* Microphone Permission Panel */}
      <MicrophonePermissionPanel
        onPermissionGranted={handlePermissionGranted}
        onPermissionDenied={handlePermissionDenied}
        isCallStarting={isStarting}
      />

      {startError && (
        <div className="p-3.5 rounded-xl bg-neutral-950 border border-neutral-800 text-neutral-300 text-xs flex items-start gap-2.5">
          <AlertCircle className="w-4 h-4 text-neutral-400 shrink-0 mt-0.5" />
          <div className="flex-1 space-y-0.5">
            <p className="font-semibold text-white">Microphone Error</p>
            <p className="text-[11px] text-neutral-400 leading-relaxed">{startError}</p>
          </div>
        </div>
      )}

      {/* Action Buttons */}
      {friendJoined ? (
        <div className="space-y-2 pt-2">
          <button
            id="start-voice-call-btn"
            onClick={handleStartCallClick}
            disabled={isStarting || !hasMicAccess}
            className={`w-full py-3.5 px-4 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-2 ${
              hasMicAccess
                ? 'bg-white hover:bg-neutral-200 text-black shadow-sm'
                : 'bg-neutral-900 text-neutral-500 cursor-not-allowed border border-neutral-800'
            }`}
          >
            {isStarting ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin text-black" />
                <span>Connecting Call…</span>
              </>
            ) : hasMicAccess ? (
              <>
                <Phone className="w-4 h-4" />
                <span>Start Call</span>
              </>
            ) : (
              <span>Enable Microphone to Start</span>
            )}
          </button>
        </div>
      ) : (
        <div className="space-y-2 pt-2">
          <button
            id="simulate-friend-btn"
            type="button"
            onClick={handleSimulateFriend}
            disabled={simulating}
            className="w-full py-2.5 px-3 rounded-xl bg-neutral-950 hover:bg-neutral-900 border border-neutral-800 text-neutral-300 hover:text-white text-xs font-medium transition-colors cursor-pointer flex items-center justify-center gap-2"
          >
            <Bot className="w-3.5 h-3.5 text-neutral-400" />
            <span>{simulating ? 'Connecting…' : 'Simulate Participant (Test)'}</span>
          </button>
        </div>
      )}
    </div>
  );
};
