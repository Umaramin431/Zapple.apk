import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import confetti from 'canvas-confetti';
import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signInWithPopup,
  signOut,
  onAuthStateChanged,
  deleteUser,
  reauthenticateWithCredential,
  reauthenticateWithPopup,
  EmailAuthProvider,
} from 'firebase/auth';
import { doc, deleteDoc } from 'firebase/firestore';
import { auth, db, googleProvider, checkEmailPasswordProviderEnabled } from '../lib/firebase';
import {
  User,
  UserRole,
  Wallet,
  Transaction,
  AppNotification,
  SupportTicket,
  ActiveTab,
  TicketStatus,
  Call,
  CallReward,
  RewardVerificationStatus,
  UserPaymentDetails,
  Payout,
  CallInvitation,
  DailyPool,
} from '../types';
import { callService } from '../services/callService';
import { poolService } from '../services/poolService';
import {
  INITIAL_USERS,
  INITIAL_WALLET,
  INITIAL_TASKS,
  INITIAL_SUBMISSIONS,
  INITIAL_TRANSACTIONS,
  INITIAL_WITHDRAWALS,
  INITIAL_NOTIFICATIONS,
  INITIAL_TICKETS,
} from '../data/initialData';

export interface UserCallItem {
  callId: string;
  topic: string;
  otherParticipant: string;
  date: string;
  status: 'Pending' | 'Verified' | 'Rejected' | string;
  backendStatus?: string;
  reward: string;
  actualDurationSeconds: number;
  joinCode: string;
}

export interface HoldingItem {
  id: string;
  callId: string;
  amount: number;
  status: RewardVerificationStatus;
  verifiedAt?: string;
  holdingPeriodEndsAt?: string;
  isMatured?: boolean;
  daysRemaining: number;
}

export interface AuthApiResponse {
  success?: boolean;
  user?: User;
  wallet?: Wallet;
  isBanned?: boolean;
  status?: string;
  banReason?: string;
  error?: string;
  token?: string;
}

// Resilient API Fetcher that handles non-JSON / HTML server error responses gracefully
export const safeFetchJson = async <T = any>(
  url: string,
  options?: RequestInit
): Promise<{ success: boolean; data?: T; status: number; error?: string }> => {
  try {
    const res = await fetch(url, {
      ...options,
      headers: {
        'Accept': 'application/json',
        ...(options?.headers || {}),
      },
    });

    const contentType = res.headers.get('content-type') || '';
    const text = await res.text();

    if (!text) {
      return {
        success: res.ok,
        status: res.status,
        error: res.ok ? undefined : `Server returned status ${res.status}`,
      };
    }

    if (contentType.includes('application/json') || text.trim().startsWith('{') || text.trim().startsWith('[')) {
      try {
        const parsed = JSON.parse(text);
        return {
          success: res.ok && parsed.success !== false,
          data: parsed,
          status: res.status,
          error: parsed.error || (res.ok ? undefined : `Request failed (${res.status})`),
        };
      } catch {
        return {
          success: false,
          status: res.status,
          error: `Failed to parse response (${res.status})`,
        };
      }
    }

    return {
      success: false,
      status: res.status,
      error: `Server returned non-JSON response (${res.status})`,
    };
  } catch (err: any) {
    return {
      success: false,
      status: 0,
      error: err?.message || 'Network communication error',
    };
  }
};

interface AppContextType {
  currentUser: User | null;
  users: User[];
  wallet: Wallet;
  transactions: Transaction[];
  notifications: AppNotification[];
  tickets: SupportTicket[];
  currentTab: ActiveTab;
  setCurrentTab: (tab: ActiveTab) => void;
  showWithdrawalModal: boolean;
  setShowWithdrawalModal: (show: boolean) => void;
  darkMode: boolean;
  setDarkMode: React.Dispatch<React.SetStateAction<boolean>>;

  // SYSTEM 1: Real Daily Earning Pool
  dailyPool: DailyPool | null;
  refreshDailyPool: () => Promise<void>;
  updateDailyPoolConfig: (totalPoolAmount: number, resetTimeUTC?: string) => Promise<{ success: boolean; message?: string }>;
  resetDailyPoolNow: () => Promise<{ success: boolean; message?: string }>;

  // Admin Dashboard and Audits
  adminOverview: any | null;
  refreshAdminOverview: () => Promise<void>;
  updatePayoutStatus: (payoutId: string, status: string, referenceNumber?: string, failureReason?: string) => Promise<{ success: boolean; message?: string }>;
  adminReviewCall: (callId: string, decision: 'VERIFIED' | 'REJECTED', reason?: string) => Promise<{ success: boolean; message?: string }>;

  // Real User Calls & Holdings
  userCalls: UserCallItem[];
  refreshUserCalls: () => Promise<void>;
  holdings: HoldingItem[];
  refreshWallet: () => Promise<void>;
  userPayouts: Payout[];
  refreshUserPayouts: () => Promise<void>;
  matureHoldings: () => Promise<{ success: boolean; message?: string }>;
  submitAppeal: (callId: string, reason: string) => Promise<{ success: boolean; message?: string; error?: string }>;

  // Payment Details & Real Payouts
  paymentDetails: UserPaymentDetails | null;
  savePaymentDetails: (details: {
    payoutMethod: 'UPI' | 'Bank Transfer';
    upiId?: string;
    bankAccountNumber?: string;
    bankIfsc?: string;
    accountHolderName?: string;
  }) => Promise<{ success: boolean; error?: string; message?: string }>;
  requestPayout: (amount: number) => Promise<{ success: boolean; payout?: any; error?: string; message?: string }>;

  // User Actions
  isEmailAuthAvailable: boolean;
  checkEmailAuthStatus: () => Promise<boolean>;
  loginWithEmailPassword: (
    email: string,
    password: string
  ) => Promise<{ success: boolean; error?: string; isNewUser?: boolean }>;
  loginWithGoogle: () => Promise<{ success: boolean; error?: string }>;
  loginWithOtp?: (mobile: string, name?: string, referralCode?: string) => Promise<boolean>;
  logout: () => void;
  deleteAccount: (passwordForReauth?: string) => Promise<{
    success: boolean;
    requiresReauth?: boolean;
    authProvider?: 'password' | 'google.com';
    error?: string;
  }>;
  reauthenticateGoogleAndDelete: () => Promise<{
    success: boolean;
    error?: string;
  }>;
  accountDeletedNotice: string | null;
  setAccountDeletedNotice: (notice: string | null) => void;
  markNotificationAsRead: (id: string) => void;
  markAllNotificationsAsRead: () => void;
  createSupportTicket: (subject: string, message: string) => void;
  updateUserProfile: (name: string, mobile: string) => void;

  // Debate Calls Actions & State
  activeCall: Call | null;
  setActiveCall: (call: Call | null) => void;
  activeCallRole: 'creator' | 'participant' | null;
  setActiveCallRole: (role: 'creator' | 'participant' | null) => void;
  callDurationSeconds: number;
  setCallDurationSeconds: (seconds: number) => void;
  createDebateCall: (topic: string, duration?: number) => Promise<Call>;
  joinDebateCall: (code: string) => Promise<{ success: boolean; call?: Call; error?: string }>;
  creditDebateReward: (callId: string, amount?: number) => void;
  callRewards: CallReward[];
  createPendingCallReward: (callId: string, amount?: number) => CallReward;
  verifyCallSession: (
    callId: string,
    simulateRejection?: boolean,
    transcript?: any[]
  ) => Promise<{
    success: boolean;
    status: RewardVerificationStatus;
    reason?: string;
    message?: string;
  }>;

  // Direct Call Again & Real-Time Invitations
  outgoingInvitation: CallInvitation | null;
  setOutgoingInvitation: React.Dispatch<React.SetStateAction<CallInvitation | null>>;
  incomingInvitation: CallInvitation | null;
  setIncomingInvitation: React.Dispatch<React.SetStateAction<CallInvitation | null>>;
  initiateCallAgain: (
    previousCallId?: string,
    customTopic?: string,
    targetRecipientId?: string,
    targetRecipientName?: string
  ) => Promise<{ success: boolean; call: Call; invitation: CallInvitation }>;
  acceptIncomingCall: (invitationId: string) => Promise<{ success: boolean; call: Call } | undefined>;
  declineIncomingCall: (invitationId: string) => Promise<void>;
  cancelOutgoingCall: () => Promise<void>;

  // Legacy/Compatibility stubs to avoid breaking older components
  tasks: any[];
  submissions: any[];
  withdrawals: any[];
  selectedTaskId: string | null;
  setSelectedTaskId: (id: string | null) => void;
  isDailyBonusClaimed: boolean;
  mobileFrameMode: boolean;
  setMobileFrameMode: React.Dispatch<React.SetStateAction<boolean>>;
  claimDailyBonus: () => void;
  submitTask: (taskId: string, data: any) => boolean;
  requestDemoWithdrawal: (amount: number, paymentMethod: any, accountDetails: string) => { success: boolean; message: string };
  approveSubmission: (submissionId: string, feedback?: string) => void;
  rejectSubmission: (submissionId: string, feedback: string) => void;
  approveWithdrawal: (withdrawalId: string, adminNote?: string) => void;
  rejectWithdrawal: (withdrawalId: string, reason: string) => void;
  createTask: (task: any) => void;
  updateTask: (taskId: string, partial: any) => void;
  deleteTask: (taskId: string) => void;
  replySupportTicket: (ticketId: string, reply: string, status: TicketStatus) => void;
  broadcastAnnouncement: (title: string, message: string) => void;
  resetDemoData: () => void;
  isOffline: boolean;
  checkConnection: () => Promise<boolean>;
}

const STORAGE_KEYS = {
  USER: 'talkreward_user_prod',
  USERS: 'talkreward_users_prod',
  ROLE: 'talkreward_role_prod',
  DARK_MODE: 'talkreward_dark_mode_prod',
};

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Real network/offline state
  const [isOffline, setIsOffline] = useState<boolean>(!navigator.onLine);

  const checkConnection = useCallback(async (): Promise<boolean> => {
    if (!navigator.onLine) {
      setIsOffline(true);
      return false;
    }
    try {
      const res = await fetch('/api/health', { method: 'GET', cache: 'no-store' });
      if (res.ok) {
        setIsOffline(false);
        return true;
      } else {
        setIsOffline(true);
        return false;
      }
    } catch {
      setIsOffline(true);
      return false;
    }
  }, []);

  useEffect(() => {
    const handleOnline = () => {
      checkConnection();
    };
    const handleOffline = () => {
      setIsOffline(true);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Initial check
    checkConnection();

    // Periodic check every 10s
    const interval = setInterval(checkConnection, 10000);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      clearInterval(interval);
    };
  }, [checkConnection]);
  // Real User state
  const [accountDeletedNotice, setAccountDeletedNotice] = useState<string | null>(null);
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.USER);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {}
    }
    return null;
  });

  const [users, setUsers] = useState<User[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.USERS);
    return saved ? JSON.parse(saved) : INITIAL_USERS;
  });

  // Real Wallet
  const [wallet, setWallet] = useState<Wallet>(INITIAL_WALLET);
  const [holdings, setHoldings] = useState<HoldingItem[]>([]);
  const [userCalls, setUserCalls] = useState<UserCallItem[]>([]);
  const [paymentDetails, setPaymentDetails] = useState<UserPaymentDetails | null>(null);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [notifications, setNotifications] = useState<AppNotification[]>(INITIAL_NOTIFICATIONS);
  const [tickets, setTickets] = useState<SupportTicket[]>(INITIAL_TICKETS);

  // SYSTEM 1: Real Daily Earning Pool
  const [dailyPool, setDailyPool] = useState<DailyPool | null>(null);
  const [adminOverview, setAdminOverview] = useState<any | null>(null);

  const [currentTab, setCurrentTab] = useState<ActiveTab>('home');
  const [darkMode, setDarkMode] = useState<boolean>(true); // Modern dark theme
  const [showWithdrawalModal, setShowWithdrawalModal] = useState<boolean>(false);
  const [mobileFrameMode, setMobileFrameMode] = useState<boolean>(false);
  const [selectedTaskId, setSelectedTaskId] = useState<string | null>(null);
  const [isDailyBonusClaimed, setIsDailyBonusClaimed] = useState<boolean>(false);
  const [isEmailAuthAvailable, setIsEmailAuthAvailable] = useState<boolean>(false);

  // Check if Email/Password sign-in provider is enabled in connected Firebase project
  const checkEmailAuthStatus = useCallback(async () => {
    const available = await checkEmailPasswordProviderEnabled();
    setIsEmailAuthAvailable(available);
    return available;
  }, []);

  useEffect(() => {
    let isMounted = true;
    checkEmailPasswordProviderEnabled().then((available) => {
      if (isMounted) {
        setIsEmailAuthAvailable(available);
      }
    });
    return () => {
      isMounted = false;
    };
  }, []);

  // Refresh daily pool from backend
  const refreshDailyPool = useCallback(async () => {
    try {
      const res = await poolService.getDailyPool();
      if (res.success && res.pool) {
        setDailyPool(res.pool);
      }
    } catch (err) {
      console.error('Failed to fetch daily pool', err);
    }
  }, []);

  // Update daily pool config (admin)
  const updateDailyPoolConfig = useCallback(
    async (totalPoolAmount: number, resetTimeUTC?: string) => {
      const res = await poolService.updatePoolConfig(totalPoolAmount, resetTimeUTC);
      if (res.success && res.pool) {
        setDailyPool(res.pool);
      }
      return res;
    },
    []
  );

  // Calls state
  const [activeCall, setActiveCall] = useState<Call | null>(null);
  const [activeCallRole, setActiveCallRole] = useState<'creator' | 'participant' | null>(null);
  const [callDurationSeconds, setCallDurationSeconds] = useState<number>(180);
  const [callRewards, setCallRewards] = useState<CallReward[]>([]);
  const [outgoingInvitation, setOutgoingInvitation] = useState<CallInvitation | null>(null);
  const [incomingInvitation, setIncomingInvitation] = useState<CallInvitation | null>(null);

  // Refresh user wallet & holdings from server
  const refreshWallet = useCallback(async () => {
    if (!currentUser?.id) return;
    try {
      const res = await callService.getWallet(currentUser.id);
      if (res.success && res.wallet) {
        setWallet(res.wallet);
        setHoldings(res.holdings || []);
      }
    } catch (err) {
      console.error('Failed to fetch wallet from server', err);
    }
  }, [currentUser?.id]);

  // Real user payouts (withdrawal receipts)
  const [userPayouts, setUserPayouts] = useState<Payout[]>([]);

  const refreshUserPayouts = useCallback(async () => {
    if (!currentUser?.id) return;
    try {
      const res = await callService.getUserPayouts(currentUser.id);
      if (res.success && Array.isArray(res.payouts)) {
        setUserPayouts(res.payouts);
      }
    } catch (err) {
      console.error('Failed to fetch user payouts', err);
    }
  }, [currentUser?.id]);

  // Refresh user real previous calls from server
  const refreshUserCalls = useCallback(async () => {
    if (!currentUser?.id) return;
    try {
      const res = await callService.getUserCalls(currentUser.id);
      if (res.success && Array.isArray(res.calls)) {
        setUserCalls(res.calls);
      }
    } catch (err) {
      console.error('Failed to fetch user calls', err);
    }
  }, [currentUser?.id]);

  // Reset daily pool now (admin)
  const resetDailyPoolNow = useCallback(async () => {
    const res = await poolService.resetPoolNow();
    if (res.success && res.pool) {
      setDailyPool(res.pool);
    }
    return res;
  }, []);

  // Refresh Admin Overview
  const refreshAdminOverview = useCallback(async () => {
    const isAdmin = currentUser?.role === 'admin' || currentUser?.email?.toLowerCase() === 'ff280270@gmail.com';
    if (!isAdmin) return;

    try {
      const adminId = currentUser?.id || currentUser?.email || 'usr_admin_ff280270';
      const res = await poolService.getAdminOverview(adminId);
      if (res && res.success) {
        setAdminOverview(res);
        if (res.pool) setDailyPool(res.pool);
      }
    } catch (err) {
      console.warn('refreshAdminOverview notice:', err);
    }
  }, [currentUser?.role, currentUser?.email, currentUser?.id]);

  // Admin update payout status
  const updatePayoutStatus = useCallback(
    async (payoutId: string, status: string, referenceNumber?: string, failureReason?: string) => {
      const res = await poolService.updatePayoutStatus(payoutId, status, referenceNumber, failureReason);
      await refreshAdminOverview();
      return res;
    },
    [refreshAdminOverview]
  );

  // Admin review call
  const adminReviewCall = useCallback(
    async (callId: string, decision: 'VERIFIED' | 'REJECTED', reason?: string) => {
      const res = await poolService.reviewCall(callId, decision, reason, currentUser?.name);
      await refreshAdminOverview();
      await refreshUserCalls();
      await refreshWallet();
      return res;
    },
    [currentUser?.name, refreshAdminOverview, refreshUserCalls, refreshWallet]
  );

  // Refresh payment details from server
  const refreshPaymentDetails = useCallback(async () => {
    if (!currentUser?.id) return;
    try {
      const res = await callService.getPaymentDetails(currentUser.id);
      if (res.success && res.paymentDetails) {
        setPaymentDetails(res.paymentDetails);
      }
    } catch (err) {
      console.error('Failed to fetch payment details', err);
    }
  }, [currentUser?.id]);

  // Refresh transactions from server
  const refreshTransactions = useCallback(async () => {
    if (!currentUser?.id) return;
    try {
      const res = await callService.getTransactions(currentUser.id);
      if (res.success && Array.isArray(res.transactions)) {
        setTransactions(res.transactions);
      }
    } catch (err) {
      console.error('Failed to fetch transactions', err);
    }
  }, [currentUser?.id]);

  // Initial and reactive synchronization with real backend
  useEffect(() => {
    refreshDailyPool();
    if (currentUser?.id) {
      refreshWallet();
      refreshUserCalls();
      refreshPaymentDetails();
      refreshTransactions();
      refreshUserPayouts();
      localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(currentUser));
    }
  }, [currentUser?.id, refreshDailyPool, refreshWallet, refreshUserCalls, refreshPaymentDetails, refreshTransactions, refreshUserPayouts]);

  // Auto-refresh data periodically, on window focus, and on cross-tab broadcast events
  useEffect(() => {
    const handleSync = () => {
      refreshDailyPool();
      if (currentUser?.id) {
        refreshWallet();
        refreshUserCalls();
        refreshUserPayouts();
      }
    };

    const timer = setInterval(handleSync, 5000);
    window.addEventListener('focus', handleSync);

    let channel: BroadcastChannel | null = null;
    if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
      try {
        channel = new BroadcastChannel('zapple_channel');
        channel.onmessage = (event) => {
          if (
            event.data?.type === 'CALL_REVIEWED' ||
            event.data?.type === 'CALL_COMPLETED' ||
            event.data?.type === 'CALL_VERIFIED' ||
            event.data?.type === 'CALL_STARTED'
          ) {
            handleSync();
          }
        };
      } catch {}
    }

    return () => {
      clearInterval(timer);
      window.removeEventListener('focus', handleSync);
      channel?.close();
    };
  }, [currentUser?.id, refreshDailyPool, refreshWallet, refreshUserCalls, refreshUserPayouts]);

  // Handle dark mode DOM class
  useEffect(() => {
    document.documentElement.classList.add('dark');
  }, []);

  // Listen to Firebase Auth state changes
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
      if (!fbUser) {
        // If Firebase Auth has no active user, clear local session if not explicitly stored
        if (localStorage.getItem(STORAGE_KEYS.USER)) {
          localStorage.removeItem(STORAGE_KEYS.USER);
          setCurrentUser(null);
        }
      } else {
        // User is authenticated in Firebase Auth -> Ensure profile exists & sync with backend
        try {
          const userRes = await safeFetchJson<{ success: boolean; user?: User; wallet?: Wallet; isBanned?: boolean; banReason?: string }>(
            `/api/auth/user/${fbUser.uid}`
          );

          if (userRes.success && userRes.data?.user) {
            const syncedUser = userRes.data.user;
            setCurrentUser(syncedUser);
            localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(syncedUser));
            if (userRes.data.wallet) setWallet(userRes.data.wallet);
          } else {
            // User might be new or not in backend cache yet -> Register/Sync via /api/auth/login
            const email = fbUser.email || '';
            const name = fbUser.displayName || (email ? email.split('@')[0] : 'Debater');
            const loginRes = await safeFetchJson<{ success: boolean; user?: User; wallet?: Wallet; isBanned?: boolean; banReason?: string }>(
              '/api/auth/login',
              {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                  email: fbUser.email,
                  name: name,
                  firebaseUid: fbUser.uid,
                  avatar: fbUser.photoURL || undefined,
                }),
              }
            );

            if (loginRes.data?.user) {
              const u = loginRes.data.user;
              if (loginRes.data.isBanned || u.status === 'BANNED') {
                u.status = 'BANNED';
                if (loginRes.data.banReason) u.banReason = loginRes.data.banReason;
              }
              setCurrentUser(u);
              localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(u));
              if (loginRes.data.wallet) setWallet(loginRes.data.wallet);
            } else {
              // Graceful fallback to client Firebase credentials
              const isAdmin = email.toLowerCase() === 'ff280270@gmail.com';
              const localUser: User = {
                id: fbUser.uid,
                name: name,
                email: email,
                mobile: '',
                createdAt: new Date().toISOString(),
                referralCode: `ZAP-${name.substring(0, 4).toUpperCase()}${Math.floor(10 + Math.random() * 90)}`,
                role: isAdmin ? 'admin' : 'user',
                status: 'ACTIVE',
                avatar: fbUser.photoURL || undefined,
              };
              setCurrentUser(localUser);
              localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(localUser));
            }
          }
        } catch (err) {
          console.warn('Failed to sync auth state with backend, using offline fallback', err);
        }
      }
    });

    return () => unsubscribe();
  }, []);

  // Save payment details
  const savePaymentDetails = async (details: {
    payoutMethod: 'UPI' | 'Bank Transfer';
    upiId?: string;
    bankAccountNumber?: string;
    bankIfsc?: string;
    accountHolderName?: string;
  }) => {
    if (!currentUser?.id) return { success: false, error: 'User not logged in' };
    const res = await callService.savePaymentDetails(currentUser.id, details);
    if (res.success && res.paymentDetails) {
      setPaymentDetails(res.paymentDetails);
      return { success: true, message: res.message || 'Payment destination saved successfully!' };
    }
    return { success: false, error: res.error || 'Failed to save payment details' };
  };

  // Request real Payout
  const requestPayout = async (amount: number) => {
    if (!currentUser?.id) return { success: false, error: 'User not logged in' };
    const res = await callService.requestPayout(currentUser.id, amount);
    if (res.success) {
      await refreshWallet();
      await refreshTransactions();
      try {
        confetti({ particleCount: 60, spread: 70, origin: { y: 0.6 } });
      } catch {}
      return { success: true, payout: res.payout, message: res.message };
    }
    return { success: false, error: res.error || 'Payout request failed' };
  };

  // Fast forward 15-day holding period (test mode accelerator)
  const matureHoldings = async () => {
    if (!currentUser?.id) return { success: false };
    const res = await callService.matureHoldings(currentUser.id);
    if (res.success) {
      await refreshWallet();
      await refreshTransactions();
      try {
        confetti({ particleCount: 50, spread: 60, origin: { y: 0.7 } });
      } catch {}
      return { success: true, message: res.message };
    }
    return { success: false, message: res.message };
  };

  // Submit appeal for rejected call
  const submitAppeal = async (callId: string, reason: string) => {
    if (!currentUser?.id) return { success: false, error: 'User not logged in' };
    const res = await callService.submitAppeal(callId, currentUser.id, reason);
    if (res.success) {
      await refreshUserCalls();
      return { success: true, message: res.message };
    }
    return { success: false, error: res.error };
  };

  // Auth: Email + Password Authentication (Login or Create Account)
  const loginWithEmailPassword = async (
    email: string,
    password: string
  ): Promise<{ success: boolean; error?: string; isNewUser?: boolean }> => {
    try {
      const cleanEmail = email.trim().toLowerCase();
      if (!cleanEmail || !cleanEmail.includes('@')) {
        return { success: false, error: 'Please enter a valid email address.' };
      }
      if (!password || password.length < 6) {
        return { success: false, error: 'Password must be at least 6 characters long.' };
      }

      const isOpNotAllowed = (err: any) => {
        const c = err?.code || '';
        const m = (err?.message || '').toLowerCase();
        return (
          c === 'auth/operation-not-allowed' ||
          c === 'auth/admin-restricted-operation' ||
          m.includes('operation-not-allowed') ||
          m.includes('operation_not_allowed') ||
          m.includes('requested action is invalid') ||
          m.includes('password_login_disabled')
        );
      };

      const ownerRequiredError =
        'Email & Password authentication is not enabled for this Firebase project. It must be enabled by the Firebase project owner in the Firebase Console (Authentication > Sign-in method). Please continue with Google.';

      let userCredential;
      let isNew = false;

      // Attempt sign-in first
      try {
        userCredential = await signInWithEmailAndPassword(auth, cleanEmail, password);
      } catch (signInErr: any) {
        if (isOpNotAllowed(signInErr)) {
          return { success: false, error: ownerRequiredError };
        }

        const errCode = signInErr?.code || '';

        // If user not found or invalid credentials, attempt account creation
        if (
          errCode === 'auth/user-not-found' ||
          errCode === 'auth/invalid-credential' ||
          errCode === 'auth/user-disabled'
        ) {
          try {
            userCredential = await createUserWithEmailAndPassword(auth, cleanEmail, password);
            isNew = true;
          } catch (createErr: any) {
            if (isOpNotAllowed(createErr)) {
              return { success: false, error: ownerRequiredError };
            }
            const createCode = createErr?.code || '';
            if (createCode === 'auth/email-already-in-use') {
              return { success: false, error: 'Incorrect password for this email account. Please try again.' };
            } else if (createCode === 'auth/weak-password') {
              return { success: false, error: 'Password must be at least 6 characters long.' };
            } else if (createCode === 'auth/invalid-email') {
              return { success: false, error: 'Please enter a valid email address.' };
            } else {
              return { success: false, error: createErr?.message || 'Authentication failed. Please verify your credentials.' };
            }
          }
        } else if (errCode === 'auth/wrong-password') {
          return { success: false, error: 'Incorrect password for this email account. Please try again.' };
        } else if (errCode === 'auth/invalid-email') {
          return { success: false, error: 'Please enter a valid email address.' };
        } else if (errCode === 'auth/too-many-requests') {
          return { success: false, error: 'Too many attempts. Access is temporarily locked; please try again later.' };
        } else {
          return { success: false, error: signInErr?.message || 'Failed to sign in. Please verify your credentials.' };
        }
      }

      if (!userCredential?.user) {
        return { success: false, error: 'Failed to verify authenticated credentials.' };
      }

      const fbUser = userCredential.user;
      const loginRes = await safeFetchJson<AuthApiResponse>('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: fbUser.email || cleanEmail,
          name: fbUser.displayName || cleanEmail.split('@')[0],
          firebaseUid: fbUser.uid,
          avatar: fbUser.photoURL || undefined,
        }),
      });

      const data: AuthApiResponse = loginRes.data || {};

      // Check if user is banned on backend
      if (data.isBanned || data.status === 'BANNED' || data.user?.status === 'BANNED') {
        const bannedUser: User = data.user || {
          id: fbUser.uid,
          name: fbUser.displayName || cleanEmail.split('@')[0],
          email: fbUser.email || cleanEmail,
          mobile: '',
          createdAt: new Date().toISOString(),
          referralCode: 'ZAP-BANNED',
          role: 'user',
          status: 'BANNED',
          banReason: data.banReason || 'Violation of debate community guidelines',
          bannedAt: new Date().toISOString(),
        };
        bannedUser.status = 'BANNED';
        if (data.banReason) bannedUser.banReason = data.banReason;
        setCurrentUser(bannedUser);
        localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(bannedUser));
        return { success: true };
      }

      if (data.success && data.user) {
        setCurrentUser(data.user);
        localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(data.user));
        setUsers((prev) => {
          if (!prev.some((u) => u.id === data.user!.id)) return [...prev, data.user!];
          return prev;
        });
        if (data.wallet) setWallet(data.wallet);
        setCurrentTab('home');
        return { success: true, isNewUser: isNew };
      }

      // Fallback if backend returned non-fatal error but Firebase Auth succeeded
      const fallbackUser: User = {
        id: fbUser.uid,
        name: fbUser.displayName || cleanEmail.split('@')[0],
        email: fbUser.email || cleanEmail,
        mobile: '',
        createdAt: new Date().toISOString(),
        referralCode: `ZAP-${(fbUser.displayName || cleanEmail).substring(0, 4).toUpperCase()}${Math.floor(10 + Math.random() * 90)}`,
        role: (fbUser.email || cleanEmail).toLowerCase() === 'ff280270@gmail.com' ? 'admin' : 'user',
        status: 'ACTIVE',
        avatar: fbUser.photoURL || undefined,
      };
      setCurrentUser(fallbackUser);
      localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(fallbackUser));
      setCurrentTab('home');
      return { success: true, isNewUser: isNew };
    } catch (err: any) {
      console.error('Email password login error:', err);
      return { success: false, error: err?.message || 'Unexpected error during authentication.' };
    }
  };

  // Auth: Google OAuth Authentication
  const loginWithGoogle = async (): Promise<{ success: boolean; error?: string }> => {
    try {
      const result = await signInWithPopup(auth, googleProvider);
      const fbUser = result.user;
      if (!fbUser) {
        return { success: false, error: 'Google sign-in did not return a valid user.' };
      }

      const email = fbUser.email || '';
      const name = fbUser.displayName || (email ? email.split('@')[0] : 'Debater');

      const loginRes = await safeFetchJson<AuthApiResponse>('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: fbUser.email,
          name: name,
          firebaseUid: fbUser.uid,
          avatar: fbUser.photoURL || undefined,
        }),
      });

      const data: AuthApiResponse = loginRes.data || {};

      // Check if user is banned on backend
      if (data.isBanned || data.status === 'BANNED' || data.user?.status === 'BANNED') {
        const bannedUser: User = data.user || {
          id: fbUser.uid,
          name: name,
          email: email,
          mobile: '',
          createdAt: new Date().toISOString(),
          referralCode: 'ZAP-BANNED',
          role: 'user',
          status: 'BANNED',
          banReason: data.banReason || 'Violation of debate community guidelines',
          bannedAt: new Date().toISOString(),
        };
        bannedUser.status = 'BANNED';
        if (data.banReason) bannedUser.banReason = data.banReason;
        setCurrentUser(bannedUser);
        localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(bannedUser));
        return { success: true };
      }

      if (data.success && data.user) {
        setCurrentUser(data.user);
        localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(data.user));
        setUsers((prev) => {
          if (!prev.some((u) => u.id === data.user!.id)) return [...prev, data.user!];
          return prev;
        });
        if (data.wallet) setWallet(data.wallet);
        setCurrentTab('home');
        return { success: true };
      }

      // Fallback: If server is starting up or response parsing issue, securely set the Firebase user
      const isAdmin = email.toLowerCase() === 'ff280270@gmail.com';
      const fallbackUser: User = {
        id: fbUser.uid,
        name: name,
        email: email,
        mobile: '',
        createdAt: new Date().toISOString(),
        referralCode: `ZAP-${name.substring(0, 4).toUpperCase()}${Math.floor(10 + Math.random() * 90)}`,
        role: isAdmin ? 'admin' : 'user',
        status: 'ACTIVE',
        avatar: fbUser.photoURL || undefined,
      };
      setCurrentUser(fallbackUser);
      localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(fallbackUser));
      setCurrentTab('home');
      return { success: true };
    } catch (err: any) {
      console.error('Google sign in error:', err);
      if (err?.code === 'auth/popup-closed-by-user') {
        return { success: false, error: 'Google sign-in window was closed before completing.' };
      }
      if (err?.code === 'auth/cancelled-popup-request') {
        return { success: false, error: 'Authentication was cancelled. Another popup is active.' };
      }
      if (err?.code === 'auth/popup-blocked') {
        return { success: false, error: 'Google sign-in popup was blocked by your browser. Please allow popups for this site and try again.' };
      }
      if (err?.code === 'auth/unauthorized-domain') {
        return { success: false, error: 'This domain is not in the Firebase Authorized Domains list. Please contact the Firebase project owner to add it in Authentication > Settings > Authorized domains.' };
      }
      return { success: false, error: err?.message || 'Failed to authenticate with Google.' };
    }
  };

  // Optional legacy sync
  const loginWithOtp = async (mobile: string, name?: string, referralCode?: string, firebaseUid?: string): Promise<boolean> => {
    try {
      const loginRes = await safeFetchJson<AuthApiResponse>('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mobile, name, referralCode, firebaseUid }),
      });
      const data: AuthApiResponse = loginRes.data || {};

      if (data.isBanned || data.status === 'BANNED' || data.user?.status === 'BANNED') {
        const bannedUser: User = data.user || {
          id: firebaseUid || `usr_${mobile}`,
          name: name || 'User',
          mobile: mobile,
          createdAt: new Date().toISOString(),
          referralCode: 'ZAP-BANNED',
          role: 'user',
          status: 'BANNED',
          banReason: data.banReason || 'Violation of debate community guidelines',
          bannedAt: new Date().toISOString(),
        };
        bannedUser.status = 'BANNED';
        if (data.banReason) bannedUser.banReason = data.banReason;
        setCurrentUser(bannedUser);
        localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(bannedUser));
        return true;
      }

      if (data.success && data.user) {
        setCurrentUser(data.user);
        localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(data.user));
        setUsers((prev) => {
          if (!prev.some((u) => u.id === data.user!.id)) return [...prev, data.user!];
          return prev;
        });
        if (data.wallet) setWallet(data.wallet);
        setCurrentTab('home');
        return true;
      }
      return false;
    } catch {
      return false;
    }
  };

  const logout = async () => {
    try {
      await signOut(auth);
    } catch (e) {
      console.error('Firebase signOut error', e);
    }
    localStorage.removeItem(STORAGE_KEYS.USER);
    setCurrentUser(null);
    setCurrentTab('home');
  };

  // Real Account Deletion with Firebase Auth removal & data scrubbing
  const deleteAccount = async (
    passwordForReauth?: string
  ): Promise<{
    success: boolean;
    requiresReauth?: boolean;
    authProvider?: 'password' | 'google.com';
    error?: string;
  }> => {
    const fbUser = auth.currentUser;
    const currentUserId = currentUser?.id || fbUser?.uid;

    if (!fbUser && !currentUserId) {
      return { success: false, error: 'No active authenticated user session found.' };
    }

    // 1. Delete user from Firebase Auth
    if (fbUser) {
      try {
        if (passwordForReauth && fbUser.email) {
          const credential = EmailAuthProvider.credential(fbUser.email, passwordForReauth);
          await reauthenticateWithCredential(fbUser, credential);
        }
        await deleteUser(fbUser);
      } catch (err: any) {
        console.error('Firebase deleteUser error:', err);
        const errCode = err?.code || '';
        if (errCode === 'auth/requires-recent-login') {
          const isGoogle = fbUser.providerData?.some((p) => p.providerId === 'google.com');
          return {
            success: false,
            requiresReauth: true,
            authProvider: isGoogle ? 'google.com' : 'password',
            error: 'For your security, please confirm your credentials before deleting your account.',
          };
        }
        if (errCode === 'auth/wrong-password' || errCode === 'auth/invalid-credential') {
          return { success: false, error: 'Incorrect password. Please verify your credentials.' };
        }
        return {
          success: false,
          error: err?.message || 'Failed to delete authentication account from Firebase.',
        };
      }
    }

    // 2. Remove user profile document from Firestore
    if (currentUserId) {
      try {
        await deleteDoc(doc(db, 'users', currentUserId));
      } catch (fsErr) {
        console.warn('Firestore doc cleanup note:', fsErr);
      }

      // 3. Call backend endpoint to anonymize and clean up user data
      try {
        await safeFetchJson('/api/auth/delete-account', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ userId: currentUserId }),
        });
      } catch (apiErr) {
        console.error('API delete-account error:', apiErr);
      }
    }

    // 4. Sign out completely, clear local storage and reset all app state
    try {
      await signOut(auth);
    } catch {}

    localStorage.removeItem(STORAGE_KEYS.USER);
    localStorage.removeItem(STORAGE_KEYS.USERS);
    setCurrentUser(null);
    setWallet(INITIAL_WALLET);
    setUserCalls([]);
    setTransactions([]);
    setHoldings([]);
    setPaymentDetails(null);
    setCurrentTab('home');
    setAccountDeletedNotice('Your account has been deleted.');

    return { success: true };
  };

  const reauthenticateGoogleAndDelete = async (): Promise<{
    success: boolean;
    error?: string;
  }> => {
    const fbUser = auth.currentUser;
    const currentUserId = currentUser?.id || fbUser?.uid;

    if (!fbUser) {
      return { success: false, error: 'No active Google session found.' };
    }

    try {
      await reauthenticateWithPopup(fbUser, googleProvider);
      await deleteUser(fbUser);
    } catch (err: any) {
      console.error('Google reauthenticate error:', err);
      if (err?.code === 'auth/popup-closed-by-user') {
        return { success: false, error: 'Google verification window was closed.' };
      }
      return {
        success: false,
        error: err?.message || 'Failed to re-authenticate with Google. Account was not deleted.',
      };
    }

    // Cleanup data
    if (currentUserId) {
      try {
        await deleteDoc(doc(db, 'users', currentUserId));
      } catch (fsErr) {
        console.warn('Firestore doc cleanup note:', fsErr);
      }

      try {
        await fetch('/api/auth/delete-account', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ userId: currentUserId }),
        });
      } catch (apiErr) {
        console.error('API delete-account error:', apiErr);
      }
    }

    try {
      await signOut(auth);
    } catch {}

    localStorage.removeItem(STORAGE_KEYS.USER);
    localStorage.removeItem(STORAGE_KEYS.USERS);
    setCurrentUser(null);
    setWallet(INITIAL_WALLET);
    setUserCalls([]);
    setTransactions([]);
    setHoldings([]);
    setPaymentDetails(null);
    setCurrentTab('home');
    setAccountDeletedNotice('Your account has been deleted.');

    return { success: true };
  };

  const updateUserProfile = (name: string, mobile: string) => {
    if (!currentUser) return;
    const updatedUser = { ...currentUser, name, mobile };
    setCurrentUser(updatedUser);
    setUsers((prev) => prev.map((u) => (u.id === currentUser.id ? updatedUser : u)));
  };

  const markNotificationAsRead = (id: string) => {
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)));
    fetch(`/api/notifications/${id}/read`, { method: 'POST' }).catch(() => {});
  };

  const markAllNotificationsAsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  };

  const createSupportTicket = (subject: string, message: string) => {
    if (!currentUser) return;
    const newTicket: SupportTicket = {
      id: `tkt_${Date.now()}`,
      userId: currentUser.id,
      userName: currentUser.name,
      subject,
      message,
      status: 'open',
      createdAt: new Date().toISOString(),
    };
    setTickets((prev) => [newTicket, ...prev]);
  };

  // Debate Calls
  const createDebateCall = async (topic: string, duration = callDurationSeconds): Promise<Call> => {
    const res = await callService.createCall(
      topic,
      currentUser?.id || 'usr_real_01',
      currentUser?.name || 'Debater Alpha',
      duration
    );
    setActiveCall(res.call);
    setActiveCallRole('creator');
    await refreshUserCalls();
    return res.call;
  };

  const joinDebateCall = async (
    code: string
  ): Promise<{ success: boolean; call?: Call; error?: string }> => {
    const res = await callService.joinCall(
      code,
      currentUser?.id || 'usr_real_02',
      currentUser?.name || 'Debater Beta'
    );
    if (res.success && res.call) {
      setActiveCall(res.call);
      setActiveCallRole('participant');
      await refreshUserCalls();
      return { success: true, call: res.call };
    }
    return { success: false, error: res.error };
  };

  const createPendingCallReward = (callId: string, amount = 20): CallReward => {
    const newReward: CallReward = {
      id: `rwd_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      callId,
      userId: currentUser?.id || 'usr_real_01',
      userName: currentUser?.name || 'User',
      amount,
      currency: 'INR',
      status: 'pending_verification',
      createdAt: new Date().toISOString(),
      checks: {
        bothJoined: true,
        durationMet: true,
        voiceActive: true,
        sessionCompleted: true,
        qualityRulesMet: true,
      },
      notes: '₹20 — Pending Verification: Voice session completed, awaiting AI quality verification.',
    };

    setCallRewards((prev) => [newReward, ...prev]);
    return newReward;
  };

  const verifyCallSession = async (
    callId: string,
    simulateRejection = false,
    transcript?: any[]
  ): Promise<{
    success: boolean;
    status: RewardVerificationStatus;
    reason?: string;
    message?: string;
    reward?: CallReward;
    aiVerification?: any;
  }> => {
    const userId = currentUser?.id || 'usr_real_01';
    const res = await callService.verifyCall(callId, userId, simulateRejection, transcript);

    if (res.reward) {
      setCallRewards((prev) => {
        const idx = prev.findIndex((r) => r.callId === callId && r.userId === userId);
        if (idx >= 0) {
          const updated = [...prev];
          updated[idx] = res.reward!;
          return updated;
        }
        return [res.reward!, ...prev];
      });
    } else if (res.status) {
      setCallRewards((prev) =>
        prev.map((r) =>
          r.callId === callId && r.userId === userId
            ? {
                ...r,
                status: res.status,
                aiVerification: (res as any).aiVerification || r.aiVerification,
                rejectionReason: res.reason || r.rejectionReason,
              }
            : r
        )
      );
    }

    await refreshWallet();
    await refreshUserCalls();
    await refreshTransactions();

    if (res.status === 'verified') {
      try {
        confetti({
          particleCount: 60,
          spread: 65,
          origin: { y: 0.65 },
        });
      } catch {}

      return {
        success: true,
        status: 'verified',
        message: '₹20 — Verified! (Entered 15-day holding period)',
        reward: res.reward,
        aiVerification: (res as any).aiVerification,
      };
    } else {
      return {
        success: false,
        status: res.status || 'rejected',
        reason: res.reason || 'Session did not meet participation rules.',
        reward: res.reward,
        aiVerification: (res as any).aiVerification,
      };
    }
  };

  const creditDebateReward = (callId: string, points = 20) => {
    createPendingCallReward(callId, points);
  };

  // Direct "Call Again" workflow: no codes shown, directly invites previous contact
  const initiateCallAgain = async (
    previousCallId?: string,
    customTopic?: string,
    targetRecipientId?: string,
    targetRecipientName?: string
  ): Promise<{ success: boolean; call: Call; invitation: CallInvitation }> => {
    const callerId = currentUser?.id || 'usr_real_01';
    const callerName = currentUser?.name || 'Debater Alpha';

    const res = await callService.callAgain(
      callerId,
      callerName,
      targetRecipientId,
      targetRecipientName,
      customTopic,
      previousCallId
    );

    if (res.success && res.call && res.invitation) {
      setOutgoingInvitation(res.invitation);
      setActiveCall(res.call);
      setActiveCallRole('creator');
      setCurrentTab('direct_calling');
    }

    return res;
  };

  const acceptIncomingCall = async (invitationId: string) => {
    if (!currentUser) return;
    const res = await callService.acceptInvitation(invitationId, currentUser.id, currentUser.name);
    if (res.success && res.call) {
      setIncomingInvitation(null);
      setActiveCall(res.call);
      setActiveCallRole('participant');
      setCurrentTab('join_call');
      await refreshUserCalls();
      return res;
    }
    return res;
  };

  const declineIncomingCall = async (invitationId: string) => {
    await callService.declineInvitation(invitationId);
    setIncomingInvitation(null);
  };

  const cancelOutgoingCall = async () => {
    if (outgoingInvitation) {
      await callService.cancelInvitation(outgoingInvitation.id);
    }
    setOutgoingInvitation(null);
    setActiveCall(null);
    setCurrentTab('home');
  };

  // Real-time synchronization for direct call invitations and acceptances
  useEffect(() => {
    if (typeof window === 'undefined') return;

    let channel: BroadcastChannel | null = null;
    try {
      if ('BroadcastChannel' in window) {
        channel = new BroadcastChannel('talkreward_calls_channel');
        channel.onmessage = (event) => {
          const data = event.data;
          if (!data) return;

          if (data.type === 'INCOMING_CALL_INVITATION') {
            if (data.invitation && data.invitation.recipientId === currentUser?.id) {
              setIncomingInvitation(data.invitation);
            }
          } else if (data.type === 'INVITATION_ACCEPTED') {
            if (outgoingInvitation && outgoingInvitation.id === data.invitationId) {
              setOutgoingInvitation((prev) => (prev ? { ...prev, status: 'accepted' } : null));
              if (data.call) {
                setActiveCall(data.call);
              }
            }
          } else if (data.type === 'INVITATION_DECLINED') {
            if (outgoingInvitation && outgoingInvitation.id === data.invitationId) {
              setOutgoingInvitation((prev) => (prev ? { ...prev, status: 'declined' } : null));
            }
          } else if (data.type === 'INVITATION_CANCELLED') {
            if (incomingInvitation && incomingInvitation.id === data.invitationId) {
              setIncomingInvitation(null);
            }
          }
        };
      }
    } catch {}

    // Polling fallback every 2 seconds
    const pollInterval = setInterval(async () => {
      if (!currentUser?.id) return;

      // 1. Check if an incoming invitation is waiting for current user
      if (currentTab !== 'voice_call' && currentTab !== 'direct_calling') {
        const invRes = await callService.getPendingInvitation(currentUser.id);
        if (invRes.success && invRes.invitation) {
          setIncomingInvitation(invRes.invitation);
        }
      }

      // 2. If user has an outgoing call invitation pending, check its status
      if (outgoingInvitation && outgoingInvitation.status === 'pending') {
        const stRes = await callService.getInvitationStatus(outgoingInvitation.id);
        if (stRes.success && stRes.invitation) {
          if (stRes.invitation.status === 'accepted') {
            setOutgoingInvitation((prev) => (prev ? { ...prev, status: 'accepted' } : null));
            if (stRes.call) {
              setActiveCall(stRes.call);
            }
          } else if (stRes.invitation.status === 'declined' || stRes.invitation.status === 'cancelled') {
            setOutgoingInvitation((prev) => (prev ? { ...prev, status: stRes.invitation.status } : null));
          }
        }
      }
    }, 2000);

    return () => {
      channel?.close();
      clearInterval(pollInterval);
    };
  }, [currentUser?.id, currentTab, outgoingInvitation, incomingInvitation]);

  // Server-authoritative ban status sync: immediate check, polling, and broadcast listener
  useEffect(() => {
    if (!currentUser?.id) return;

    let isSubscribed = true;
    let callsChannel: BroadcastChannel | null = null;
    let zappleChannel: BroadcastChannel | null = null;

    const checkServerUserStatus = async () => {
      try {
        const res = await safeFetchJson<AuthApiResponse>(`/api/auth/user/${currentUser.id}`);

        const data: AuthApiResponse = res.data || {};
        if (!isSubscribed) return;

        if (data.isBanned || data.status === 'BANNED' || data.user?.status === 'BANNED') {
          if (currentUser.status !== 'BANNED') {
            const updatedUser: User = {
              ...currentUser,
              ...(data.user || {}),
              status: 'BANNED',
              banReason: data.banReason || data.user?.banReason || 'Violation of debate community guidelines',
            };
            setCurrentUser(updatedUser);
            localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(updatedUser));
            setActiveCall(null);
            setIncomingInvitation(null);
            setOutgoingInvitation(null);
          }
        } else if (data.success && data.user && data.user.status === 'ACTIVE') {
          if (currentUser.status === 'BANNED') {
            const restoredUser: User = {
              ...currentUser,
              ...data.user,
              status: 'ACTIVE',
              banReason: undefined,
            };
            setCurrentUser(restoredUser);
            localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(restoredUser));
          }
        }
      } catch (err) {
        // Network or offline check
      }
    };

    // Run check immediately on mount or user change
    checkServerUserStatus();

    // Listen to broadcast events across browser tabs/windows
    try {
      if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
        callsChannel = new BroadcastChannel('talkreward_calls_channel');
        callsChannel.onmessage = (event) => {
          const data = event.data;
          if (!data) return;
          if ((data.type === 'USER_BANNED' || data.type === 'USER_UNBANNED') && data.userId === currentUser.id) {
            checkServerUserStatus();
          }
        };

        zappleChannel = new BroadcastChannel('zapple_channel');
        zappleChannel.onmessage = (event) => {
          const data = event.data;
          if (!data) return;
          if ((data.type === 'USER_BANNED' || data.type === 'USER_UNBANNED') && data.userId === currentUser.id) {
            checkServerUserStatus();
          }
        };
      }
    } catch {}

    // Polling sync every 2.5 seconds
    const statusInterval = setInterval(checkServerUserStatus, 2500);

    const handleFocus = () => {
      checkServerUserStatus();
    };
    window.addEventListener('focus', handleFocus);
    document.addEventListener('visibilitychange', handleFocus);

    return () => {
      isSubscribed = false;
      callsChannel?.close();
      zappleChannel?.close();
      clearInterval(statusInterval);
      window.removeEventListener('focus', handleFocus);
      document.removeEventListener('visibilitychange', handleFocus);
    };
  }, [currentUser?.id, currentUser?.status]);

  // Compatibility stubs
  const tasks: any[] = [];
  const submissions: any[] = [];
  const withdrawals: any[] = [];
  const claimDailyBonus = () => {};
  const submitTask = () => false;
  const requestDemoWithdrawal = () => ({ success: true, message: 'Processed' });
  const approveSubmission = () => {};
  const rejectSubmission = () => {};
  const approveWithdrawal = () => {};
  const rejectWithdrawal = () => {};
  const createTask = () => {};
  const updateTask = () => {};
  const deleteTask = () => {};
  const replySupportTicket = () => {};
  const broadcastAnnouncement = () => {};
  const resetDemoData = () => {
    localStorage.clear();
    window.location.reload();
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        users,
        wallet,
        transactions,
        notifications,
        tickets,
        currentTab,
        setCurrentTab,
        showWithdrawalModal,
        setShowWithdrawalModal,
        darkMode,
        setDarkMode,
        dailyPool,
        refreshDailyPool,
        updateDailyPoolConfig,
        resetDailyPoolNow,
        adminOverview,
        refreshAdminOverview,
        updatePayoutStatus,
        adminReviewCall,
        userCalls,
        refreshUserCalls,
        holdings,
        refreshWallet,
        userPayouts,
        refreshUserPayouts,
        matureHoldings,
        submitAppeal,
        paymentDetails,
        savePaymentDetails,
        requestPayout,
        isEmailAuthAvailable,
        checkEmailAuthStatus,
        loginWithEmailPassword,
        loginWithGoogle,
        loginWithOtp,
        logout,
        deleteAccount,
        reauthenticateGoogleAndDelete,
        accountDeletedNotice,
        setAccountDeletedNotice,
        markNotificationAsRead,
        markAllNotificationsAsRead,
        createSupportTicket,
        updateUserProfile,
        activeCall,
        setActiveCall,
        activeCallRole,
        setActiveCallRole,
        callDurationSeconds,
        setCallDurationSeconds,
        createDebateCall,
        joinDebateCall,
        creditDebateReward,
        callRewards,
        createPendingCallReward,
        verifyCallSession,
        outgoingInvitation,
        setOutgoingInvitation,
        incomingInvitation,
        setIncomingInvitation,
        initiateCallAgain,
        acceptIncomingCall,
        declineIncomingCall,
        cancelOutgoingCall,
        tasks,
        submissions,
        withdrawals,
        selectedTaskId,
        setSelectedTaskId,
        isDailyBonusClaimed,
        mobileFrameMode,
        setMobileFrameMode,
        claimDailyBonus,
        submitTask,
        requestDemoWithdrawal,
        approveSubmission,
        rejectSubmission,
        approveWithdrawal,
        rejectWithdrawal,
        createTask,
        updateTask,
        deleteTask,
        replySupportTicket,
        broadcastAnnouncement,
        resetDemoData,
        isOffline,
        checkConnection,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
