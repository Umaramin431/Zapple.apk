import React, { useState, useCallback } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { MobileShell } from './components/layout/MobileShell';
import { BottomNav } from './components/layout/BottomNav';
import { SplashScreen } from './components/screens/SplashScreen';
import { AuthScreen } from './components/screens/AuthScreen';
import { BannedScreen } from './components/screens/BannedScreen';
import { OfflineScreen } from './components/screens/OfflineScreen';
import { HomeScreen } from './components/screens/HomeScreen';
import { EarningsScreen } from './components/screens/EarningsScreen';
import { ProfileScreen } from './components/screens/ProfileScreen';
import { CallWaitingRoomScreen } from './components/calls/CallWaitingRoomScreen';
import { JoinCallScreen } from './components/calls/JoinCallScreen';
import { VoiceCallScreen } from './components/calls/VoiceCallScreen';
import { DirectCallingScreen } from './components/calls/DirectCallingScreen';
import { IncomingCallModal } from './components/calls/IncomingCallModal';
import { AdminPanelModal } from './components/admin/AdminPanelModal';

const MainAppContent: React.FC = () => {
  const { currentUser, currentTab, setCurrentTab, isOffline, checkConnection } = useApp();
  const [splashFinished, setSplashFinished] = useState(false);

  const handleSplashComplete = useCallback(() => {
    setSplashFinished(true);
  }, []);

  // 0. Offline Check: If offline, show OfflineScreen immediately
  if (isOffline) {
    return <OfflineScreen onRetry={checkConnection} />;
  }

  // 1. Splash Screen
  if (!splashFinished) {
    return <SplashScreen onComplete={handleSplashComplete} />;
  }

  // 2. Authentication Screen
  if (!currentUser) {
    return <AuthScreen />;
  }

  // 3. BANNED User Full-Screen Experience (No Home, Wallet, Earnings, Profile, or Calls)
  if (currentUser.status === 'BANNED') {
    return <BannedScreen user={currentUser} />;
  }

  // 4. Authenticated App Flow: Home, Earnings, Profile, or active Call views
  const renderContent = () => {
    switch (currentTab) {
      case 'home':
        return <HomeScreen />;
      case 'earnings':
      case 'wallet':
        return <EarningsScreen />;
      case 'profile':
        return <ProfileScreen />;
      case 'admin':
        return <AdminPanelModal isOpen={true} onClose={() => setCurrentTab('profile')} />;
      case 'call_waiting':
        return <CallWaitingRoomScreen />;
      case 'join_call':
        return <JoinCallScreen />;
      case 'direct_calling':
        return <DirectCallingScreen />;
      case 'voice_call':
        return <VoiceCallScreen />;
      default:
        return <HomeScreen />;
    }
  };

  const isFullScreenCall =
    currentTab === 'voice_call' || currentTab === 'call_waiting' || currentTab === 'direct_calling' || currentTab === 'join_call';

  return (
    <div className="flex-1 flex flex-col min-h-0 relative bg-black text-white selection:bg-emerald-500 selection:text-black">
      <main className="flex-1 overflow-y-auto">
        {renderContent()}
      </main>

      {/* Global incoming call invitation overlay */}
      <IncomingCallModal />

      {/* Exactly 3 tabs bottom navigation: Home, Earnings, Profile */}
      {!isFullScreenCall && <BottomNav />}
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MobileShell>
        <MainAppContent />
      </MobileShell>
    </AppProvider>
  );
}
