export type UserRole = 'user' | 'admin';
export type UserStatus = 'ACTIVE' | 'BANNED';

export interface User {
  id: string;
  name: string;
  mobile: string;
  createdAt: string;
  referralCode: string;
  role: UserRole;
  status?: UserStatus;
  banReason?: string;
  bannedAt?: string;
  bannedBy?: string;
  bannedByName?: string;
  unbannedAt?: string;
  unbannedBy?: string;
  unbannedByName?: string;
  avatar?: string;
  email?: string;
  deviceId?: string;
  clientIp?: string;
  totalCallsCount?: number;
  totalEarned?: number;
  currentWalletBalance?: number;
  lastActiveAt?: string;
}

export type TaskCategory = 'voice_feedback' | 'opinion' | 'daily_question' | 'survey' | 'audio_test';

export interface Task {
  id: string;
  title: string;
  description: string;
  rewardPoints: number;
  duration: string; // e.g., "2 mins", "5 mins"
  status: 'active' | 'inactive';
  category: TaskCategory;
  instructions: string;
  questionText: string;
  inputType: 'voice_record' | 'text_answer' | 'multiple_choice';
  options?: string[];
  minimumSeconds?: number;
}

export type SubmissionStatus = 'pending' | 'approved' | 'rejected';

export interface TaskSubmission {
  id: string;
  userId: string;
  userName: string;
  userMobile: string;
  taskId: string;
  taskTitle: string;
  submittedAt: string;
  status: SubmissionStatus;
  rewardPoints: number;
  submissionData: {
    answerText?: string;
    voiceDurationSeconds?: number;
    selectedOption?: string;
    audioRecorded?: boolean;
  };
  adminFeedback?: string;
  reviewedAt?: string;
}

export interface DailyPool {
  totalPoolAmount: number;
  allocatedAmount: number;
  remainingAmount: number;
  resetTimeUTC: string;
  nextResetAt: string;
  isExhausted: boolean;
  lastResetAt: string;
  todayApprovedRewardsCount: number;
}

export interface AdminAuditRecord {
  auditId: string;
  adminId: string;
  adminName: string;
  action:
    | 'CALL_APPROVED'
    | 'CALL_REJECTED'
    | 'WITHDRAWAL_APPROVED'
    | 'WITHDRAWAL_REJECTED'
    | 'PRIZE_POOL_INJECTION'
    | 'PRIZE_POOL_LIMIT_UPDATE'
    | 'DAILY_POOL_RESET'
    | 'DISBURSE_QUEUED'
    | 'USER_BANNED'
    | 'USER_UNBANNED'
    | 'SYSTEM_CONFIG';
  targetId: string;
  targetType: 'call' | 'payout' | 'prize_pool' | 'user' | 'appeal' | 'system';
  previousStatus?: string;
  newStatus?: string;
  rewardAmount?: number;
  timestamp: string; // Server ISO timestamp
  reason?: string;
  adminNotes?: string;
  metadata?: Record<string, any>;
}

export type PrizePoolTransactionType =
  | 'FUND_INJECTION'
  | 'REWARD_ALLOCATION'
  | 'DAILY_RESET'
  | 'LIMIT_UPDATE'
  | 'PAYOUT_DEDUCTION';

export interface PrizePoolLedgerTransaction {
  id: string;
  type: PrizePoolTransactionType;
  amount: number; // Positive for inflow/injections, negative for rewards/deductions, 0 for resets/limit changes
  previousBalance?: number;
  balanceAfter: number;
  dailyAllocatedAfter: number;
  adminId?: string;
  adminName?: string;
  userId?: string;
  userName?: string;
  participant1Id?: string;
  participant1Name?: string;
  participant2Id?: string;
  participant2Name?: string;
  callId?: string;
  joinCode?: string;
  topic?: string;
  timestamp: string; // Server ISO timestamp
  note: string;
}

export interface PrizePoolState {
  totalPoolBalance: number;       // Total funds added to treasury (e.g. ₹75,000)
  totalAllocatedAllTime: number;  // Total rewards distributed all-time (e.g. ₹1,800)
  remainingPoolBalance: number;   // Current Prize Pool balance = totalPoolBalance - totalAllocatedAllTime
  dailyLimit: number;             // Maximum amount that can be distributed per day (e.g. ₹30,000)
  dailyAllocated: number;         // Amount distributed/allocated today
  dailyRemaining: number;         // Remaining budget today = dailyLimit - dailyAllocated
  todayApprovedRewardsCount: number; // Number of ₹20 rewards approved today
  isDailyExhausted: boolean;      // Whether daily pool is fully exhausted
  nextResetAt: string;            // Server UTC timestamp of next reset
  lastResetAt: string;            // Server UTC timestamp of last reset
  lastUpdated: string;
  awaitingPoolFundsCallsCount?: number;
}

export interface Wallet {
  userId: string;
  currentBalance: number; // Real withdrawable balance from matured rewards
  pendingBalance: number; // Total rewards under 15-day holding period + pending verification
  paidOutTotal: number;   // Total amount disbursed via UPI/Bank
  totalEarned: number;    // All-time accumulated earnings
  demoBalance?: number;   // Backwards-compat alias for currentBalance
  pendingRewards?: number; // Backwards-compat alias for pendingBalance
}

export type RewardVerificationStatus = 'pending_verification' | 'pending_admin_review' | 'held' | 'verified' | 'rejected' | 'matured' | 'awaiting_pool_funds';

export interface VerificationChecklist {
  bothJoined: boolean;
  durationMet: boolean;
  voiceActive: boolean;
  sessionCompleted: boolean;
  qualityRulesMet: boolean;
}

export interface TranscriptMessage {
  id: string;
  speakerId: string;
  speakerName: string;
  text: string;
  timestamp: string;
  secondsIntoCall: number;
  confidence?: number;
}

export interface AICriterionAnalysis {
  passed: boolean;
  score: number; // 0-100
  notes: string;
}

export interface AIVerificationResult {
  decision: 'VERIFIED' | 'REJECTED';
  confidenceScore: number; // 0-100
  summary: string;
  reason: string;
  modelUsed: string;
  evaluatedAt: string;
  criteriaAnalysis: {
    mutualParticipation: AICriterionAnalysis;
    topicRelevance: AICriterionAnalysis;
    genuineEngagement: AICriterionAnalysis;
    antiGamingCheck: AICriterionAnalysis;
  };
  speakerStats?: {
    creatorTurnCount: number;
    creatorWordCount: number;
    joinerTurnCount: number;
    joinerWordCount: number;
    silencePercentage: number;
  };
}

export type AICallVerificationResult = AIVerificationResult;

export interface CallReward {
  id: string;
  callId: string;
  userId: string;
  userName: string;
  amount: number; // 20 (₹20)
  currency: 'INR';
  status: RewardVerificationStatus;
  createdAt: string;
  verifiedAt?: string;
  holdingPeriodEndsAt?: string; // 15-day holding period completion date
  isMatured?: boolean;
  rejectedAt?: string;
  rejectionReason?: string;
  appealStatus?: 'none' | 'pending' | 'approved' | 'rejected';
  appealReason?: string;
  appealSubmittedAt?: string;
  checks: VerificationChecklist;
  notes?: string;
  userConsentGiven?: boolean;
  transcript?: TranscriptMessage[];
  aiVerification?: AIVerificationResult;
}

export type TransactionType =
  | 'call_reward'
  | 'debate_reward'
  | 'payout'
  | 'referral_bonus'
  | 'signup_bonus';

export interface Transaction {
  id: string;
  userId: string;
  callId?: string;
  type: TransactionType;
  amount: number;
  description: string;
  createdAt: string;
  isCredit: boolean;
  status: 'completed' | 'pending' | 'cancelled' | 'failed';
}

export type PayoutStatus =
  | 'REQUESTED'
  | 'UNDER REVIEW'
  | 'APPROVED'
  | 'PROCESSING'
  | 'PAID'
  | 'FAILED'
  | 'REJECTED'
  | 'PENDING';

export interface Payout {
  id: string;
  userId: string;
  userName: string;
  amount: number;
  payoutMethod: 'UPI' | 'Bank Transfer';
  destinationDetails: string; // e.g. "alex@okhdfcbank"
  status: PayoutStatus;
  requestedAt: string;
  processedAt?: string;
  referenceNumber?: string;
  failureReason?: string;
  rewardId?: string;
}

export interface UserPaymentDetails {
  userId: string;
  payoutMethod: 'UPI' | 'Bank Transfer';
  upiId?: string;
  bankAccountNumber?: string;
  bankIfsc?: string;
  accountHolderName?: string;
  isVerified: boolean;
  updatedAt: string;
}

export interface FinancialFundingLedger {
  totalRevenueReceived: number;
  totalRewardBudget: number;
  totalUserRewardsAccrued: number;
  totalPayoutsDisbursed: number;
  remainingAvailableReserve: number;
  lastUpdated: string;
  fundingSources: {
    id: string;
    sourceName: string;
    amount: number;
    date: string;
    category: 'research_partnership' | 'ad_pool' | 'ai_data_licensing' | 'sponsor_grant';
  }[];
}

export type CallStatus = 'waiting' | 'joined' | 'active' | 'completed' | 'ended';

export interface Call {
  callId: string;
  creatorId: string;
  creatorName: string;
  participantId?: string;
  participantName?: string;
  topic: string;
  joinCode: string;
  status: CallStatus;
  createdAt: string;
  startedAt?: string;
  completedAt?: string;
  targetDurationSeconds: number; // 180 seconds (3 minutes)
  actualDurationSeconds?: number;
  endedReason?: 'completed' | 'left_early' | 'cancelled';
  transcript?: TranscriptMessage[];
  consentGiven?: boolean;
}

export type ParticipantConnectionStatus = 'connected' | 'reconnecting' | 'disconnected' | 'muted';

export interface CallParticipant {
  callId: string;
  userId: string;
  userName: string;
  joinedAt: string;
  leftAt?: string;
  connectionStatus: ParticipantConnectionStatus;
  isMuted?: boolean;
}

export interface SignalingMessage {
  type: 'offer' | 'answer' | 'candidate' | 'ready' | 'leave';
  callId: string;
  senderId: string;
  data?: any;
}

export type WithdrawalStatus = 'pending' | 'approved' | 'rejected';

export interface Withdrawal {
  id: string;
  userId: string;
  userName: string;
  amount: number;
  paymentMethod: 'UPI' | 'Bank Transfer' | 'Demo Gift Card';
  accountDetails: string;
  status: WithdrawalStatus;
  createdAt: string;
  demoNotice: string;
  adminNote?: string;
}

export type NotificationType =
  | 'task_approved'
  | 'new_task'
  | 'demo_reward'
  | 'system_announcement'
  | 'withdrawal_update';

export interface AppNotification {
  id: string;
  userId: string; // 'all' or specific userId
  title: string;
  message: string;
  type: NotificationType;
  createdAt: string;
  read: boolean;
  relatedId?: string;
}

export type TicketStatus = 'open' | 'in_progress' | 'resolved';

export interface SupportTicket {
  id: string;
  userId: string;
  userName: string;
  subject: string;
  message: string;
  status: TicketStatus;
  createdAt: string;
  adminReply?: string;
  repliedAt?: string;
}

export type InvitationStatus = 'pending' | 'accepted' | 'declined' | 'cancelled' | 'connected';

export interface CallInvitation {
  id: string;
  callId: string;
  callerId: string;
  callerName: string;
  callerAvatar?: string;
  recipientId: string;
  recipientName: string;
  recipientAvatar?: string;
  topic: string;
  status: InvitationStatus;
  createdAt: string;
  joinCode?: string;
}

export type ActiveTab =
  | 'home'
  | 'earnings'
  | 'wallet'
  | 'profile'
  | 'admin'
  | 'call_waiting'
  | 'join_call'
  | 'direct_calling'
  | 'voice_call'
  | 'call_completed';
