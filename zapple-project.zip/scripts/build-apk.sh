#!/usr/bin/env bash
set -e

echo "=== Zapple APK Build Script ==="

# 1. Ensure Java 17 is available
export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64
export PATH=$JAVA_HOME/bin:$PATH

if ! command -v java &> /dev/null; then
    echo "Java not found. Please ensure openjdk-17-jdk is installed."
    exit 1
fi

echo "Java version:"
java -version

# 2. Setup Android SDK
export ANDROID_HOME="/root/android-sdk"
mkdir -p "$ANDROID_HOME/cmdline-tools"

if [ ! -d "$ANDROID_HOME/cmdline-tools/latest" ]; then
    echo "Downloading Android Command Line Tools..."
    curl -o cmdline-tools.zip https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
    unzip -q cmdline-tools.zip
    mkdir -p "$ANDROID_HOME/cmdline-tools/latest"
    mv cmdline-tools/* "$ANDROID_HOME/cmdline-tools/latest/" 2>/dev/null || mv cmdline-tools/bin cmdline-tools/lib "$ANDROID_HOME/cmdline-tools/latest/" 2>/dev/null || true
    rm -rf cmdline-tools.zip cmdline-tools
fi

export PATH=$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$PATH

echo "Accepting Android SDK licenses and installing build-tools / platforms..."
yes | sdkmanager --licenses || true
sdkmanager "platform-tools" "platforms;android-34" "build-tools;34.0.0"

# 3. Build web assets
echo "Building Vite web assets..."
npx vite build

# 4. Sync Capacitor
echo "Syncing Capacitor..."
npx cap sync android

# 5. Build APK with Gradle
echo "Building Android Debug APK..."
cd android
chmod +x gradlew
./gradlew assembleDebug

# 6. Copy APK to public
APK_PATH="app/build/outputs/apk/debug/app-debug.apk"
if [ -f "$APK_PATH" ]; then
    mkdir -p ../public
    cp "$APK_PATH" ../public/zapple.apk
    echo "SUCCESS: APK generated at public/zapple.apk"
else
    echo "ERROR: APK file not found at expected path."
    exit 1
fi
