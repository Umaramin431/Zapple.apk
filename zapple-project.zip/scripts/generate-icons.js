import fs from 'fs';
import zlib from 'zlib';

function createCRC32Table() {
  const table = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let k = 0; k < 8; k++) {
      c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
    }
    table[i] = c;
  }
  return table;
}

const crcTable = createCRC32Table();

function crc32(buf) {
  let crc = -1;
  for (let i = 0; i < buf.length; i++) {
    crc = (crc >>> 8) ^ crcTable[(crc ^ buf[i]) & 0xff];
  }
  return (crc ^ (-1)) >>> 0;
}

function makeChunk(type, data) {
  const len = data.length;
  const chunk = Buffer.alloc(12 + len);
  chunk.writeUInt32BE(len, 0);
  chunk.write(type, 4, 4, 'ascii');
  data.copy(chunk, 8);
  const typeAndData = chunk.subarray(4, 8 + len);
  chunk.writeUInt32BE(crc32(typeAndData), 8 + len);
  return chunk;
}

function generatePngBuffer(width, height, isMaskable = false) {
  const signature = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);

  // IHDR
  const ihdrData = Buffer.alloc(13);
  ihdrData.writeUInt32BE(width, 0);
  ihdrData.writeUInt32BE(height, 4);
  ihdrData.writeUInt8(8, 8); // bit depth 8
  ihdrData.writeUInt8(6, 9); // RGBA
  ihdrData.writeUInt8(0, 10);
  ihdrData.writeUInt8(0, 11);
  ihdrData.writeUInt8(0, 12);
  const ihdrChunk = makeChunk('IHDR', ihdrData);

  // Raw image data: filter byte (0) + width * 4 bytes per row
  const rowSize = 1 + width * 4;
  const rawData = Buffer.alloc(rowSize * height);

  const cx = width / 2;
  const cy = height / 2;
  const boxSize = isMaskable ? width * 0.52 : width * 0.62;
  const halfBox = boxSize / 2;
  const radius = boxSize * 0.22;

  for (let y = 0; y < height; y++) {
    const rowOffset = y * rowSize;
    rawData[rowOffset] = 0; // Filter: None

    for (let x = 0; x < width; x++) {
      const pxOffset = rowOffset + 1 + x * 4;

      // Check if inside white rounded box
      const dx = Math.abs(x - cx);
      const dy = Math.abs(y - cy);

      let inBox = false;
      if (dx <= halfBox && dy <= halfBox) {
        if (dx <= halfBox - radius || dy <= halfBox - radius) {
          inBox = true;
        } else {
          const cornerDist = Math.hypot(dx - (halfBox - radius), dy - (halfBox - radius));
          if (cornerDist <= radius) inBox = true;
        }
      }

      // Check if inside 'Z' shape
      let isZ = false;
      if (inBox) {
        const zScale = boxSize / 100;
        const localX = (x - (cx - halfBox)) / zScale;
        const localY = (y - (cy - halfBox)) / zScale;
        const th = 11; // thickness

        // Top bar
        if (localY >= 25 && localY <= 25 + th && localX >= 25 && localX <= 75) isZ = true;
        // Bottom bar
        if (localY >= 75 - th && localY <= 75 && localX >= 25 && localX <= 75) isZ = true;
        // Diagonal: from (75, 25) to (25, 75)
        // distance from line x + y = 100
        const diagDist = Math.abs(localX + localY - 100) / Math.SQRT2;
        if (diagDist <= th / 1.6 && localX >= 25 && localX <= 75 && localY >= 25 && localY <= 75) {
          isZ = true;
        }
      }

      if (isZ) {
        // Black Z
        rawData[pxOffset] = 0;
        rawData[pxOffset + 1] = 0;
        rawData[pxOffset + 2] = 0;
        rawData[pxOffset + 3] = 255;
      } else if (inBox) {
        // White rounded emblem
        rawData[pxOffset] = 255;
        rawData[pxOffset + 1] = 255;
        rawData[pxOffset + 2] = 255;
        rawData[pxOffset + 3] = 255;
      } else {
        // Black background
        rawData[pxOffset] = 0;
        rawData[pxOffset + 1] = 0;
        rawData[pxOffset + 2] = 0;
        rawData[pxOffset + 3] = 255;
      }
    }
  }

  const compressedData = zlib.deflateSync(rawData);
  const idatChunk = makeChunk('IDAT', compressedData);
  const iendChunk = makeChunk('IEND', Buffer.alloc(0));

  return Buffer.concat([signature, ihdrChunk, idatChunk, iendChunk]);
}

const icons = [
  { file: 'public/pwa-192x192.png', size: 192, maskable: false },
  { file: 'public/pwa-512x512.png', size: 512, maskable: false },
  { file: 'public/pwa-maskable-512x512.png', size: 512, maskable: true },
  { file: 'public/apple-touch-icon.png', size: 180, maskable: false },
  { file: 'public/favicon.png', size: 64, maskable: false },
  { file: 'public/favicon.ico', size: 32, maskable: false },
];

for (const icon of icons) {
  const buf = generatePngBuffer(icon.size, icon.size, icon.maskable);
  fs.writeFileSync(icon.file, buf);
  console.log(`Generated ${icon.file} (${icon.size}x${icon.size})`);
}
