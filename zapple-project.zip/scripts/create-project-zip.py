#!/usr/bin/env python3
import os
import sys
import shutil
import zipfile

def create_project_zip():
    base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    public_dir = os.path.join(base_dir, 'public')
    os.makedirs(public_dir, exist_ok=True)
    
    zip_dest = os.path.join(public_dir, 'zapple-project.zip')
    temp_zip = os.path.join('/tmp', 'zapple-project.zip')
    
    if os.path.exists(temp_zip):
        os.remove(temp_zip)
        
    exclude_dirs = {
        'node_modules',
        '.git',
        '.gradle',
        'dist',
        'android_build_temp',
        'build',
        '.idea',
        '.vscode'
    }
    
    exclude_files = {
        '.DS_Store',
        'Thumbs.db'
    }
    
    file_count = 0
    total_uncompressed = 0
    
    print(f"Creating project ZIP from: {base_dir}")
    with zipfile.ZipFile(temp_zip, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zipf:
        for root, dirs, files in os.walk(base_dir):
            # Prune excluded directories
            dirs[:] = [d for d in dirs if d not in exclude_dirs and not d.startswith('.gradle')]
            
            for file in files:
                # Do not include any zip archives
                if file.endswith('.zip') or file in exclude_files or file.endswith('~'):
                    continue
                
                full_path = os.path.join(root, file)
                rel_path = os.path.relpath(full_path, base_dir)
                
                # Double-check relative path components
                parts = rel_path.split(os.sep)
                if any(p in exclude_dirs for p in parts):
                    continue
                
                file_size = os.path.getsize(full_path)
                total_uncompressed += file_size
                zipf.write(full_path, rel_path)
                file_count += 1

    zip_size_bytes = os.path.getsize(temp_zip)
    zip_size_mb = zip_size_bytes / (1024 * 1024)
    
    # Move to public destination
    shutil.move(temp_zip, zip_dest)
    
    # Also copy to dist if dist exists
    dist_dir = os.path.join(base_dir, 'dist')
    if os.path.exists(dist_dir):
        shutil.copy2(zip_dest, os.path.join(dist_dir, 'zapple-project.zip'))
        
    print(f"SUCCESS: Created {zip_dest}")
    print(f"Total files: {file_count}")
    print(f"Uncompressed size: {total_uncompressed / (1024*1024):.2f} MB")
    print(f"Final ZIP size: {zip_size_mb:.2f} MB ({zip_size_bytes} bytes)")
    
    if zip_size_mb >= 25.0:
        print(f"WARNING: ZIP size {zip_size_mb:.2f} MB exceeds 25 MB limit!", file=sys.stderr)
        sys.exit(1)
    else:
        print(f"Optimal: ZIP size is well below 25 MB GitHub web limit.")

if __name__ == '__main__':
    create_project_zip()
