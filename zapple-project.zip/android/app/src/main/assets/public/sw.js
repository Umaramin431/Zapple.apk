/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-7e5eb42b'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "registerSW.js",
    "revision": "1872c500de691dce40960bb85481de07"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "01f9aeeb8ba96122a0475157de1a9ece"
  }, {
    "url": "pwa-512x512.png",
    "revision": "dbb3e6f6912051ca1307fd1e8a908ac4"
  }, {
    "url": "pwa-192x192.png",
    "revision": "ed724a7611d0dc683b3b774b7540f757"
  }, {
    "url": "index.html",
    "revision": "fd056c8c214c1165d3581ca434de3103"
  }, {
    "url": "icon.svg",
    "revision": "d1cb818f41400fe71122e5c47752b0ae"
  }, {
    "url": "icon-maskable.svg",
    "revision": "be2e37e34c97d3020b90127ee1da4365"
  }, {
    "url": "favicon.png",
    "revision": "3a91c4d2986093ac2e4ab74edc587988"
  }, {
    "url": "favicon.ico",
    "revision": "a1c1f45ce2f44af0ebbcee1f7003dc4c"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "5fef3e2c6f4120577f46d74f455dbf0e"
  }, {
    "url": "assets/index-CIPL6cEc.js",
    "revision": null
  }, {
    "url": "assets/index-BsOMN_tW.css",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "5fef3e2c6f4120577f46d74f455dbf0e"
  }, {
    "url": "favicon.ico",
    "revision": "a1c1f45ce2f44af0ebbcee1f7003dc4c"
  }, {
    "url": "favicon.png",
    "revision": "3a91c4d2986093ac2e4ab74edc587988"
  }, {
    "url": "icon.svg",
    "revision": "d1cb818f41400fe71122e5c47752b0ae"
  }, {
    "url": "pwa-192x192.png",
    "revision": "ed724a7611d0dc683b3b774b7540f757"
  }, {
    "url": "pwa-512x512.png",
    "revision": "dbb3e6f6912051ca1307fd1e8a908ac4"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "01f9aeeb8ba96122a0475157de1a9ece"
  }, {
    "url": "manifest.webmanifest",
    "revision": "1b77e95876a6116f156b28e22eb72ac2"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));

}));
