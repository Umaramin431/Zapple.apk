var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// server.ts
var server_exports = {};
module.exports = __toCommonJS(server_exports);
var import_express = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_vite = require("vite");
async function startServer() {
  const app = (0, import_express.default)();
  const PORT = 3e3;
  app.use(import_express.default.json());
  const users = /* @__PURE__ */ new Map();
  const calls = /* @__PURE__ */ new Map();
  const callsByCode = /* @__PURE__ */ new Map();
  const participants = /* @__PURE__ */ new Map();
  const signals = /* @__PURE__ */ new Map();
  const callRewards = /* @__PURE__ */ new Map();
  const rewardByCallAndUser = /* @__PURE__ */ new Map();
  const verificationAudits = [];
  const transactions = [];
  const payouts = [];
  const userPaymentDetails = /* @__PURE__ */ new Map();
  const notifications = [];
  const supportTickets = [];
  const callTranscripts = /* @__PURE__ */ new Map();
  const userConsents = /* @__PURE__ */ new Map();
  const directInvitations = /* @__PURE__ */ new Map();
  const prizePoolTransactions = [];
  function getNextMidnightUTC() {
    const d = /* @__PURE__ */ new Date();
    d.setUTCHours(24, 0, 0, 0);
    return d;
  }
  const initialNextReset = getNextMidnightUTC().toISOString();
  const initialLastReset = (/* @__PURE__ */ new Date()).toISOString();
  const prizePool = {
    totalPoolBalance: 75e3,
    totalAllocatedAllTime: 180,
    remainingPoolBalance: 74820,
    dailyLimit: 3e4,
    dailyAllocated: 180,
    dailyRemaining: 29820,
    todayApprovedRewardsCount: 9,
    isDailyExhausted: false,
    nextResetAt: initialNextReset,
    lastResetAt: initialLastReset,
    lastUpdated: (/* @__PURE__ */ new Date()).toISOString()
  };
  const dailyPool = {
    totalPoolAmount: prizePool.dailyLimit,
    allocatedAmount: prizePool.dailyAllocated,
    remainingAmount: prizePool.dailyRemaining,
    resetTimeUTC: "00:00:00 UTC",
    nextResetAt: prizePool.nextResetAt,
    isExhausted: prizePool.isDailyExhausted,
    lastResetAt: prizePool.lastResetAt,
    todayApprovedRewardsCount: prizePool.todayApprovedRewardsCount
  };
  prizePoolTransactions.push(
    {
      id: "tx_seed_01",
      type: "FUND_INJECTION",
      amount: 35e3,
      balanceAfter: 35e3,
      dailyAllocatedAfter: 0,
      adminId: "usr_admin_ff280270",
      adminName: "Administrator",
      timestamp: "2026-08-01T10:00:00.000Z",
      note: "Initial Treasury Allocation: Voice AI Research Consortium Grant"
    },
    {
      id: "tx_seed_02",
      type: "FUND_INJECTION",
      amount: 25e3,
      balanceAfter: 6e4,
      dailyAllocatedAfter: 0,
      adminId: "usr_admin_ff280270",
      adminName: "Administrator",
      timestamp: "2026-08-15T14:30:00.000Z",
      note: "Treasury Top-up: Linguistic Diversity Sponsorship Pool"
    },
    {
      id: "tx_seed_03",
      type: "FUND_INJECTION",
      amount: 15e3,
      balanceAfter: 75e3,
      dailyAllocatedAfter: 0,
      adminId: "usr_admin_ff280270",
      adminName: "Administrator",
      timestamp: "2026-09-01T09:15:00.000Z",
      note: "Capital Injection: In-App Audio Advertising Revenue Reserve"
    },
    {
      id: "tx_seed_04",
      type: "LIMIT_UPDATE",
      amount: 0,
      balanceAfter: 75e3,
      dailyAllocatedAfter: 0,
      adminId: "usr_admin_ff280270",
      adminName: "Administrator",
      timestamp: "2026-09-01T09:30:00.000Z",
      note: "Configured Daily Pool Limit to \u20B930,000 / day"
    }
  );
  const adminAuditLogs = [
    {
      auditId: "adm_audit_seed_01",
      adminId: "usr_admin_ff280270",
      adminName: "Administrator",
      action: "PRIZE_POOL_INJECTION",
      targetId: "prize_pool",
      targetType: "prize_pool",
      previousStatus: "0",
      newStatus: "75000",
      timestamp: "2026-09-01T09:15:00.000Z",
      reason: "Initial Treasury Allocation: Voice AI Research Consortium Grant (\u20B975,000)"
    },
    {
      auditId: "adm_audit_seed_02",
      adminId: "usr_admin_ff280270",
      adminName: "Administrator",
      action: "PRIZE_POOL_LIMIT_UPDATE",
      targetId: "daily_limit",
      targetType: "prize_pool",
      previousStatus: "10000",
      newStatus: "30000",
      timestamp: "2026-09-01T09:30:00.000Z",
      reason: "Configured Daily Pool Limit to \u20B930,000 / day"
    }
  ];
  function recordAdminAudit(entry) {
    const audit = {
      auditId: entry.auditId || `adm_audit_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      adminId: entry.adminId,
      adminName: entry.adminName || users.get(entry.adminId)?.name || "Audit Supervisor",
      action: entry.action,
      targetId: entry.targetId,
      targetType: entry.targetType,
      previousStatus: entry.previousStatus,
      newStatus: entry.newStatus,
      rewardAmount: entry.rewardAmount !== void 0 ? entry.rewardAmount : entry.metadata?.rewardAmount ?? 0,
      timestamp: entry.timestamp || (/* @__PURE__ */ new Date()).toISOString(),
      reason: entry.reason,
      adminNotes: entry.adminNotes || entry.reason,
      metadata: entry.metadata
    };
    adminAuditLogs.unshift(audit);
    return audit;
  }
  function checkAndRefreshDailyPool() {
    const now = Date.now();
    const resetTimestamp = new Date(prizePool.nextResetAt).getTime();
    if (now >= resetTimestamp) {
      prizePool.dailyAllocated = 0;
      prizePool.dailyRemaining = prizePool.dailyLimit;
      prizePool.todayApprovedRewardsCount = 0;
      prizePool.isDailyExhausted = false;
      prizePool.lastResetAt = (/* @__PURE__ */ new Date()).toISOString();
      prizePool.nextResetAt = getNextMidnightUTC().toISOString();
      prizePool.lastUpdated = (/* @__PURE__ */ new Date()).toISOString();
      dailyPool.allocatedAmount = 0;
      dailyPool.totalPoolAmount = prizePool.dailyLimit;
      dailyPool.remainingAmount = prizePool.dailyLimit;
      dailyPool.todayApprovedRewardsCount = 0;
      dailyPool.isExhausted = false;
      dailyPool.lastResetAt = prizePool.lastResetAt;
      dailyPool.nextResetAt = prizePool.nextResetAt;
      prizePoolTransactions.unshift({
        id: `tx_reset_${Date.now()}`,
        type: "DAILY_RESET",
        amount: 0,
        balanceAfter: prizePool.remainingPoolBalance,
        dailyAllocatedAfter: 0,
        adminId: "system_cron",
        adminName: "System UTC Midnight Scheduler",
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        note: `Automatic Daily Pool Reset at UTC Midnight. Daily limit refreshed to \u20B9${prizePool.dailyLimit.toLocaleString("en-IN")}.`
      });
    } else {
      prizePool.dailyRemaining = Math.max(0, prizePool.dailyLimit - prizePool.dailyAllocated);
      prizePool.remainingPoolBalance = Math.max(0, prizePool.totalPoolBalance - prizePool.totalAllocatedAllTime);
      prizePool.isDailyExhausted = prizePool.dailyRemaining <= 0 || prizePool.remainingPoolBalance < 40;
      dailyPool.totalPoolAmount = prizePool.dailyLimit;
      dailyPool.allocatedAmount = prizePool.dailyAllocated;
      dailyPool.remainingAmount = prizePool.dailyRemaining;
      dailyPool.isExhausted = prizePool.isDailyExhausted;
      dailyPool.todayApprovedRewardsCount = prizePool.todayApprovedRewardsCount;
    }
  }
  function countAwaitingPoolFundsCalls() {
    const awaitingCallIds = /* @__PURE__ */ new Set();
    for (const r of callRewards.values()) {
      if (r.status === "awaiting_pool_funds") {
        awaitingCallIds.add(r.callId);
      }
    }
    return awaitingCallIds.size;
  }
  function processAwaitingCalls() {
    let processedCount = 0;
    const awaitingCallIds = /* @__PURE__ */ new Set();
    for (const r of callRewards.values()) {
      if (r.status === "awaiting_pool_funds") {
        awaitingCallIds.add(r.callId);
      }
    }
    for (const callId of awaitingCallIds) {
      if (prizePool.remainingPoolBalance < 40) break;
      const call = calls.get(callId);
      if (!call || call.rewardGranted) continue;
      const p1Id = call.creatorId || "usr_creator";
      const p1Name = call.creatorName || users.get(p1Id)?.name || "Caller 1";
      const p2Id = call.participantId || participants.get(callId)?.find((p) => p.userId !== p1Id)?.userId || "usr_joiner";
      const p2Name = call.participantName || participants.get(callId)?.find((p) => p.userId !== p1Id)?.userName || users.get(p2Id)?.name || "Caller 2";
      const p1RewardKey = `${callId}_${p1Id}`;
      const p2RewardKey = `${callId}_${p2Id}`;
      const p1Reward = rewardByCallAndUser.get(p1RewardKey);
      const p2Reward = rewardByCallAndUser.get(p2RewardKey);
      const prevBalance = prizePool.remainingPoolBalance;
      prizePool.dailyAllocated += 40;
      prizePool.totalAllocatedAllTime += 40;
      prizePool.todayApprovedRewardsCount += 2;
      prizePool.remainingPoolBalance = Math.max(0, prizePool.totalPoolBalance - prizePool.totalAllocatedAllTime);
      prizePool.dailyRemaining = Math.max(0, prizePool.dailyLimit - prizePool.dailyAllocated);
      prizePool.isDailyExhausted = prizePool.dailyRemaining <= 0 || prizePool.remainingPoolBalance < 40;
      prizePool.lastUpdated = (/* @__PURE__ */ new Date()).toISOString();
      dailyPool.allocatedAmount = prizePool.dailyAllocated;
      dailyPool.totalPoolAmount = prizePool.dailyLimit;
      dailyPool.remainingAmount = prizePool.dailyRemaining;
      dailyPool.todayApprovedRewardsCount = prizePool.todayApprovedRewardsCount;
      dailyPool.isExhausted = prizePool.isDailyExhausted;
      call.rewardGranted = true;
      const holdingPeriodEndsAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1e3).toISOString();
      if (p1Reward) {
        p1Reward.status = "verified";
        p1Reward.verifiedAt = (/* @__PURE__ */ new Date()).toISOString();
        p1Reward.holdingPeriodEndsAt = holdingPeriodEndsAt;
        p1Reward.isMatured = false;
        p1Reward.notes = "Reward Released \u2014 Entered 7-Day Holding Period";
        transactions.unshift({
          id: `tx_call_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
          userId: p1Id,
          callId: call.callId,
          type: "call_reward",
          amount: 20,
          description: "Call Reward (Queued Reward Released \u2014 7-Day Holding Period)",
          createdAt: (/* @__PURE__ */ new Date()).toISOString(),
          isCredit: true,
          status: "completed"
        });
        sendNotification(
          p1Id,
          "\u20B920 \u2014 Queued Reward Released!",
          "Prize Pool funds have been replenished! Your verified \u20B920 reward is now in the 7-day holding period.",
          "verification_approved",
          p1Reward.id
        );
      }
      if (p2Reward) {
        p2Reward.status = "verified";
        p2Reward.verifiedAt = (/* @__PURE__ */ new Date()).toISOString();
        p2Reward.holdingPeriodEndsAt = holdingPeriodEndsAt;
        p2Reward.isMatured = false;
        p2Reward.notes = "Reward Released \u2014 Entered 7-Day Holding Period";
        transactions.unshift({
          id: `tx_call_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
          userId: p2Id,
          callId: call.callId,
          type: "call_reward",
          amount: 20,
          description: "Call Reward (Queued Reward Released \u2014 7-Day Holding Period)",
          createdAt: (/* @__PURE__ */ new Date()).toISOString(),
          isCredit: true,
          status: "completed"
        });
        sendNotification(
          p2Id,
          "\u20B920 \u2014 Queued Reward Released!",
          "Prize Pool funds have been replenished! Your verified \u20B920 reward is now in the 7-day holding period.",
          "verification_approved",
          p2Reward.id
        );
      }
      prizePoolTransactions.unshift({
        id: `pp_tx_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        type: "REWARD_ALLOCATION",
        amount: -40,
        previousBalance: prevBalance,
        balanceAfter: prizePool.remainingPoolBalance,
        dailyAllocatedAfter: prizePool.dailyAllocated,
        userId: p1Id,
        userName: p1Name,
        participant1Id: p1Id,
        participant1Name: p1Name,
        participant2Id: p2Id,
        participant2Name: p2Name,
        callId: call.callId,
        joinCode: call.joinCode,
        topic: call.topic,
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        note: `Queued 2-Person Call #${call.joinCode || call.callId} disbursed \u2014 \u20B940 total (\u20B920 to ${p1Name}, \u20B920 to ${p2Name})`
      });
      processedCount++;
    }
    refreshFinancialLedger();
    return processedCount;
  }
  function verifyAdminRequest(req, res) {
    const headerId = req.headers["x-admin-id"]?.trim();
    const headerEmail = req.headers["x-admin-email"]?.trim()?.toLowerCase();
    const authHeader = req.headers["authorization"]?.replace("Bearer ", "")?.trim();
    const bodyId = req.body?.adminId?.toString()?.trim();
    const bodyEmail = req.body?.adminEmail?.toString()?.trim()?.toLowerCase();
    const queryId = req.query?.adminId?.trim();
    const queryEmail = req.query?.adminEmail?.trim()?.toLowerCase();
    const authKey = headerId || authHeader || bodyId || queryId || headerEmail || bodyEmail || "";
    const candidateEmail = headerEmail || bodyEmail || queryEmail || (authKey.includes("@") ? authKey.toLowerCase() : "") || (authHeader?.includes("@") ? authHeader.toLowerCase() : "");
    if (!authKey && !candidateEmail) {
      res.status(401).json({
        success: false,
        error: "Authentication Required: Please sign in with an authorized administrative account.",
        code: "AUTH_REQUIRED"
      });
      return null;
    }
    let user = (authKey ? users.get(authKey) : void 0) || Array.from(users.values()).find(
      (u) => authKey && (u.id === authKey || u.email && u.email.toLowerCase() === authKey.toLowerCase()) || candidateEmail && u.email && u.email.toLowerCase() === candidateEmail
    );
    const isAdminEmail = candidateEmail === "ff280270@gmail.com" || user?.email && user.email.toLowerCase() === "ff280270@gmail.com";
    const isAdminId = authKey === "usr_admin_ff280270" || authKey === "usr_admin_01" || authKey.toLowerCase() === "ff280270@gmail.com";
    if (!user && (isAdminEmail || isAdminId)) {
      user = {
        ...adminUser,
        id: authKey && !authKey.includes("@") ? authKey : adminUser.id,
        email: "ff280270@gmail.com",
        role: "admin"
      };
      if (user.id) {
        users.set(user.id, user);
      }
    }
    if (user && (user.role === "admin" || isAdminEmail || isAdminId)) {
      user.role = "admin";
      return user;
    }
    res.status(403).json({
      success: false,
      error: "Access Denied: Administrative privileges are strictly restricted to authorized administrator (ff280270@gmail.com).",
      code: "ADMIN_UNAUTHORIZED"
    });
    return null;
  }
  const financialFundingLedger = {
    totalRevenueReceived: 75e3,
    totalRewardBudget: 6e4,
    totalUserRewardsAccrued: 0,
    totalPayoutsDisbursed: 0,
    remainingAvailableReserve: 6e4,
    lastUpdated: (/* @__PURE__ */ new Date()).toISOString(),
    fundingSources: [
      {
        id: "fund_01",
        sourceName: "Voice AI Research Consortium Grant",
        amount: 35e3,
        date: "2026-08-01T00:00:00Z",
        category: "research_partnership"
      },
      {
        id: "fund_02",
        sourceName: "Linguistic Diversity Sponsorship Pool",
        amount: 25e3,
        date: "2026-08-15T00:00:00Z",
        category: "sponsor_grant"
      },
      {
        id: "fund_03",
        sourceName: "In-App Audio Advertising Revenue Reserve",
        amount: 15e3,
        date: "2026-09-01T00:00:00Z",
        category: "ad_pool"
      }
    ]
  };
  const adminUser = {
    id: "usr_admin_ff280270",
    name: "Administrator",
    mobile: "+91 98765 43210",
    email: "ff280270@gmail.com",
    role: "admin",
    status: "ACTIVE",
    referralCode: "ZAP-ADMIN",
    createdAt: "2026-08-01T00:00:00.000Z",
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&auto=format&fit=crop&q=80",
    deviceId: "dev_adm_881a",
    clientIp: "103.21.148.12",
    lastActiveAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  users.set(adminUser.id, adminUser);
  const sampleUsers = [
    {
      id: "usr_real_01",
      name: "Debater Alpha (Priya Sharma)",
      mobile: "+91 98765 12340",
      email: "priya.sharma@example.com",
      role: "user",
      status: "ACTIVE",
      referralCode: "ZAP-PRIY44",
      createdAt: "2026-08-10T11:20:00.000Z",
      deviceId: "dev_and_9a82",
      clientIp: "49.36.128.45",
      lastActiveAt: "2026-09-18T14:30:00.000Z"
    },
    {
      id: "usr_real_02",
      name: "Debater Beta (Rahul Verma)",
      mobile: "+91 98112 34567",
      email: "rahul.verma@example.com",
      role: "user",
      status: "ACTIVE",
      referralCode: "ZAP-RAHU88",
      createdAt: "2026-08-15T09:45:00.000Z",
      deviceId: "dev_ios_4c11",
      clientIp: "157.34.89.210",
      lastActiveAt: "2026-09-18T16:15:00.000Z"
    },
    {
      id: "usr_real_03",
      name: "Amit Patel",
      mobile: "+91 97234 56789",
      email: "amit.patel@example.com",
      role: "user",
      status: "BANNED",
      banReason: "Repeated zero-audio microphone spoofing",
      bannedAt: "2026-09-10T12:00:00.000Z",
      bannedBy: "usr_admin_ff280270",
      bannedByName: "Administrator",
      referralCode: "ZAP-AMIT19",
      createdAt: "2026-08-20T14:10:00.000Z",
      deviceId: "dev_and_88ff",
      clientIp: "182.72.44.19",
      lastActiveAt: "2026-09-10T11:58:00.000Z"
    },
    {
      id: "usr_real_04",
      name: "Sneha Roy",
      mobile: "+91 96543 21098",
      email: "sneha.roy@example.com",
      role: "user",
      status: "ACTIVE",
      referralCode: "ZAP-SNEH72",
      createdAt: "2026-08-28T16:30:00.000Z",
      deviceId: "dev_ios_99e1",
      clientIp: "122.161.48.90",
      lastActiveAt: "2026-09-17T18:00:00.000Z"
    }
  ];
  sampleUsers.forEach((u) => users.set(u.id, u));
  function processMaturedRewardsAndAutoWithdrawals(targetUserId) {
    const now = Date.now();
    callRewards.forEach((reward) => {
      if (targetUserId && reward.userId !== targetUserId) return;
      if (reward.status === "verified" || reward.status === "held" || reward.status === "matured") {
        const holdingStart = reward.verifiedAt ? new Date(reward.verifiedAt).getTime() : new Date(reward.createdAt).getTime();
        const holdingEnds = reward.holdingPeriodEndsAt ? new Date(reward.holdingPeriodEndsAt).getTime() : holdingStart + 7 * 24 * 60 * 60 * 1e3;
        if (!reward.holdingPeriodEndsAt) {
          reward.holdingPeriodEndsAt = new Date(holdingEnds).toISOString();
        }
        if (now >= holdingEnds || reward.isMatured) {
          reward.status = "matured";
          reward.isMatured = true;
          if (!reward.withdrawalRequestId) {
            const existingPayout = payouts.find((p) => p.rewardId === reward.id);
            if (existingPayout) {
              reward.withdrawalRequestId = existingPayout.id;
            } else {
              const userPayment = userPaymentDetails.get(reward.userId);
              const dest = userPayment?.payoutMethod === "Bank Transfer" && userPayment.bankAccountNumber ? `Bank: \u2022\u2022\u2022\u2022 ${userPayment.bankAccountNumber.slice(-4)} (${userPayment.bankIfsc || ""})` : userPayment?.upiId ? `UPI: ${userPayment.upiId}` : "UPI: Registered Destination";
              const payoutId = `wd_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
              const autoPayout = {
                id: payoutId,
                userId: reward.userId,
                userName: users.get(reward.userId)?.name || "User",
                amount: reward.amount,
                payoutMethod: userPayment?.payoutMethod || "UPI",
                destinationDetails: dest,
                status: "REQUESTED",
                requestedAt: (/* @__PURE__ */ new Date()).toISOString(),
                rewardId: reward.id
              };
              payouts.unshift(autoPayout);
              reward.withdrawalRequestId = payoutId;
              recordAdminAudit({
                adminId: "SYSTEM",
                adminName: "Automated 7-Day Protocol",
                action: "DISBURSE_QUEUED",
                targetId: autoPayout.id,
                targetType: "payout",
                previousStatus: "HELD_7_DAYS",
                newStatus: "REQUESTED",
                reason: `Automatic withdrawal request generated after 7-day holding maturity (Reward: ${reward.id})`,
                metadata: {
                  userId: reward.userId,
                  rewardId: reward.id,
                  amount: reward.amount
                }
              });
              sendNotification(
                reward.userId,
                "Withdrawal Request Created",
                `Your \u20B9${reward.amount} reward has completed the 7-day holding period and an automated withdrawal request (${autoPayout.id}) has been created for admin review.`,
                "reward_eligible",
                autoPayout.id
              );
            }
          }
        }
      }
    });
  }
  function calculateUserWallet(userId) {
    processMaturedRewardsAndAutoWithdrawals(userId);
    const userRewards = Array.from(callRewards.values()).filter((r) => r.userId === userId);
    let totalEarned = 0;
    userRewards.forEach((reward) => {
      if (reward.status === "held" || reward.status === "verified" || reward.status === "matured") {
        totalEarned += reward.amount;
      }
    });
    const userPayouts = payouts.filter((p) => p.userId === userId);
    let paidOutTotal = 0;
    let pendingBalance = 0;
    userPayouts.forEach((p) => {
      if (p.status === "PAID") {
        paidOutTotal += p.amount;
      } else if (p.status === "REQUESTED" || p.status === "UNDER REVIEW" || p.status === "APPROVED" || p.status === "PROCESSING" || p.status === "PENDING") {
        pendingBalance += p.amount;
      }
    });
    const currentBalance = Math.max(0, totalEarned - paidOutTotal - pendingBalance);
    return {
      userId,
      currentBalance,
      pendingBalance,
      paidOutTotal,
      totalEarned,
      demoBalance: currentBalance,
      pendingRewards: pendingBalance
    };
  }
  function refreshFinancialLedger() {
    let accrued = 0;
    callRewards.forEach((r) => {
      if (r.status === "verified" || r.status === "matured") {
        accrued += r.amount;
      }
    });
    let disbursed = 0;
    payouts.forEach((p) => {
      if (p.status === "PAID") {
        disbursed += p.amount;
      }
    });
    financialFundingLedger.totalUserRewardsAccrued = accrued;
    financialFundingLedger.totalPayoutsDisbursed = disbursed;
    financialFundingLedger.remainingAvailableReserve = Math.max(
      0,
      financialFundingLedger.totalRewardBudget - disbursed
    );
    financialFundingLedger.lastUpdated = (/* @__PURE__ */ new Date()).toISOString();
  }
  function sendNotification(userId, title, message, type, relatedId) {
    const notif = {
      id: `notif_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      userId,
      title,
      message,
      type,
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      read: false,
      relatedId
    };
    notifications.unshift(notif);
    return notif;
  }
  async function runSessionCallVerification(topic, creatorName, participantName, durationSeconds, transcript, simulateRejection = false) {
    const safeTranscript = Array.isArray(transcript) ? transcript : [];
    let creatorTurns = 0;
    let creatorWords = 0;
    let joinerTurns = 0;
    let joinerWords = 0;
    for (const msg of safeTranscript) {
      const text = (msg.text || "").trim();
      const words = text ? text.split(/\s+/).length : 0;
      const isCreator = msg.speakerName === creatorName || msg.speakerId && msg.speakerId.includes("creator");
      if (isCreator) {
        creatorTurns++;
        creatorWords += words;
      } else {
        joinerTurns++;
        joinerWords += words;
      }
    }
    const totalWords = creatorWords + joinerWords;
    const totalTurns = creatorTurns + joinerTurns;
    if (simulateRejection) {
      return {
        decision: "REJECTED",
        confidenceScore: 96,
        summary: "Session Ineligible: Verification criteria failed during automated analysis.",
        reason: "Call could not be verified because mutual dialogue was inadequate or conversation was off-topic.",
        modelUsed: "TalkReward AI Verification Pipeline v2.4",
        evaluatedAt: (/* @__PURE__ */ new Date()).toISOString(),
        criteriaAnalysis: {
          mutualParticipation: { passed: false, score: 25, notes: "One speaker accounted for insufficient dialogue." },
          topicRelevance: { passed: false, score: 30, notes: "Content did not focus on the selected topic." },
          genuineEngagement: { passed: false, score: 35, notes: "Did not meet reciprocal conversation standard." },
          antiGamingCheck: { passed: false, score: 40, notes: "Audio analysis flagged session for low active turns." }
        },
        speakerStats: {
          creatorTurnCount: creatorTurns,
          creatorWordCount: creatorWords,
          joinerTurnCount: joinerTurns,
          joinerWordCount: joinerWords,
          silencePercentage: 65
        }
      };
    }
    if (totalWords < 10 || totalTurns < 2) {
      return {
        decision: "REJECTED",
        confidenceScore: 99,
        summary: "Session Ineligible: Insufficient verbal conversation detected.",
        reason: "Neither participant maintained an active, audible 2-way conversation during the 3-minute session.",
        modelUsed: "TalkReward AI Verification Pipeline v2.4",
        evaluatedAt: (/* @__PURE__ */ new Date()).toISOString(),
        criteriaAnalysis: {
          mutualParticipation: { passed: false, score: 10, notes: "Dialogue turns below the minimum threshold." },
          topicRelevance: { passed: false, score: 10, notes: "Insufficient verbal content to analyze topic relevance." },
          genuineEngagement: { passed: false, score: 5, notes: "Session contained prolonged silence or dead air." },
          antiGamingCheck: { passed: false, score: 15, notes: "Empty audio session detected." }
        },
        speakerStats: {
          creatorTurnCount: creatorTurns,
          creatorWordCount: creatorWords,
          joinerTurnCount: joinerTurns,
          joinerWordCount: joinerWords,
          silencePercentage: 85
        }
      };
    }
    const hasBothSpoken = creatorTurns >= 1 && joinerTurns >= 1 && creatorWords >= 4 && joinerWords >= 4;
    const isTopicMentioned = Boolean(
      topic.toLowerCase().split(/\s+/).filter((w) => w.length > 3).some((word) => safeTranscript.some((t) => (t.text || "").toLowerCase().includes(word))) || totalWords >= 20
    );
    const isGenuine = totalWords >= 15 && totalTurns >= 2;
    const antiGamingPass = totalWords < 1200 && creatorWords / (joinerWords || 1) < 12 && joinerWords / (creatorWords || 1) < 12;
    const allPassed = hasBothSpoken && isTopicMentioned && isGenuine && antiGamingPass;
    return {
      decision: allPassed ? "VERIFIED" : "REJECTED",
      confidenceScore: allPassed ? 96 : 85,
      summary: allPassed ? "Session Verified: Reciprocal 2-person voice conversation on topic." : "Session Ineligible: Failed conversation quality requirements.",
      reason: allPassed ? "Both participants actively exchanged genuine thoughts on the assigned topic throughout the session." : "Call could not be verified because mutual dialogue turns or topic relevance criteria were not satisfied.",
      modelUsed: "TalkReward AI Verification Pipeline v2.4",
      evaluatedAt: (/* @__PURE__ */ new Date()).toISOString(),
      criteriaAnalysis: {
        mutualParticipation: {
          passed: hasBothSpoken,
          score: hasBothSpoken ? 95 : 30,
          notes: hasBothSpoken ? `Both participants (${creatorTurns} & ${joinerTurns} turns) contributed voice audio.` : "Unbalanced speech: One participant did not reach the participation threshold."
        },
        topicRelevance: {
          passed: isTopicMentioned,
          score: isTopicMentioned ? 92 : 35,
          notes: isTopicMentioned ? `Conversation addressed key themes of: "${topic}".` : "Conversation did not sufficiently engage with the selected topic."
        },
        genuineEngagement: {
          passed: isGenuine,
          score: isGenuine ? 95 : 40,
          notes: isGenuine ? "Dialogue displayed authentic back-and-forth communication." : "Conversation lacked reciprocal engagement."
        },
        antiGamingCheck: {
          passed: antiGamingPass,
          score: antiGamingPass ? 98 : 30,
          notes: antiGamingPass ? "No automated audio, dead air, or gaming detected." : "Session flagged for unusual speech distribution."
        }
      },
      speakerStats: {
        creatorTurnCount: creatorTurns,
        creatorWordCount: creatorWords,
        joinerTurnCount: joinerTurns,
        joinerWordCount: joinerWords,
        silencePercentage: Math.max(5, Math.min(50, Math.round(100 - totalWords / 3)))
      }
    };
  }
  const CHARS = "23456789ABCDEFGHJKLMNPQRSTUVWXYZ";
  function generateUniqueCode() {
    let attempts = 0;
    while (attempts < 100) {
      let code = "";
      for (let i = 0; i < 6; i++) {
        code += CHARS.charAt(Math.floor(Math.random() * CHARS.length));
      }
      if (!callsByCode.has(code)) {
        return code;
      }
      attempts++;
    }
    return `TR${Math.floor(1e3 + Math.random() * 9e3)}`;
  }
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", serverTime: (/* @__PURE__ */ new Date()).toISOString() });
  });
  app.post("/api/auth/login", (req, res) => {
    try {
      const { email, identifier, name, referralCode, firebaseUid, avatar } = req.body || {};
      const userEmail = (email || identifier || "").trim().toLowerCase();
      if (!userEmail && !firebaseUid) {
        res.status(400).json({ success: false, error: "Email or authenticated user ID is required." });
        return;
      }
      let user = Array.from(users.values()).find(
        (u) => firebaseUid && u.id === firebaseUid || userEmail && u.email && u.email.toLowerCase() === userEmail
      );
      const isAdminEmail = userEmail === "ff280270@gmail.com";
      if (user && user.status === "BANNED") {
        res.status(403).json({
          success: false,
          isBanned: true,
          error: "Your account has been banned",
          status: "BANNED",
          banReason: user.banReason,
          user: {
            ...user,
            status: "BANNED"
          }
        });
        return;
      }
      if (!user) {
        const id = firebaseUid || `usr_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
        const cleanName = name?.trim() || (userEmail ? userEmail.split("@")[0].replace(/[._]/g, " ") : "Debater");
        const formattedName = cleanName.charAt(0).toUpperCase() + cleanName.slice(1);
        user = {
          id,
          name: formattedName,
          mobile: "",
          email: userEmail || void 0,
          role: isAdminEmail ? "admin" : "user",
          status: "ACTIVE",
          referralCode: referralCode?.trim() || `ZAP-${formattedName.substring(0, 4).toUpperCase()}${Math.floor(10 + Math.random() * 90)}`,
          createdAt: (/* @__PURE__ */ new Date()).toISOString(),
          avatar: avatar || "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80",
          deviceId: `dev_${id.substring(0, 8)}`,
          clientIp: "103.45.89.12",
          lastActiveAt: (/* @__PURE__ */ new Date()).toISOString()
        };
        users.set(id, user);
        sendNotification(
          id,
          "Welcome to Zapple",
          "Complete 3-minute voice calls discussing topics with friends to earn \u20B920 per verified session.",
          "system_announcement"
        );
      } else {
        user.lastActiveAt = (/* @__PURE__ */ new Date()).toISOString();
        if (name && name.trim() && (user.name.startsWith("Debater ") || user.name === "New User")) {
          user.name = name.trim();
        }
        if (userEmail && !user.email) {
          user.email = userEmail;
        }
        if (avatar && !user.avatar) {
          user.avatar = avatar;
        }
        if (isAdminEmail) {
          user.role = "admin";
        } else {
          user.role = "user";
        }
        if (firebaseUid && user.id !== firebaseUid) {
          users.delete(user.id);
          user.id = firebaseUid;
          users.set(firebaseUid, user);
        }
      }
      const wallet = calculateUserWallet(user.id);
      res.json({ success: true, user, wallet, token: `tok_${user.id}_${Date.now()}` });
    } catch (err) {
      console.error("Error in /api/auth/login:", err);
      res.status(500).json({ success: false, error: err?.message || "Authentication server error." });
    }
  });
  app.get("/api/auth/users", (req, res) => {
    try {
      res.json({ success: true, users: Array.from(users.values()) });
    } catch (err) {
      res.status(500).json({ success: false, error: err?.message });
    }
  });
  app.get("/api/auth/user/:userId", (req, res) => {
    try {
      const { userId } = req.params;
      const user = users.get(userId);
      if (!user) {
        res.status(404).json({ error: "User not found." });
        return;
      }
      if (user.status === "BANNED") {
        res.json({
          success: false,
          isBanned: true,
          error: "Your account has been banned",
          status: "BANNED",
          banReason: user.banReason,
          user: {
            ...user,
            status: "BANNED"
          }
        });
        return;
      }
      const wallet = calculateUserWallet(userId);
      res.json({ success: true, user, wallet });
    } catch (err) {
      console.error("Error in /api/auth/user/:userId:", err);
      res.status(500).json({ success: false, error: err?.message || "Server error" });
    }
  });
  app.post("/api/auth/profile", (req, res) => {
    const { userId, name, mobile, email } = req.body;
    const user = users.get(userId);
    if (!user) {
      res.status(404).json({ error: "User not found." });
      return;
    }
    if (name) user.name = name.trim();
    if (mobile) user.mobile = mobile.trim();
    if (email) user.email = email.trim();
    res.json({ success: true, user });
  });
  app.post("/api/auth/delete-account", (req, res) => {
    const { userId } = req.body;
    if (!userId || typeof userId !== "string") {
      res.status(400).json({ success: false, error: "User ID is required for account deletion." });
      return;
    }
    const cleanUserId = userId.trim();
    users.delete(cleanUserId);
    userPaymentDetails.delete(cleanUserId);
    for (let i = notifications.length - 1; i >= 0; i--) {
      if (notifications[i].userId === cleanUserId) {
        notifications.splice(i, 1);
      }
    }
    for (const [invId, inv] of directInvitations.entries()) {
      if (inv.callerId === cleanUserId || inv.recipientId === cleanUserId) {
        directInvitations.delete(invId);
      }
    }
    for (const [, call] of calls.entries()) {
      if (call.creatorId === cleanUserId && call.status === "waiting") {
        call.status = "cancelled";
        if (call.joinCode) {
          callsByCode.delete(call.joinCode);
        }
      }
    }
    for (const [, call] of calls.entries()) {
      if (call.creatorId === cleanUserId) {
        call.creatorName = "Deleted User";
      }
      if (call.participantId === cleanUserId) {
        call.participantName = "Deleted User";
      }
    }
    for (const [, pList] of participants.entries()) {
      for (const p of pList) {
        if (p.userId === cleanUserId) {
          p.userName = "Deleted User";
        }
      }
    }
    for (const ledgerTx of prizePoolTransactions) {
      if (ledgerTx.userId === cleanUserId) {
        ledgerTx.userName = "Deleted User";
      }
      if (ledgerTx.participant1Id === cleanUserId) {
        ledgerTx.participant1Name = "Deleted User";
      }
      if (ledgerTx.participant2Id === cleanUserId) {
        ledgerTx.participant2Name = "Deleted User";
      }
    }
    for (const payout of payouts) {
      if (payout.userId === cleanUserId) {
        payout.userName = "Deleted User";
        payout.destinationDetails = "***[Sanitized]***";
      }
    }
    for (const ticket of supportTickets) {
      if (ticket.userId === cleanUserId) {
        ticket.userName = "Deleted User";
        ticket.message = "[Content redacted upon user account deletion]";
      }
    }
    recordAdminAudit({
      adminId: "system_auth",
      adminName: "System Security",
      action: "SYSTEM_CONFIG",
      targetId: cleanUserId,
      targetType: "user",
      reason: "User permanently requested account deletion and data scrubbing",
      adminNotes: `Account ${cleanUserId} deleted. Firebase Auth removed, personal profile data scrubbed, financial audit records anonymized.`
    });
    res.json({
      success: true,
      message: "Account and associated personal data successfully deleted and anonymized."
    });
  });
  app.post("/api/calls/create", (req, res) => {
    const { topic, creatorId, creatorName, targetDurationSeconds } = req.body;
    if (!topic || typeof topic !== "string" || !topic.trim()) {
      res.status(400).json({ error: "Topic is required." });
      return;
    }
    const caller = users.get(creatorId);
    if (caller && caller.status === "BANNED") {
      res.status(403).json({ success: false, isBanned: true, error: "Your account has been suspended." });
      return;
    }
    const callId = `call_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const joinCode = generateUniqueCode();
    const duration = Number(targetDurationSeconds) > 0 ? Number(targetDurationSeconds) : 180;
    const newCall = {
      callId,
      creatorId: creatorId || "usr_guest",
      creatorName: creatorName || "Debater",
      topic: topic.trim(),
      joinCode,
      status: "waiting",
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      targetDurationSeconds: duration
    };
    calls.set(callId, newCall);
    callsByCode.set(joinCode, callId);
    participants.set(callId, [
      {
        callId,
        userId: newCall.creatorId,
        userName: newCall.creatorName,
        joinedAt: (/* @__PURE__ */ new Date()).toISOString(),
        connectionStatus: "connected",
        lastHeartbeat: Date.now()
      }
    ]);
    signals.set(callId, []);
    res.status(201).json({
      success: true,
      call: newCall,
      joinCode,
      message: "Call created successfully. Share the 6-character code with your partner."
    });
  });
  app.post("/api/calls/call-again", (req, res) => {
    const { callerId, callerName, recipientId, recipientName, topic, previousCallId } = req.body;
    if (!callerId) {
      res.status(400).json({ error: "Caller ID is required." });
      return;
    }
    let targetRecipientId = recipientId;
    let targetRecipientName = recipientName;
    if (!targetRecipientId && previousCallId) {
      const prev = calls.get(previousCallId);
      if (prev) {
        if (prev.creatorId === callerId) {
          targetRecipientId = prev.participantId;
          targetRecipientName = prev.participantName;
        } else {
          targetRecipientId = prev.creatorId;
          targetRecipientName = prev.creatorName;
        }
      }
    }
    if (!targetRecipientId) {
      const otherUser = Array.from(users.values()).find((u) => u.id !== callerId);
      if (otherUser) {
        targetRecipientId = otherUser.id;
        targetRecipientName = otherUser.name;
      } else {
        targetRecipientId = "usr_partner_02";
        targetRecipientName = "Debater Partner";
      }
    }
    const caller = users.get(callerId);
    if (caller && caller.status === "BANNED") {
      res.status(403).json({ success: false, isBanned: true, error: "Your account has been suspended." });
      return;
    }
    const recipient = users.get(targetRecipientId);
    if (recipient && recipient.status === "BANNED") {
      res.status(400).json({ success: false, error: "Cannot initiate call: recipient account is suspended." });
      return;
    }
    const callTopic = topic || (previousCallId ? calls.get(previousCallId)?.topic : "Live Debate Session") || "Live Debate Session";
    const newCallId = `call_direct_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const internalJoinCode = generateUniqueCode();
    const newCall = {
      callId: newCallId,
      creatorId: callerId,
      creatorName: callerName || caller?.name || "Caller",
      participantId: targetRecipientId,
      participantName: targetRecipientName || recipient?.name || "Partner",
      topic: callTopic,
      joinCode: internalJoinCode,
      status: "waiting",
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      targetDurationSeconds: 180
      // 3 minutes
    };
    calls.set(newCallId, newCall);
    callsByCode.set(internalJoinCode, newCallId);
    participants.set(newCallId, [
      {
        callId: newCallId,
        userId: callerId,
        userName: newCall.creatorName,
        joinedAt: (/* @__PURE__ */ new Date()).toISOString(),
        connectionStatus: "connected",
        lastHeartbeat: Date.now()
      }
    ]);
    signals.set(newCallId, []);
    const invitationId = `inv_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const invitation = {
      id: invitationId,
      callId: newCallId,
      callerId,
      callerName: newCall.creatorName,
      callerAvatar: caller?.avatar || "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80",
      recipientId: targetRecipientId,
      recipientName: newCall.participantName,
      recipientAvatar: recipient?.avatar || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80",
      topic: callTopic,
      status: "pending",
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      joinCode: internalJoinCode
    };
    directInvitations.set(invitationId, invitation);
    sendNotification(
      targetRecipientId,
      "Incoming Voice Call",
      `${newCall.creatorName} is calling you for "${callTopic}". Tap to accept and earn \u20B920.`,
      "call_invitation",
      newCallId
    );
    res.status(201).json({
      success: true,
      call: newCall,
      invitation,
      message: "Call session initiated and invitation sent to partner."
    });
  });
  app.get("/api/calls/invitations/pending/:userId", (req, res) => {
    const { userId } = req.params;
    const now = Date.now();
    const pending = Array.from(directInvitations.values()).filter((inv) => inv.recipientId === userId && inv.status === "pending" && now - new Date(inv.createdAt).getTime() < 12e4).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())[0];
    res.json({ success: true, invitation: pending || null });
  });
  app.post("/api/calls/invitations/:invitationId/accept", (req, res) => {
    const { invitationId } = req.params;
    const { recipientId, recipientName } = req.body;
    const recipient = users.get(recipientId);
    if (recipient && recipient.status === "BANNED") {
      res.status(403).json({ success: false, isBanned: true, error: "Your account has been suspended." });
      return;
    }
    const inv = directInvitations.get(invitationId);
    if (!inv) {
      res.status(404).json({ error: "Invitation not found or expired." });
      return;
    }
    inv.status = "accepted";
    const call = calls.get(inv.callId);
    if (call) {
      call.status = "joined";
      call.participantId = recipientId || inv.recipientId;
      call.participantName = recipientName || inv.recipientName;
      const currentParts = participants.get(inv.callId) || [];
      if (!currentParts.some((p) => p.userId === (recipientId || inv.recipientId))) {
        currentParts.push({
          callId: inv.callId,
          userId: recipientId || inv.recipientId,
          userName: call.participantName,
          joinedAt: (/* @__PURE__ */ new Date()).toISOString(),
          connectionStatus: "connected",
          lastHeartbeat: Date.now()
        });
        participants.set(inv.callId, currentParts);
      }
    }
    res.json({ success: true, invitation: inv, call });
  });
  app.post("/api/calls/invitations/:invitationId/decline", (req, res) => {
    const { invitationId } = req.params;
    const inv = directInvitations.get(invitationId);
    if (inv) {
      inv.status = "declined";
      const call = calls.get(inv.callId);
      if (call && call.status === "waiting") {
        call.status = "ended";
        call.endedReason = "cancelled";
      }
    }
    res.json({ success: true, message: "Invitation declined." });
  });
  app.post("/api/calls/invitations/:invitationId/cancel", (req, res) => {
    const { invitationId } = req.params;
    const inv = directInvitations.get(invitationId);
    if (inv) {
      inv.status = "cancelled";
      const call = calls.get(inv.callId);
      if (call && call.status === "waiting") {
        call.status = "ended";
        call.endedReason = "cancelled";
      }
    }
    res.json({ success: true, message: "Call invitation cancelled." });
  });
  app.get("/api/calls/invitations/:invitationId/status", (req, res) => {
    const { invitationId } = req.params;
    const inv = directInvitations.get(invitationId);
    if (!inv) {
      res.status(404).json({ error: "Invitation not found." });
      return;
    }
    const call = calls.get(inv.callId);
    res.json({ success: true, invitation: inv, call });
  });
  app.post("/api/calls/join", (req, res) => {
    const { joinCode, participantId, participantName } = req.body;
    if (!joinCode || typeof joinCode !== "string") {
      res.status(400).json({ error: "Please enter a 6-character code." });
      return;
    }
    const joiner = users.get(participantId);
    if (joiner && joiner.status === "BANNED") {
      res.status(403).json({ success: false, isBanned: true, error: "Your account has been suspended." });
      return;
    }
    const cleanCode = joinCode.trim().toUpperCase();
    const callId = callsByCode.get(cleanCode);
    if (!callId || !calls.has(callId)) {
      res.status(404).json({ error: "Invalid or expired code. Please check the code and try again." });
      return;
    }
    const call = calls.get(callId);
    const codeAgeMs = Date.now() - new Date(call.createdAt).getTime();
    if (codeAgeMs > 5 * 60 * 1e3) {
      callsByCode.delete(cleanCode);
      res.status(400).json({ error: "This 6-character code has expired (5-minute limit exceeded). Please start a new call." });
      return;
    }
    if (call.status === "completed" || call.status === "ended") {
      res.status(400).json({ error: "This call has already completed or expired." });
      return;
    }
    const currentParticipants = participants.get(callId) || [];
    const existingJoined = currentParticipants.find((p) => p.userId === participantId);
    if (!existingJoined && currentParticipants.length >= 2) {
      res.status(403).json({ error: "This call session is full. Exactly 2 participants are permitted." });
      return;
    }
    call.participantId = participantId;
    call.participantName = participantName || "Debater Partner";
    call.status = "joined";
    if (!existingJoined) {
      currentParticipants.push({
        callId,
        userId: participantId,
        userName: call.participantName,
        joinedAt: (/* @__PURE__ */ new Date()).toISOString(),
        connectionStatus: "connected",
        lastHeartbeat: Date.now()
      });
      participants.set(callId, currentParticipants);
      sendNotification(
        call.creatorId,
        "Partner Joined Call",
        `${call.participantName} has joined your session for "${call.topic}". Starting voice call.`,
        "call_invitation",
        call.callId
      );
    }
    res.json({
      success: true,
      call,
      message: "Successfully joined call session."
    });
  });
  app.get("/api/calls/:callId", (req, res) => {
    const { callId } = req.params;
    const call = calls.get(callId);
    if (!call) {
      res.status(404).json({ error: "Call not found." });
      return;
    }
    const currentParticipants = participants.get(callId) || [];
    res.json({ success: true, call, participants: currentParticipants });
  });
  app.post("/api/calls/:callId/start", (req, res) => {
    const { callId } = req.params;
    const call = calls.get(callId);
    if (!call) {
      res.status(404).json({ error: "Call not found." });
      return;
    }
    if (!call.startedAt) {
      call.startedAt = (/* @__PURE__ */ new Date()).toISOString();
      call.status = "active";
    }
    res.json({ success: true, call, startedAt: call.startedAt });
  });
  app.post("/api/calls/:callId/heartbeat", (req, res) => {
    const { callId } = req.params;
    const { userId } = req.body;
    const call = calls.get(callId);
    if (!call) {
      res.status(404).json({ error: "Call not found." });
      return;
    }
    const currentParticipants = participants.get(callId) || [];
    const p = currentParticipants.find((item) => item.userId === userId);
    if (p) {
      p.lastHeartbeat = Date.now();
      p.connectionStatus = "connected";
    }
    res.json({ success: true, status: call.status });
  });
  app.post("/api/calls/:callId/leave", (req, res) => {
    const { callId } = req.params;
    const call = calls.get(callId);
    if (!call) {
      res.status(404).json({ error: "Call not found." });
      return;
    }
    let elapsed = 0;
    if (call.startedAt) {
      elapsed = (Date.now() - new Date(call.startedAt).getTime()) / 1e3;
    }
    const isFullDuration = elapsed >= call.targetDurationSeconds - 3;
    if (!isFullDuration && call.status !== "completed") {
      call.status = "ended";
      call.endedReason = "left_early";
      call.completedAt = (/* @__PURE__ */ new Date()).toISOString();
      call.actualDurationSeconds = Math.round(elapsed);
      callsByCode.delete(call.joinCode);
      res.json({
        success: true,
        call,
        rewardEligible: false,
        message: "Call ended before the 3-minute requirement. No reward generated."
      });
      return;
    }
    res.json({ success: true, call, rewardEligible: isFullDuration });
  });
  app.get("/api/calls/user/:userId", (req, res) => {
    const { userId } = req.params;
    const userCalls = Array.from(calls.values()).filter((c) => c.creatorId === userId || c.participantId === userId).sort((a, b) => new Date(b.completedAt || b.startedAt || b.createdAt).getTime() - new Date(a.completedAt || a.startedAt || a.createdAt).getTime()).map((c) => {
      const isCreator = c.creatorId === userId;
      const otherParticipant = isCreator ? c.participantName || "Waiting for partner" : c.creatorName;
      const rewardKey = `${c.callId}_${userId}`;
      let reward = rewardByCallAndUser.get(rewardKey);
      if (!reward) {
        reward = Array.from(callRewards.values()).find(
          (r) => r.callId === c.callId && r.userId === userId
        );
      }
      let authoritativeStatus = "WAITING";
      let userFacingStatus = "Pending";
      let rewardDisplay = "\u20B920";
      const callStatusUpper = (c.status || "").toUpperCase().trim();
      const rewardStatusLower = (reward?.status || "").toLowerCase().trim();
      if (callStatusUpper === "REJECTED" || callStatusUpper === "CANCELLED" || rewardStatusLower === "rejected" || c.status === "ended" && c.endedReason === "left_early") {
        authoritativeStatus = "REJECTED";
        userFacingStatus = "Rejected";
        rewardDisplay = "\u20B90";
      } else if (callStatusUpper === "REWARD_DISTRIBUTED" || callStatusUpper === "REWARD DISTRIBUTED" || callStatusUpper === "VERIFIED" || c.rewardGranted === true || rewardStatusLower === "held" || rewardStatusLower === "verified" || rewardStatusLower === "matured" || rewardStatusLower === "reward_distributed") {
        authoritativeStatus = "REWARD DISTRIBUTED";
        userFacingStatus = "Verified";
        rewardDisplay = "\u20B920";
      } else if (callStatusUpper === "PENDING_ADMIN_REVIEW" || callStatusUpper === "PENDING ADMIN REVIEW" || rewardStatusLower === "pending_admin_review") {
        authoritativeStatus = "PENDING ADMIN REVIEW";
        userFacingStatus = "Pending";
        rewardDisplay = "\u20B920";
      } else if (callStatusUpper === "VERIFYING" || rewardStatusLower === "verifying" || rewardStatusLower === "pending_verification") {
        authoritativeStatus = "VERIFYING";
        userFacingStatus = "Pending";
        rewardDisplay = "\u20B920";
      } else if (callStatusUpper === "COMPLETED") {
        authoritativeStatus = "COMPLETED";
        userFacingStatus = "Pending";
        rewardDisplay = "\u20B920";
      } else if (callStatusUpper === "ACTIVE" || callStatusUpper === "JOINED") {
        authoritativeStatus = "ACTIVE";
        userFacingStatus = "Pending";
        rewardDisplay = "\u20B920";
      } else {
        authoritativeStatus = "WAITING";
        userFacingStatus = "Pending";
        rewardDisplay = "\u20B920";
      }
      return {
        callId: c.callId,
        topic: c.topic,
        otherParticipant,
        date: c.completedAt || c.startedAt || c.createdAt,
        status: userFacingStatus,
        // User facing: "Pending", "Verified", "Rejected"
        backendStatus: authoritativeStatus,
        // Authoritative: "WAITING", "ACTIVE", "COMPLETED", "VERIFYING", "PENDING ADMIN REVIEW", "VERIFIED", "REWARD DISTRIBUTED", "REJECTED"
        reward: rewardDisplay,
        actualDurationSeconds: c.actualDurationSeconds || 0,
        joinCode: c.joinCode
      };
    });
    const totalCompletedCalls = userCalls.filter(
      (c) => c.status === "Verified" || c.backendStatus === "REWARD DISTRIBUTED"
    ).length;
    res.json({ success: true, calls: userCalls, totalCompletedCalls });
  });
  app.post("/api/calls/:callId/consent", (req, res) => {
    const { callId } = req.params;
    const { userId } = req.body;
    if (!userId) {
      res.status(400).json({ error: "User ID is required." });
      return;
    }
    userConsents.set(`${callId}_${userId}`, {
      userId,
      callId,
      consentedAt: (/* @__PURE__ */ new Date()).toISOString()
    });
    res.json({
      success: true,
      message: "Informed user consent recorded for voice transcription and reward verification."
    });
  });
  app.post("/api/calls/:callId/transcript", (req, res) => {
    const { callId } = req.params;
    const { message, messages } = req.body;
    let current = callTranscripts.get(callId) || [];
    if (Array.isArray(messages)) {
      current = [...current, ...messages];
    } else if (message && typeof message === "object") {
      current.push(message);
    }
    callTranscripts.set(callId, current);
    res.json({ success: true, count: current.length });
  });
  app.get("/api/calls/:callId/transcript", (req, res) => {
    const { callId } = req.params;
    const transcript = callTranscripts.get(callId) || [];
    res.json({ success: true, transcript, count: transcript.length });
  });
  app.post("/api/calls/:callId/complete", (req, res) => {
    const { callId } = req.params;
    const { userId, transcript, isTest, fastComplete } = req.body;
    const call = calls.get(callId);
    if (!call) {
      res.status(404).json({ error: "Call not found." });
      return;
    }
    if (Array.isArray(transcript) && transcript.length > 0) {
      callTranscripts.set(callId, transcript);
    }
    if (!call.startedAt) {
      res.status(400).json({
        success: false,
        rewardEligible: false,
        error: "Security verification failed: Call session was never started."
      });
      return;
    }
    const isFastTesting = Boolean(isTest || fastComplete);
    const elapsedSeconds = isFastTesting ? 180 : (Date.now() - new Date(call.startedAt).getTime()) / 1e3;
    const requiredSeconds = call.targetDurationSeconds;
    const graceSeconds = 4;
    if (!isFastTesting && elapsedSeconds < requiredSeconds - graceSeconds) {
      call.status = "ended";
      call.endedReason = "left_early";
      call.completedAt = (/* @__PURE__ */ new Date()).toISOString();
      call.actualDurationSeconds = Math.round(elapsedSeconds);
      res.status(400).json({
        success: false,
        rewardEligible: false,
        error: `Only ${Math.round(elapsedSeconds)}s completed. Required duration is ${requiredSeconds}s.`
      });
      return;
    }
    call.status = "completed";
    call.endedReason = "completed";
    call.completedAt = (/* @__PURE__ */ new Date()).toISOString();
    call.actualDurationSeconds = Math.round(elapsedSeconds);
    callsByCode.delete(call.joinCode);
    const participantsList = [
      { id: call.creatorId, name: call.creatorName },
      call.participantId ? { id: call.participantId, name: call.participantName || "Debater B" } : null
    ].filter(Boolean);
    let currentUserReward;
    participantsList.forEach((p) => {
      const existingKey = `${call.callId}_${p.id}`;
      if (!rewardByCallAndUser.has(existingKey)) {
        const rewardRecord = {
          id: `rwd_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
          callId: call.callId,
          userId: p.id,
          userName: p.name,
          amount: 20,
          // ₹20
          currency: "INR",
          status: "pending_verification",
          createdAt: (/* @__PURE__ */ new Date()).toISOString(),
          checks: {
            bothJoined: Boolean(call.creatorId && call.participantId && call.creatorId !== call.participantId),
            durationMet: elapsedSeconds >= requiredSeconds - graceSeconds,
            voiceActive: true,
            sessionCompleted: true,
            qualityRulesMet: true
          },
          notes: "3-minute call completed. \u20B920 Pending Verification.",
          userConsentGiven: true,
          transcript: callTranscripts.get(callId) || []
        };
        callRewards.set(rewardRecord.id, rewardRecord);
        rewardByCallAndUser.set(existingKey, rewardRecord);
        sendNotification(
          p.id,
          "Call Completed \u2014 Verification Pending",
          "Your 3-minute voice conversation has finished. \u20B920 is pending AI quality verification.",
          "verification_pending",
          call.callId
        );
        if (p.id === userId) {
          currentUserReward = rewardRecord;
        }
      } else {
        if (p.id === userId) {
          currentUserReward = rewardByCallAndUser.get(existingKey);
        }
      }
    });
    res.json({
      success: true,
      rewardEligible: true,
      call,
      rewardStatus: "pending_verification",
      amount: 20,
      amountFormatted: "\u20B920",
      message: "\u20B920 \u2014 Pending Verification",
      reward: currentUserReward
    });
  });
  app.post("/api/calls/:callId/verify", async (req, res) => {
    const { callId } = req.params;
    const { userId, simulateRejection, transcript: clientTranscript } = req.body;
    const call = calls.get(callId);
    if (!call) {
      res.status(404).json({ error: "Call not found." });
      return;
    }
    call.status = "VERIFYING";
    calls.set(callId, call);
    let sessionTranscript = callTranscripts.get(callId) || [];
    if (Array.isArray(clientTranscript) && clientTranscript.length > 0) {
      sessionTranscript = clientTranscript;
      callTranscripts.set(callId, sessionTranscript);
    }
    const p1Id = call.creatorId || userId || "usr_creator";
    const p1Name = call.creatorName || users.get(p1Id)?.name || "Caller 1";
    const p2Id = call.participantId || participants.get(callId)?.find((p) => p.userId !== p1Id)?.userId || "usr_joiner";
    const p2Name = call.participantName || participants.get(callId)?.find((p) => p.userId !== p1Id)?.userName || users.get(p2Id)?.name || "Caller 2";
    const p1RewardKey = `${callId}_${p1Id}`;
    const p2RewardKey = `${callId}_${p2Id}`;
    let p1Reward = rewardByCallAndUser.get(p1RewardKey);
    let p2Reward = rewardByCallAndUser.get(p2RewardKey);
    if (!p1Reward) {
      p1Reward = {
        id: `rwd_${Date.now()}_p1_${Math.random().toString(36).substring(2, 6)}`,
        callId,
        userId: p1Id,
        userName: p1Name,
        amount: 20,
        currency: "INR",
        status: "pending_verification",
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        checks: {
          bothJoined: true,
          durationMet: true,
          voiceActive: true,
          sessionCompleted: true,
          qualityRulesMet: true
        },
        notes: "Call session pending AI quality verification.",
        userConsentGiven: true,
        transcript: sessionTranscript
      };
      callRewards.set(p1Reward.id, p1Reward);
      rewardByCallAndUser.set(p1RewardKey, p1Reward);
    }
    if (!p2Reward) {
      p2Reward = {
        id: `rwd_${Date.now()}_p2_${Math.random().toString(36).substring(2, 6)}`,
        callId,
        userId: p2Id,
        userName: p2Name,
        amount: 20,
        currency: "INR",
        status: "pending_verification",
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        checks: {
          bothJoined: true,
          durationMet: true,
          voiceActive: true,
          sessionCompleted: true,
          qualityRulesMet: true
        },
        notes: "Call session pending AI quality verification.",
        userConsentGiven: true,
        transcript: sessionTranscript
      };
      callRewards.set(p2Reward.id, p2Reward);
      rewardByCallAndUser.set(p2RewardKey, p2Reward);
    }
    const currentCallerReward = userId === p2Id ? p2Reward : p1Reward;
    if (currentCallerReward.status === "verified" || currentCallerReward.status === "matured") {
      const wallet = calculateUserWallet(userId);
      res.json({
        success: true,
        status: currentCallerReward.status,
        amount: 20,
        amountFormatted: "\u20B920",
        reward: currentCallerReward,
        wallet,
        aiVerification: currentCallerReward.aiVerification,
        message: "This session has already been verified and entered holding."
      });
      return;
    }
    const aiResult = await runSessionCallVerification(
      call.topic,
      call.creatorName,
      call.participantName || "Partner",
      call.actualDurationSeconds || call.targetDurationSeconds,
      sessionTranscript,
      Boolean(simulateRejection)
    );
    p1Reward.aiVerification = aiResult;
    p1Reward.transcript = sessionTranscript;
    p2Reward.aiVerification = aiResult;
    p2Reward.transcript = sessionTranscript;
    if (aiResult.decision === "VERIFIED") {
      p1Reward.status = "pending_admin_review";
      p1Reward.notes = "AI verification passed. Waiting for admin review before reward distribution.";
      p2Reward.status = "pending_admin_review";
      p2Reward.notes = "AI verification passed. Waiting for admin review before reward distribution.";
      const verificationChecks = {
        bothJoined: aiResult.criteriaAnalysis.mutualParticipation.passed,
        durationMet: true,
        voiceActive: aiResult.criteriaAnalysis.genuineEngagement.passed,
        sessionCompleted: true,
        qualityRulesMet: true
      };
      p1Reward.checks = verificationChecks;
      p2Reward.checks = verificationChecks;
      callRewards.set(p1Reward.id, p1Reward);
      callRewards.set(p2Reward.id, p2Reward);
      rewardByCallAndUser.set(p1RewardKey, p1Reward);
      rewardByCallAndUser.set(p2RewardKey, p2Reward);
      call.status = "PENDING_ADMIN_REVIEW";
      call.rewardGranted = false;
      calls.set(callId, call);
      verificationAudits.push({
        auditId: `audit_ai_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        callId,
        userId: p1Id,
        status: "pending_admin_review",
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        checks: p1Reward.checks,
        performedBy: "server_ai_verifier",
        aiVerification: aiResult
      });
      sendNotification(
        p1Id,
        "AI Verification Passed \u2014 Waiting for Admin Review",
        "Your 3-minute voice debate passed AI checks. The session is now in the Admin review queue before reward allocation.",
        "call_completed",
        p1Reward.id
      );
      if (p2Id && p2Id !== p1Id) {
        sendNotification(
          p2Id,
          "AI Verification Passed \u2014 Waiting for Admin Review",
          "Your 3-minute voice debate passed AI checks. The session is now in the Admin review queue before reward allocation.",
          "call_completed",
          p2Reward.id
        );
      }
      refreshFinancialLedger();
      const wallet = calculateUserWallet(userId);
      res.json({
        success: true,
        status: "pending_admin_review",
        callStatus: "COMPLETED",
        amount: 20,
        amountFormatted: "\u20B920",
        reward: currentCallerReward,
        wallet,
        aiVerification: aiResult,
        message: "AI verification completed successfully. Session is now waiting for admin review."
      });
      return;
    } else {
      p1Reward.status = "rejected";
      p1Reward.amount = 0;
      p1Reward.rejectedAt = (/* @__PURE__ */ new Date()).toISOString();
      p1Reward.rejectionReason = aiResult.reason;
      p1Reward.checks = {
        bothJoined: aiResult.criteriaAnalysis.mutualParticipation.passed,
        durationMet: true,
        voiceActive: aiResult.criteriaAnalysis.genuineEngagement.passed,
        sessionCompleted: true,
        qualityRulesMet: false
      };
      p2Reward.status = "rejected";
      p2Reward.amount = 0;
      p2Reward.rejectedAt = (/* @__PURE__ */ new Date()).toISOString();
      p2Reward.rejectionReason = aiResult.reason;
      p2Reward.checks = { ...p1Reward.checks };
      callRewards.set(p1Reward.id, p1Reward);
      callRewards.set(p2Reward.id, p2Reward);
      rewardByCallAndUser.set(p1RewardKey, p1Reward);
      rewardByCallAndUser.set(p2RewardKey, p2Reward);
      call.status = "REJECTED";
      call.rewardGranted = false;
      call.rejectionReason = aiResult.reason;
      calls.set(callId, call);
      verificationAudits.push({
        auditId: `audit_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        callId,
        userId,
        status: "rejected",
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        reason: aiResult.reason,
        checks: p1Reward.checks,
        performedBy: "server_ai_verifier",
        aiVerification: aiResult
      });
      sendNotification(
        userId,
        "Call Ineligible \u2014 Verification Rejected",
        `Verification rejected: ${aiResult.reason}. You may request a manual review.`,
        "verification_rejected",
        call.callId
      );
      refreshFinancialLedger();
      const wallet = calculateUserWallet(userId);
      res.json({
        success: false,
        status: "rejected",
        callStatus: "COMPLETED",
        amount: 0,
        amountFormatted: "\u20B90",
        reason: aiResult.reason,
        reward: currentCallerReward,
        wallet,
        aiVerification: aiResult,
        message: "Call Ineligible: Conversation did not satisfy reward criteria. You may request a manual appeal."
      });
      return;
    }
  });
  app.post("/api/calls/:callId/appeal", (req, res) => {
    const { callId } = req.params;
    const { userId, reason } = req.body;
    const rewardKey = `${callId}_${userId}`;
    const reward = rewardByCallAndUser.get(rewardKey);
    if (!reward) {
      res.status(404).json({ error: "Call reward record not found." });
      return;
    }
    if (reward.status !== "rejected") {
      res.status(400).json({ error: "Only rejected calls can be appealed." });
      return;
    }
    reward.appealStatus = "pending";
    reward.appealReason = reason || "User requested manual review of rejected session audio.";
    reward.appealSubmittedAt = (/* @__PURE__ */ new Date()).toISOString();
    const ticket = {
      id: `tkt_appeal_${Date.now()}`,
      userId,
      userName: reward.userName,
      callId,
      subject: `Call Verification Appeal: ${reward.callId}`,
      message: `User appealed rejected \u20B920 reward: "${reward.appealReason}". Rejection reason was: "${reward.rejectionReason}".`,
      type: "appeal",
      status: "open",
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    supportTickets.unshift(ticket);
    sendNotification(
      userId,
      "Appeal Received",
      "Your appeal has been submitted for manual audit review. You will be notified once reviewed.",
      "system_announcement",
      ticket.id
    );
    res.json({
      success: true,
      reward,
      message: "Appeal submitted successfully for human review."
    });
  });
  app.get("/api/wallet/:userId", (req, res) => {
    const { userId } = req.params;
    const wallet = calculateUserWallet(userId);
    const userRewards = Array.from(callRewards.values()).filter((r) => r.userId === userId);
    res.json({
      success: true,
      wallet,
      holdings: userRewards.map((r) => ({
        id: r.id,
        callId: r.callId,
        amount: r.amount,
        status: r.status,
        verifiedAt: r.verifiedAt,
        holdingPeriodEndsAt: r.holdingPeriodEndsAt,
        isMatured: r.isMatured,
        daysRemaining: r.holdingPeriodEndsAt ? Math.max(0, Math.ceil((new Date(r.holdingPeriodEndsAt).getTime() - Date.now()) / (1e3 * 60 * 60 * 24))) : 0
      }))
    });
  });
  app.post("/api/wallet/mature-holdings", (req, res) => {
    const { userId } = req.body;
    const userRewards = Array.from(callRewards.values()).filter((r) => r.userId === userId);
    let maturedCount = 0;
    userRewards.forEach((r) => {
      if (r.status === "verified" || r.status === "held") {
        r.status = "matured";
        r.isMatured = true;
        r.holdingPeriodEndsAt = (/* @__PURE__ */ new Date()).toISOString();
        maturedCount++;
        transactions.unshift({
          id: `tx_mat_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
          userId,
          callId: r.callId,
          type: "call_reward",
          amount: 20,
          description: "Call Reward (7-Day Holding Period Completed \u2014 Moved to Pending)",
          createdAt: (/* @__PURE__ */ new Date()).toISOString(),
          isCredit: true,
          status: "completed"
        });
        sendNotification(
          userId,
          "Reward Matured \u2014 Moved to Pending",
          "Your \u20B920 call reward completed its 7-day holding period and an automated withdrawal request has been submitted for admin review.",
          "reward_eligible",
          r.id
        );
      }
    });
    const wallet = calculateUserWallet(userId);
    res.json({
      success: true,
      maturedCount,
      wallet,
      message: `Holding period matured for ${maturedCount} reward(s). Moved to Pending and submitted for admin review!`
    });
  });
  app.get("/api/user/:userId/payment-details", (req, res) => {
    const { userId } = req.params;
    const details = userPaymentDetails.get(userId) || {
      userId,
      payoutMethod: "UPI",
      upiId: "",
      isVerified: false,
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    res.json({ success: true, paymentDetails: details });
  });
  app.post("/api/user/:userId/payment-details", (req, res) => {
    const { userId } = req.params;
    const { payoutMethod, upiId, bankAccountNumber, bankIfsc, accountHolderName } = req.body;
    if (payoutMethod === "UPI" && (!upiId || !upiId.includes("@"))) {
      res.status(400).json({ error: "Please enter a valid UPI ID (e.g. username@bank)." });
      return;
    }
    if (payoutMethod === "Bank Transfer" && (!bankAccountNumber || !bankIfsc)) {
      res.status(400).json({ error: "Please enter account number and IFSC code." });
      return;
    }
    const updated = {
      userId,
      payoutMethod: payoutMethod || "UPI",
      upiId: upiId?.trim(),
      bankAccountNumber: bankAccountNumber?.trim(),
      bankIfsc: bankIfsc?.trim().toUpperCase(),
      accountHolderName: accountHolderName?.trim() || users.get(userId)?.name,
      isVerified: true,
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    userPaymentDetails.set(userId, updated);
    res.json({ success: true, paymentDetails: updated, message: "Payout destination configured successfully." });
  });
  app.post("/api/payouts/request", (req, res) => {
    const { userId, amount } = req.body;
    const payoutAmount = Number(amount);
    if (!payoutAmount || payoutAmount < 20) {
      res.status(400).json({ error: "Minimum payout amount is \u20B920." });
      return;
    }
    const requestingUser = users.get(userId);
    if (requestingUser && requestingUser.status === "BANNED") {
      res.status(403).json({ success: false, isBanned: true, error: "Your account has been suspended." });
      return;
    }
    const wallet = calculateUserWallet(userId);
    if (wallet.currentBalance < payoutAmount) {
      res.status(400).json({
        error: `Insufficient available balance. You have \u20B9${wallet.currentBalance} available. Rewards currently under the 15-day holding period (\u20B9${wallet.pendingBalance}) cannot be withdrawn yet.`
      });
      return;
    }
    const paymentDetails = userPaymentDetails.get(userId);
    if (!paymentDetails || !paymentDetails.upiId && !paymentDetails.bankAccountNumber) {
      res.status(400).json({ error: "Please configure your UPI ID or Bank account details before requesting a payout." });
      return;
    }
    refreshFinancialLedger();
    if (financialFundingLedger.remainingAvailableReserve < payoutAmount) {
      res.status(503).json({
        error: "Payout temporarily queuing: Corporate funding reserve replenishment in progress. Please try again shortly."
      });
      return;
    }
    const dest = paymentDetails.payoutMethod === "UPI" ? `UPI: ${paymentDetails.upiId}` : `Bank: \u2022\u2022\u2022\u2022 ${paymentDetails.bankAccountNumber?.slice(-4)} (${paymentDetails.bankIfsc})`;
    const payoutRecord = {
      id: `pay_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      userId,
      userName: users.get(userId)?.name || "User",
      amount: payoutAmount,
      payoutMethod: paymentDetails.payoutMethod,
      destinationDetails: dest,
      status: "PAID",
      // Instant payout simulation via automated banking gateway
      requestedAt: (/* @__PURE__ */ new Date()).toISOString(),
      processedAt: (/* @__PURE__ */ new Date()).toISOString(),
      referenceNumber: `UPI/RR/2026${Math.floor(1e8 + Math.random() * 9e8)}`
    };
    payouts.unshift(payoutRecord);
    const tx = {
      id: `tx_payout_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      userId,
      type: "payout",
      amount: payoutAmount,
      description: `UPI Payout to ${dest} (Ref: ${payoutRecord.referenceNumber})`,
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      isCredit: false,
      status: "completed"
    };
    transactions.unshift(tx);
    refreshFinancialLedger();
    sendNotification(
      userId,
      "Payout Completed",
      `\u20B9${payoutAmount} has been disbursed to ${dest}. Ref: ${payoutRecord.referenceNumber}`,
      "payout_completed",
      payoutRecord.id
    );
    const updatedWallet = calculateUserWallet(userId);
    res.json({
      success: true,
      payout: payoutRecord,
      wallet: updatedWallet,
      transaction: tx,
      message: `\u20B9${payoutAmount} payout processed successfully to ${dest}.`
    });
  });
  app.get("/api/payouts/user/:userId", (req, res) => {
    const { userId } = req.params;
    processMaturedRewardsAndAutoWithdrawals(userId);
    const userPayouts = payouts.filter((p) => p.userId === userId);
    res.json({ success: true, payouts: userPayouts });
  });
  app.get("/api/transactions/:userId", (req, res) => {
    const { userId } = req.params;
    const userTx = transactions.filter((tx) => tx.userId === userId);
    res.json({ success: true, transactions: userTx });
  });
  app.get("/api/notifications/:userId", (req, res) => {
    const { userId } = req.params;
    const userNotifs = notifications.filter((n) => n.userId === userId || n.userId === "all");
    res.json({ success: true, notifications: userNotifs });
  });
  app.post("/api/notifications/:notifId/read", (req, res) => {
    const { notifId } = req.params;
    const n = notifications.find((item) => item.id === notifId);
    if (n) n.read = true;
    res.json({ success: true });
  });
  app.get("/api/financial-ledger", (req, res) => {
    refreshFinancialLedger();
    res.json({ success: true, ledger: financialFundingLedger });
  });
  app.get("/api/pool", (req, res) => {
    checkAndRefreshDailyPool();
    res.json({
      success: true,
      pool: dailyPool
    });
  });
  app.get("/api/admin/prize-pool", (req, res) => {
    if (!verifyAdminRequest(req, res)) return;
    checkAndRefreshDailyPool();
    prizePool.awaitingPoolFundsCallsCount = countAwaitingPoolFundsCalls();
    res.json({
      success: true,
      prizePool,
      dailyPool,
      transactions: prizePoolTransactions.slice(0, 100)
    });
  });
  app.post("/api/admin/prize-pool/add-funds", (req, res) => {
    const callingAdmin = verifyAdminRequest(req, res);
    if (!callingAdmin) return;
    const { amount, note } = req.body;
    const parsedAmount = Number(amount);
    if (amount === void 0 || amount === null || isNaN(parsedAmount) || !isFinite(parsedAmount) || parsedAmount <= 0) {
      res.status(400).json({
        success: false,
        error: "Please enter a valid positive fund injection amount."
      });
      return;
    }
    const prevBalance = prizePool.remainingPoolBalance;
    prizePool.totalPoolBalance += parsedAmount;
    prizePool.remainingPoolBalance = Math.max(0, prizePool.totalPoolBalance - prizePool.totalAllocatedAllTime);
    prizePool.isDailyExhausted = prizePool.dailyRemaining <= 0 || prizePool.remainingPoolBalance < 40;
    prizePool.lastUpdated = (/* @__PURE__ */ new Date()).toISOString();
    dailyPool.remainingAmount = Math.min(dailyPool.remainingAmount, prizePool.remainingPoolBalance);
    dailyPool.isExhausted = prizePool.isDailyExhausted;
    financialFundingLedger.totalRevenueReceived += parsedAmount;
    financialFundingLedger.totalRewardBudget += parsedAmount;
    financialFundingLedger.remainingAvailableReserve = Math.max(
      0,
      financialFundingLedger.totalRewardBudget - financialFundingLedger.totalPayoutsDisbursed
    );
    financialFundingLedger.lastUpdated = (/* @__PURE__ */ new Date()).toISOString();
    const tx = {
      id: `pp_fund_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      type: "FUND_INJECTION",
      amount: parsedAmount,
      previousBalance: prevBalance,
      balanceAfter: prizePool.remainingPoolBalance,
      dailyAllocatedAfter: prizePool.dailyAllocated,
      adminId: callingAdmin.id,
      adminName: callingAdmin.name,
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      note: note?.trim() || `Master Prize Pool capital injection of \u20B9${parsedAmount.toLocaleString("en-IN")}`
    };
    prizePoolTransactions.unshift(tx);
    recordAdminAudit({
      adminId: callingAdmin.id,
      adminName: callingAdmin.name,
      action: "PRIZE_POOL_INJECTION",
      targetId: "prize_pool",
      targetType: "prize_pool",
      previousStatus: `\u20B9${prevBalance.toLocaleString("en-IN")}`,
      newStatus: `\u20B9${prizePool.remainingPoolBalance.toLocaleString("en-IN")}`,
      reason: note?.trim() || `Injected \u20B9${parsedAmount.toLocaleString("en-IN")} to Master Prize Pool`,
      metadata: { amount: parsedAmount, newBalance: prizePool.totalPoolBalance }
    });
    const disbursedQueuedCount = processAwaitingCalls();
    prizePool.awaitingPoolFundsCallsCount = countAwaitingPoolFundsCalls();
    res.json({
      success: true,
      prizePool,
      dailyPool,
      transaction: tx,
      disbursedQueuedCount,
      message: `Prize Pool updated successfully. Added \u20B9${parsedAmount.toLocaleString("en-IN")} to the Prize Pool.${disbursedQueuedCount > 0 ? ` ${disbursedQueuedCount} queued call(s) were automatically funded.` : ""}`
    });
  });
  app.post("/api/admin/prize-pool/set-limit", (req, res) => {
    if (!verifyAdminRequest(req, res)) return;
    const { dailyLimit, note, adminId } = req.body;
    const parsedLimit = Number(dailyLimit);
    if (isNaN(parsedLimit) || parsedLimit < 0) {
      res.status(400).json({ error: "Please enter a valid non-negative daily limit." });
      return;
    }
    const callingAdmin = users.get(adminId) || adminUser;
    const previousLimit = prizePool.dailyLimit;
    const prevBalance = prizePool.remainingPoolBalance;
    prizePool.dailyLimit = parsedLimit;
    prizePool.dailyRemaining = Math.max(0, prizePool.dailyLimit - prizePool.dailyAllocated);
    prizePool.isDailyExhausted = prizePool.dailyRemaining <= 0 || prizePool.remainingPoolBalance < 40;
    prizePool.lastUpdated = (/* @__PURE__ */ new Date()).toISOString();
    dailyPool.totalPoolAmount = prizePool.dailyLimit;
    dailyPool.remainingAmount = prizePool.dailyRemaining;
    dailyPool.isExhausted = prizePool.isDailyExhausted;
    const tx = {
      id: `pp_limit_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      type: "LIMIT_UPDATE",
      amount: 0,
      previousBalance: prevBalance,
      balanceAfter: prizePool.remainingPoolBalance,
      dailyAllocatedAfter: prizePool.dailyAllocated,
      adminId: callingAdmin.id,
      adminName: callingAdmin.name,
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      note: note?.trim() || `Daily Pool Limit updated from \u20B9${previousLimit.toLocaleString("en-IN")} to \u20B9${parsedLimit.toLocaleString("en-IN")}/day`
    };
    prizePoolTransactions.unshift(tx);
    recordAdminAudit({
      adminId: callingAdmin.id,
      adminName: callingAdmin.name,
      action: "PRIZE_POOL_LIMIT_UPDATE",
      targetId: "daily_limit",
      targetType: "prize_pool",
      previousStatus: `\u20B9${previousLimit.toLocaleString("en-IN")}/day`,
      newStatus: `\u20B9${parsedLimit.toLocaleString("en-IN")}/day`,
      reason: note?.trim() || `Updated daily pool distribution cap to \u20B9${parsedLimit.toLocaleString("en-IN")}/day`,
      metadata: { dailyLimit: parsedLimit }
    });
    res.json({
      success: true,
      prizePool,
      transaction: tx,
      message: `Daily Pool Limit successfully configured to \u20B9${parsedLimit.toLocaleString("en-IN")}/day.`
    });
  });
  app.post("/api/admin/prize-pool/reset", (req, res) => {
    if (!verifyAdminRequest(req, res)) return;
    const { adminId, note } = req.body;
    const callingAdmin = users.get(adminId) || adminUser;
    const previousAllocated = prizePool.dailyAllocated;
    const prevBalance = prizePool.remainingPoolBalance;
    prizePool.dailyAllocated = 0;
    prizePool.dailyRemaining = prizePool.dailyLimit;
    prizePool.todayApprovedRewardsCount = 0;
    prizePool.isDailyExhausted = prizePool.remainingPoolBalance < 40;
    prizePool.lastResetAt = (/* @__PURE__ */ new Date()).toISOString();
    prizePool.nextResetAt = getNextMidnightUTC().toISOString();
    prizePool.lastUpdated = (/* @__PURE__ */ new Date()).toISOString();
    dailyPool.allocatedAmount = 0;
    dailyPool.remainingAmount = dailyPool.totalPoolAmount;
    dailyPool.todayApprovedRewardsCount = 0;
    dailyPool.isExhausted = prizePool.isDailyExhausted;
    dailyPool.lastResetAt = prizePool.lastResetAt;
    dailyPool.nextResetAt = prizePool.nextResetAt;
    const tx = {
      id: `pp_reset_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      type: "DAILY_RESET",
      amount: 0,
      previousBalance: prevBalance,
      balanceAfter: prizePool.remainingPoolBalance,
      dailyAllocatedAfter: 0,
      adminId: callingAdmin.id,
      adminName: callingAdmin.name,
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      note: note?.trim() || `Manual Daily Pool Reset by Admin (cleared \u20B9${previousAllocated.toLocaleString("en-IN")} allocated usage)`
    };
    prizePoolTransactions.unshift(tx);
    recordAdminAudit({
      adminId: callingAdmin.id,
      adminName: callingAdmin.name,
      action: "DAILY_POOL_RESET",
      targetId: "daily_pool",
      targetType: "prize_pool",
      previousStatus: `Allocated \u20B9${previousAllocated.toLocaleString("en-IN")}`,
      newStatus: "Allocated \u20B90",
      reason: note?.trim() || `Manual Daily Pool Reset by Admin (cleared \u20B9${previousAllocated.toLocaleString("en-IN")} allocated usage)`,
      metadata: { clearedAmount: previousAllocated }
    });
    res.json({
      success: true,
      prizePool,
      transaction: tx,
      message: "Daily Earning Pool has been reset with server timestamp."
    });
  });
  app.post("/api/admin/prize-pool/disburse-queued", (req, res) => {
    if (!verifyAdminRequest(req, res)) return;
    const disbursedCount = processAwaitingCalls();
    prizePool.awaitingPoolFundsCallsCount = countAwaitingPoolFundsCalls();
    res.json({
      success: true,
      disbursedCount,
      prizePool,
      message: disbursedCount > 0 ? `Successfully disbursed rewards for ${disbursedCount} queued call(s) (\u20B9${disbursedCount * 40} total).` : "No queued calls pending disbursement or insufficient pool balance (\u20B940/call required)."
    });
  });
  app.get("/api/admin/prize-pool/transactions", (req, res) => {
    if (!verifyAdminRequest(req, res)) return;
    const type = req.query.type;
    let list = prizePoolTransactions;
    if (type && type !== "ALL") {
      list = list.filter((t) => t.type === type);
    }
    res.json({
      success: true,
      transactions: list,
      count: list.length
    });
  });
  function getEnrichedUserList() {
    return Array.from(users.values()).map((u) => {
      const userCallsCount = Array.from(calls.values()).filter(
        (c) => c.creatorId === u.id || c.participantId === u.id
      ).length;
      const userWallet = calculateUserWallet(u.id);
      return {
        ...u,
        status: u.status || "ACTIVE",
        totalCallsCount: userCallsCount,
        totalEarned: userWallet.totalEarned,
        currentWalletBalance: userWallet.currentBalance,
        deviceId: u.deviceId || `dev_${u.id.substring(0, 8)}`,
        clientIp: u.clientIp || "103.45.89.12"
      };
    });
  }
  app.get("/api/admin/users", (req, res) => {
    if (!verifyAdminRequest(req, res)) return;
    const query = req.query.query?.trim()?.toLowerCase();
    const status = req.query.status?.trim()?.toUpperCase();
    let list = getEnrichedUserList();
    if (status && status !== "ALL") {
      list = list.filter((u) => (u.status || "ACTIVE") === status);
    }
    if (query) {
      list = list.filter((u) => {
        const matchId = u.id?.toLowerCase().includes(query);
        const matchName = u.name?.toLowerCase().includes(query);
        const matchEmail = u.email?.toLowerCase().includes(query);
        const matchMobile = u.mobile?.toLowerCase().includes(query);
        const matchRef = u.referralCode?.toLowerCase().includes(query);
        const matchDevice = u.deviceId?.toLowerCase().includes(query);
        const matchIp = u.clientIp?.toLowerCase().includes(query);
        return matchId || matchName || matchEmail || matchMobile || matchRef || matchDevice || matchIp;
      });
    }
    list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    res.json({
      success: true,
      users: list,
      totalCount: list.length
    });
  });
  app.post("/api/admin/users/:userId/ban", (req, res) => {
    const callingAdmin = verifyAdminRequest(req, res);
    if (!callingAdmin) return;
    const { userId } = req.params;
    const { reason } = req.body;
    const targetUser = users.get(userId);
    if (!targetUser) {
      res.status(404).json({ success: false, error: "User account not found." });
      return;
    }
    if (targetUser.id === callingAdmin.id || callingAdmin.email && targetUser.email?.toLowerCase() === callingAdmin.email.toLowerCase()) {
      res.status(400).json({ success: false, error: "Administrators cannot ban their own account." });
      return;
    }
    if (targetUser.role === "admin" || targetUser.email?.toLowerCase() === "ff280270@gmail.com") {
      res.status(403).json({ success: false, error: "Protected account: Administrators cannot be banned." });
      return;
    }
    const prevStatus = targetUser.status || "ACTIVE";
    const effectiveReason = reason?.trim() || "Terms of Service violation";
    targetUser.status = "BANNED";
    targetUser.banReason = effectiveReason;
    targetUser.bannedAt = (/* @__PURE__ */ new Date()).toISOString();
    targetUser.bannedBy = callingAdmin.id;
    targetUser.bannedByName = callingAdmin.name;
    calls.forEach((call) => {
      if ((call.creatorId === targetUser.id || call.participantId === targetUser.id) && (call.status === "active" || call.status === "waiting" || call.status === "joined")) {
        call.status = "ended";
        call.endedReason = "cancelled";
        call.rejectionReason = "Session terminated: participant account suspended.";
      }
    });
    const audit = recordAdminAudit({
      adminId: callingAdmin.id,
      adminName: callingAdmin.name,
      action: "USER_BANNED",
      targetId: targetUser.id,
      targetType: "user",
      previousStatus: prevStatus,
      newStatus: "BANNED",
      reason: effectiveReason,
      metadata: {
        userId: targetUser.id,
        userName: targetUser.name,
        userEmail: targetUser.email,
        userMobile: targetUser.mobile,
        deviceId: targetUser.deviceId,
        banReason: effectiveReason
      }
    });
    res.json({
      success: true,
      user: targetUser,
      audit,
      message: `User ${targetUser.name} (${targetUser.email || targetUser.id}) has been banned.`
    });
  });
  app.post("/api/admin/users/:userId/unban", (req, res) => {
    const callingAdmin = verifyAdminRequest(req, res);
    if (!callingAdmin) return;
    const { userId } = req.params;
    const targetUser = users.get(userId);
    if (!targetUser) {
      res.status(404).json({ success: false, error: "User account not found." });
      return;
    }
    const prevStatus = targetUser.status || "ACTIVE";
    targetUser.status = "ACTIVE";
    targetUser.banReason = void 0;
    targetUser.bannedAt = void 0;
    targetUser.bannedBy = void 0;
    targetUser.bannedByName = void 0;
    targetUser.unbannedAt = (/* @__PURE__ */ new Date()).toISOString();
    targetUser.unbannedBy = callingAdmin.id;
    targetUser.unbannedByName = callingAdmin.name;
    const audit = recordAdminAudit({
      adminId: callingAdmin.id,
      adminName: callingAdmin.name,
      action: "USER_UNBANNED",
      targetId: targetUser.id,
      targetType: "user",
      previousStatus: prevStatus,
      newStatus: "ACTIVE",
      reason: "Account reinstated by administrator",
      metadata: {
        userId: targetUser.id,
        userName: targetUser.name,
        userEmail: targetUser.email
      }
    });
    res.json({
      success: true,
      user: targetUser,
      audit,
      message: `User ${targetUser.name} (${targetUser.email || targetUser.id}) has been unbanned.`
    });
  });
  app.get("/api/admin/overview", (req, res) => {
    if (!verifyAdminRequest(req, res)) return;
    refreshFinancialLedger();
    checkAndRefreshDailyPool();
    const allCalls = Array.from(calls.values());
    const allRewards = Array.from(callRewards.values());
    const allUsers = getEnrichedUserList();
    const completedCallsCount = allCalls.filter((c) => c.status === "completed").length;
    const activeCallsCount = allCalls.filter((c) => c.status === "active" || c.status === "joined").length;
    const pendingVerificationCount = allRewards.filter((r) => r.status === "pending_verification").length;
    const rejectedCallsCount = allRewards.filter((r) => r.status === "rejected").length;
    const pendingPayouts = payouts.filter((p) => p.status === "PENDING");
    const paidPayouts = payouts.filter((p) => p.status === "PAID");
    const rejectedPayouts = payouts.filter((p) => p.status === "REJECTED" || p.status === "FAILED");
    const totalDisbursedAmount = paidPayouts.reduce((sum, p) => sum + p.amount, 0);
    const suspiciousCalls = allCalls.filter((c) => {
      const transcript = callTranscripts.get(c.callId) || [];
      const p1Reward = Array.from(callRewards.values()).find((r) => r.callId === c.callId);
      const aiVer = p1Reward?.aiVerification;
      const silence = aiVer?.speakerStats?.silencePercentage || 0;
      const isShort = (c.actualDurationSeconds || 0) < 60 && c.status === "completed";
      const lowTurns = transcript.length < 3 && c.status === "completed";
      return silence > 50 || isShort || lowTurns;
    }).map((c) => {
      const transcript = callTranscripts.get(c.callId) || [];
      const p1Reward = Array.from(callRewards.values()).find((r) => r.callId === c.callId);
      const aiVer = p1Reward?.aiVerification;
      const silence = aiVer?.speakerStats?.silencePercentage || 0;
      let flagReason = "Unusual conversation pattern detected";
      if (silence > 50) flagReason = `High dead air / silence detected (${silence}% of call)`;
      else if (transcript.length < 3) flagReason = "Insufficient dialogue exchange (< 3 speaker turns)";
      else if ((c.actualDurationSeconds || 0) < 60) flagReason = "Call ended prematurely (< 60 seconds)";
      return {
        callId: c.callId,
        joinCode: c.joinCode,
        topic: c.topic,
        creatorName: c.creatorName,
        participantName: c.participantName || "Awaiting Joiner",
        duration: c.actualDurationSeconds || 0,
        silencePercentage: silence,
        turnsCount: transcript.length,
        flagReason,
        status: c.status,
        createdAt: c.createdAt
      };
    });
    res.json({
      success: true,
      pool: dailyPool,
      prizePool,
      prizePoolTransactions: prizePoolTransactions.slice(0, 50),
      users: allUsers,
      calls: allCalls,
      rewards: allRewards,
      audits: verificationAudits,
      adminAuditLogs: adminAuditLogs.slice(0, 50),
      payouts,
      transactions,
      tickets: supportTickets,
      ledger: financialFundingLedger,
      metrics: {
        totalPoolBalance: prizePool.totalPoolBalance,
        remainingPoolBalance: prizePool.remainingPoolBalance,
        totalAllocatedAllTime: prizePool.totalAllocatedAllTime,
        dailyLimit: prizePool.dailyLimit,
        dailyAllocated: prizePool.dailyAllocated,
        dailyRemaining: prizePool.dailyRemaining,
        completedCallsCount,
        activeCallsCount,
        pendingVerificationCount,
        rejectedCallsCount,
        totalUsersCount: allUsers.length,
        pendingPayoutsCount: pendingPayouts.length,
        pendingPayoutsAmount: pendingPayouts.reduce((sum, p) => sum + p.amount, 0),
        totalDisbursedAmount,
        rejectedPayoutsCount: rejectedPayouts.length,
        suspiciousCallsCount: suspiciousCalls.length
      },
      suspiciousCalls
    });
  });
  app.get("/api/admin/calls", (req, res) => {
    if (!verifyAdminRequest(req, res)) return;
    const allCalls = Array.from(calls.values()).sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
    const enrichedCalls = allCalls.map((call) => {
      const transcript = callTranscripts.get(call.callId) || [];
      const p1Reward = Array.from(callRewards.values()).find(
        (r) => r.callId === call.callId && r.userId === call.creatorId
      );
      const p2Reward = Array.from(callRewards.values()).find(
        (r) => r.callId === call.callId && r.userId === call.participantId
      );
      const aiVer = p1Reward?.aiVerification || p2Reward?.aiVerification;
      const silence = aiVer?.speakerStats?.silencePercentage || 0;
      const lowTurns = transcript.length < 3 && call.status === "completed";
      const isSuspicious = silence > 50 || lowTurns;
      let flagReason = "";
      if (silence > 50) flagReason = `High silence percentage (${silence}%)`;
      else if (lowTurns) flagReason = "Low speaker turn exchange (< 3 turns)";
      return {
        ...call,
        rewardStatus: p1Reward?.status || p2Reward?.status || "pending_admin_review",
        aiVerificationResult: aiVer,
        durationSeconds: call.actualDurationSeconds || call.targetDurationSeconds || 180,
        participant1: {
          id: call.creatorId,
          name: call.creatorName,
          rewardStatus: p1Reward?.status || "pending_verification",
          rewardAmount: p1Reward?.amount || 20,
          holdingPeriodEndsAt: p1Reward?.holdingPeriodEndsAt,
          rejectionReason: p1Reward?.rejectionReason,
          checks: p1Reward?.checks
        },
        participant2: call.participantId ? {
          id: call.participantId,
          name: call.participantName || "Debater Partner",
          rewardStatus: p2Reward?.status || "pending_verification",
          rewardAmount: p2Reward?.amount || 20,
          holdingPeriodEndsAt: p2Reward?.holdingPeriodEndsAt,
          rejectionReason: p2Reward?.rejectionReason,
          checks: p2Reward?.checks
        } : null,
        transcript,
        aiVerification: aiVer,
        isFlaggedSuspicious: isSuspicious,
        flagReason
      };
    });
    res.json({
      success: true,
      calls: enrichedCalls,
      count: enrichedCalls.length
    });
  });
  app.get("/api/admin/payouts", (req, res) => {
    if (!verifyAdminRequest(req, res)) return;
    res.json({
      success: true,
      payouts,
      count: payouts.length
    });
  });
  app.post("/api/admin/payouts/:payoutId/approve", (req, res) => {
    if (!verifyAdminRequest(req, res)) return;
    const { payoutId } = req.params;
    const { referenceNumber, adminId, note } = req.body;
    const payout = payouts.find((p) => p.id === payoutId);
    if (!payout) {
      res.status(404).json({ error: "Payout request record not found." });
      return;
    }
    if (payout.status === "PAID") {
      res.status(400).json({ error: "This payout has already been approved and disbursed." });
      return;
    }
    const callingAdmin = users.get(adminId) || adminUser;
    const prevStatus = payout.status;
    const ref = referenceNumber?.trim() || `UPI/RR/2026${Math.floor(1e8 + Math.random() * 9e8)}`;
    payout.status = "PAID";
    payout.processedAt = (/* @__PURE__ */ new Date()).toISOString();
    payout.referenceNumber = ref;
    prizePoolTransactions.unshift({
      id: `pp_payout_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      type: "PAYOUT_DEDUCTION",
      amount: -payout.amount,
      balanceAfter: prizePool.remainingPoolBalance,
      dailyAllocatedAfter: prizePool.dailyAllocated,
      adminId: callingAdmin.id,
      adminName: callingAdmin.name,
      userId: payout.userId,
      userName: payout.userName,
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      note: `Disbursed \u20B9${payout.amount} payout to ${payout.userName} via ${payout.payoutMethod} (Ref #${ref})`
    });
    refreshFinancialLedger();
    recordAdminAudit({
      adminId: callingAdmin.id,
      adminName: callingAdmin.name,
      action: "WITHDRAWAL_APPROVED",
      targetId: payout.id,
      targetType: "payout",
      previousStatus: prevStatus,
      newStatus: "PAID",
      reason: note?.trim() || `Approved \u20B9${payout.amount} payout with reference #${ref}`,
      metadata: {
        userId: payout.userId,
        userName: payout.userName,
        amount: payout.amount,
        payoutMethod: payout.payoutMethod,
        referenceNumber: ref
      }
    });
    sendNotification(
      payout.userId,
      "Payout Disbursed Successfully",
      `\u20B9${payout.amount} has been successfully disbursed to your ${payout.payoutMethod}. Reference: ${ref}`,
      "payout_completed",
      payout.id
    );
    res.json({
      success: true,
      payout,
      message: `Payout of \u20B9${payout.amount} approved and disbursed. Ref: ${ref}`
    });
  });
  app.post("/api/admin/payouts/:payoutId/reject", (req, res) => {
    if (!verifyAdminRequest(req, res)) return;
    const { payoutId } = req.params;
    const { failureReason, adminId } = req.body;
    const payout = payouts.find((p) => p.id === payoutId);
    if (!payout) {
      res.status(404).json({ error: "Payout request record not found." });
      return;
    }
    if (!failureReason || !failureReason.trim()) {
      res.status(400).json({ error: "A rejection/failure reason is required." });
      return;
    }
    const callingAdmin = users.get(adminId) || adminUser;
    const prevStatus = payout.status;
    const reasonText = failureReason.trim();
    payout.status = "REJECTED";
    payout.failureReason = reasonText;
    recordAdminAudit({
      adminId: callingAdmin.id,
      adminName: callingAdmin.name,
      action: "WITHDRAWAL_REJECTED",
      targetId: payout.id,
      targetType: "payout",
      previousStatus: prevStatus,
      newStatus: "REJECTED",
      reason: reasonText,
      metadata: {
        userId: payout.userId,
        userName: payout.userName,
        amount: payout.amount,
        payoutMethod: payout.payoutMethod
      }
    });
    sendNotification(
      payout.userId,
      "Payout Request Rejected",
      `Your payout request for \u20B9${payout.amount} was rejected: ${reasonText}`,
      "system_announcement",
      payout.id
    );
    res.json({
      success: true,
      payout,
      message: `Payout rejected: ${reasonText}`
    });
  });
  app.post("/api/admin/payouts/:payoutId/status", (req, res) => {
    if (!verifyAdminRequest(req, res)) return;
    const { payoutId } = req.params;
    const { status, referenceNumber, failureReason, adminId } = req.body;
    const payout = payouts.find((p) => p.id === payoutId);
    if (!payout) {
      res.status(404).json({ error: "Payout request not found." });
      return;
    }
    const callingAdmin = users.get(adminId) || adminUser;
    const prevStatus = payout.status;
    if (status) {
      payout.status = status;
      if (status === "PAID") {
        payout.processedAt = (/* @__PURE__ */ new Date()).toISOString();
        const ref = referenceNumber || `UPI/RR/2026${Math.floor(1e8 + Math.random() * 9e8)}`;
        payout.referenceNumber = ref;
        prizePoolTransactions.unshift({
          id: `pp_payout_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
          type: "PAYOUT_DEDUCTION",
          amount: -payout.amount,
          balanceAfter: prizePool.remainingPoolBalance,
          dailyAllocatedAfter: prizePool.dailyAllocated,
          adminId: callingAdmin.id,
          adminName: callingAdmin.name,
          userId: payout.userId,
          userName: payout.userName,
          timestamp: (/* @__PURE__ */ new Date()).toISOString(),
          note: `Disbursed \u20B9${payout.amount} payout to ${payout.userName} via ${payout.payoutMethod} (Ref #${ref})`
        });
        recordAdminAudit({
          adminId: callingAdmin.id,
          adminName: callingAdmin.name,
          action: "WITHDRAWAL_APPROVED",
          targetId: payout.id,
          targetType: "payout",
          previousStatus: prevStatus,
          newStatus: "PAID",
          reason: `Approved payout #${ref}`
        });
      } else if (status === "FAILED" || status === "REJECTED") {
        payout.failureReason = failureReason || "Verification check failed during bank gateway processing.";
        recordAdminAudit({
          adminId: callingAdmin.id,
          adminName: callingAdmin.name,
          action: "WITHDRAWAL_REJECTED",
          targetId: payout.id,
          targetType: "payout",
          previousStatus: prevStatus,
          newStatus: status,
          reason: payout.failureReason
        });
      }
    }
    refreshFinancialLedger();
    res.json({ success: true, payout, message: `Payout status updated to ${payout.status}.` });
  });
  app.post("/api/admin/calls/:callId/review", (req, res) => {
    if (!verifyAdminRequest(req, res)) return;
    const { callId } = req.params;
    const { decision, reason, reviewerName, adminId } = req.body;
    const call = calls.get(callId);
    if (!call) {
      res.status(404).json({ error: "Call session not found." });
      return;
    }
    const callingAdmin = users.get(adminId) || adminUser;
    if (decision === "VERIFIED") {
      checkAndRefreshDailyPool();
      const TOTAL_CALL_REWARD = 40;
      if (prizePool.remainingPoolBalance < TOTAL_CALL_REWARD) {
        res.status(400).json({
          error: `Master Prize Pool treasury insufficient. Remaining balance is \u20B9${prizePool.remainingPoolBalance}, but \u20B9${TOTAL_CALL_REWARD} is required to allocate \u20B920 to both participants. Please add funds to the Master Prize Pool first.`
        });
        return;
      }
      if (prizePool.dailyAllocated + TOTAL_CALL_REWARD > prizePool.dailyLimit) {
        res.status(400).json({
          error: `Daily Earning Pool limit reached for today. Daily budget remaining: \u20B9${prizePool.dailyRemaining}. Approving \u20B9${TOTAL_CALL_REWARD} would exceed the daily cap.`
        });
        return;
      }
      const holdingEndsAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1e3).toISOString();
      const updatedRewards = [];
      let previousCallRewardStatus = "PENDING_ADMIN_REVIEW";
      for (const reward of callRewards.values()) {
        if (reward.callId === callId) {
          previousCallRewardStatus = reward.status || "PENDING_ADMIN_REVIEW";
          reward.status = "held";
          reward.amount = 20;
          reward.verifiedAt = (/* @__PURE__ */ new Date()).toISOString();
          reward.holdingPeriodEndsAt = holdingEndsAt;
          reward.isMatured = false;
          reward.notes = `Admin Approval by ${reviewerName || callingAdmin.name}: ${reason || "Audio dialogue verified"}`;
          updatedRewards.push(reward);
          const tx = {
            id: `tx_call_${Date.now()}_${reward.userId}`,
            userId: reward.userId,
            callId,
            type: "call_reward",
            amount: 20,
            description: "Call Reward (Admin Approved \u2014 7-Day Holding Period)",
            createdAt: (/* @__PURE__ */ new Date()).toISOString(),
            isCredit: true,
            status: "completed"
          };
          transactions.unshift(tx);
          verificationAudits.push({
            auditId: `audit_man_${Date.now()}_${reward.userId}`,
            callId,
            userId: reward.userId,
            status: "held",
            timestamp: (/* @__PURE__ */ new Date()).toISOString(),
            performedBy: "admin_audit",
            reason: reason || "Manual supervisor verification passed.",
            checks: reward.checks
          });
          sendNotification(
            reward.userId,
            "Call Approved by Admin",
            "Your call was approved by admin supervisor. \u20B920 entered 7-day holding period.",
            "verification_approved",
            reward.id
          );
          callRewards.set(reward.id, reward);
          rewardByCallAndUser.set(`${callId}_${reward.userId}`, reward);
        }
      }
      call.status = "REWARD_DISTRIBUTED";
      call.rewardGranted = true;
      call.reviewedBy = reviewerName || callingAdmin.name;
      call.reviewedAt = (/* @__PURE__ */ new Date()).toISOString();
      calls.set(callId, call);
      const prevPoolBalance = prizePool.remainingPoolBalance;
      prizePool.dailyAllocated += TOTAL_CALL_REWARD;
      prizePool.totalAllocatedAllTime += TOTAL_CALL_REWARD;
      prizePool.todayApprovedRewardsCount += 2;
      prizePool.remainingPoolBalance = Math.max(0, prizePool.totalPoolBalance - prizePool.totalAllocatedAllTime);
      prizePool.dailyRemaining = Math.max(0, prizePool.dailyLimit - prizePool.dailyAllocated);
      prizePool.isDailyExhausted = prizePool.dailyRemaining <= 0 || prizePool.remainingPoolBalance < 40;
      dailyPool.allocatedAmount = prizePool.dailyAllocated;
      dailyPool.remainingAmount = prizePool.dailyRemaining;
      dailyPool.todayApprovedRewardsCount = prizePool.todayApprovedRewardsCount;
      dailyPool.isExhausted = prizePool.isDailyExhausted;
      prizePoolTransactions.unshift({
        id: `pp_tx_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        type: "REWARD_ALLOCATION",
        amount: -TOTAL_CALL_REWARD,
        previousBalance: prevPoolBalance,
        balanceAfter: prizePool.remainingPoolBalance,
        dailyAllocatedAfter: prizePool.dailyAllocated,
        adminId: callingAdmin.id,
        adminName: callingAdmin.name,
        callId,
        topic: call.topic,
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        note: `Admin Approval: \u20B940 allocated (\u20B920 to ${call.creatorName} & ${call.participantName || "Joiner"}) in 7-day holding`
      });
      recordAdminAudit({
        adminId: callingAdmin.id,
        adminName: callingAdmin.name,
        action: "CALL_APPROVED",
        targetId: callId,
        targetType: "call",
        previousStatus: previousCallRewardStatus,
        newStatus: "HELD",
        rewardAmount: 20,
        reason: reason?.trim() || "Manual audio review verified reciprocal dialogue and topic relevance.",
        adminNotes: reason?.trim() || "Manual audio review verified reciprocal dialogue and topic relevance.",
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        metadata: {
          topic: call.topic,
          creatorId: call.creatorId,
          participantId: call.participantId,
          totalReward: TOTAL_CALL_REWARD,
          holdingPeriodDays: 7
        }
      });
      refreshFinancialLedger();
      res.json({
        success: true,
        message: `Call ${callId} successfully approved by admin. \u20B920 allocated to each participant (\u20B940 total) in 7-day holding.`,
        rewards: updatedRewards
      });
      return;
    } else if (decision === "REJECTED") {
      if (!reason || !reason.trim()) {
        res.status(400).json({ error: "A mandatory rejection reason is required when marking a call as ineligible." });
        return;
      }
      const rejectionReason = reason.trim();
      const updatedRewards = [];
      let previousCallRewardStatus = "PENDING_ADMIN_REVIEW";
      for (const reward of callRewards.values()) {
        if (reward.callId === callId) {
          previousCallRewardStatus = reward.status || "PENDING_ADMIN_REVIEW";
          reward.status = "rejected";
          reward.amount = 0;
          reward.rejectedAt = (/* @__PURE__ */ new Date()).toISOString();
          reward.rejectionReason = rejectionReason;
          reward.notes = `Manual Admin Rejection: ${rejectionReason}`;
          updatedRewards.push(reward);
          verificationAudits.push({
            auditId: `audit_man_${Date.now()}_${reward.userId}`,
            callId,
            userId: reward.userId,
            status: "rejected",
            timestamp: (/* @__PURE__ */ new Date()).toISOString(),
            performedBy: "admin_audit",
            reason: rejectionReason,
            checks: reward.checks
          });
          sendNotification(
            reward.userId,
            "Call Review Decision",
            `Your call review was completed: Rejected \u2014 ${rejectionReason}`,
            "verification_rejected",
            reward.id
          );
          callRewards.set(reward.id, reward);
          rewardByCallAndUser.set(`${callId}_${reward.userId}`, reward);
        }
      }
      call.status = "REJECTED";
      call.rewardGranted = false;
      call.reviewedBy = reviewerName || callingAdmin.name;
      call.reviewedAt = (/* @__PURE__ */ new Date()).toISOString();
      call.rejectionReason = rejectionReason;
      calls.set(callId, call);
      recordAdminAudit({
        adminId: callingAdmin.id,
        adminName: callingAdmin.name,
        action: "CALL_REJECTED",
        targetId: callId,
        targetType: "call",
        previousStatus: previousCallRewardStatus,
        newStatus: "REJECTED",
        rewardAmount: 0,
        reason: rejectionReason,
        adminNotes: rejectionReason,
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        metadata: {
          topic: call.topic,
          creatorId: call.creatorId,
          participantId: call.participantId
        }
      });
      refreshFinancialLedger();
      res.json({
        success: true,
        message: `Call ${callId} marked as ineligible. Reason: ${rejectionReason}`,
        rewards: updatedRewards
      });
      return;
    } else {
      res.status(400).json({ error: "Invalid decision. Must be VERIFIED or REJECTED." });
    }
  });
  app.get("/api/admin/audits", (req, res) => {
    if (!verifyAdminRequest(req, res)) return;
    res.json({
      success: true,
      audits: adminAuditLogs,
      count: adminAuditLogs.length
    });
  });
  app.post("/api/admin/appeal-action", (req, res) => {
    if (!verifyAdminRequest(req, res)) return;
    const { callId, userId, action, reason, adminId } = req.body;
    const rewardKey = `${callId}_${userId}`;
    const reward = rewardByCallAndUser.get(rewardKey);
    if (!reward) {
      res.status(404).json({ error: "Reward record not found." });
      return;
    }
    const callingAdmin = users.get(adminId) || adminUser;
    if (action === "approve") {
      checkAndRefreshDailyPool();
      const REWARD_AMOUNT = 20;
      if (prizePool.remainingPoolBalance < REWARD_AMOUNT) {
        res.status(400).json({
          error: "Master Prize Pool treasury exhausted. Cannot approve appeal reward."
        });
        return;
      }
      if (prizePool.dailyAllocated + REWARD_AMOUNT > prizePool.dailyLimit) {
        res.status(400).json({
          error: "Daily Earning Pool limit reached for today. Cannot approve appeal exceeding daily limit."
        });
        return;
      }
      reward.status = "verified";
      reward.appealStatus = "approved";
      reward.verifiedAt = (/* @__PURE__ */ new Date()).toISOString();
      reward.holdingPeriodEndsAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1e3).toISOString();
      reward.isMatured = false;
      prizePool.dailyAllocated += REWARD_AMOUNT;
      prizePool.totalAllocatedAllTime += REWARD_AMOUNT;
      prizePool.todayApprovedRewardsCount += 1;
      prizePool.remainingPoolBalance = Math.max(0, prizePool.totalPoolBalance - prizePool.totalAllocatedAllTime);
      prizePool.dailyRemaining = Math.max(0, prizePool.dailyLimit - prizePool.dailyAllocated);
      prizePool.isDailyExhausted = prizePool.dailyRemaining <= 0 || prizePool.remainingPoolBalance < REWARD_AMOUNT;
      dailyPool.allocatedAmount = prizePool.dailyAllocated;
      dailyPool.remainingAmount = prizePool.dailyRemaining;
      dailyPool.todayApprovedRewardsCount = prizePool.todayApprovedRewardsCount;
      dailyPool.isExhausted = prizePool.isDailyExhausted;
      prizePoolTransactions.unshift({
        id: `pp_appeal_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        type: "REWARD_ALLOCATION",
        amount: -REWARD_AMOUNT,
        balanceAfter: prizePool.remainingPoolBalance,
        dailyAllocatedAfter: prizePool.dailyAllocated,
        adminId: callingAdmin.id,
        adminName: callingAdmin.name,
        userId,
        userName: reward.userName,
        callId,
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        note: `Appeal Approved: \u20B920 reward allocated by ${callingAdmin.name}`
      });
      transactions.unshift({
        id: `tx_appeal_appr_${Date.now()}`,
        userId,
        callId,
        type: "call_reward",
        amount: 20,
        description: "Call Reward (Appeal Approved by Admin \u2014 7-Day Holding)",
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        isCredit: true,
        status: "completed"
      });
      verificationAudits.push({
        auditId: `audit_appeal_${Date.now()}`,
        callId,
        userId,
        status: "verified",
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        performedBy: "appeal_reviewer",
        reason: reason || "Manual audio review verified reciprocal dialogue.",
        checks: reward.checks
      });
      sendNotification(
        userId,
        "Appeal Approved \u2014 \u20B920 Reward Verified",
        "Your appeal has been reviewed and approved by human supervisor. \u20B920 has entered the 7-day holding period.",
        "verification_approved",
        reward.id
      );
      refreshFinancialLedger();
      res.json({ success: true, reward, message: "Appeal approved and reward granted." });
    } else {
      reward.appealStatus = "rejected";
      reward.rejectionReason = reason || "Appeal reviewed: session did not fulfill participation rules.";
      sendNotification(
        userId,
        "Appeal Decision",
        `Your appeal was reviewed: ${reward.rejectionReason}`,
        "verification_rejected",
        reward.id
      );
      res.json({ success: true, reward, message: "Appeal rejected." });
    }
  });
  app.post("/api/calls/:callId/signal", (req, res) => {
    const { callId } = req.params;
    const { senderId, targetId, type, payload } = req.body;
    const list = signals.get(callId) || [];
    const msg = {
      id: `sig_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      callId,
      senderId,
      targetId,
      type,
      payload,
      timestamp: Date.now()
    };
    list.push(msg);
    if (list.length > 50) list.shift();
    signals.set(callId, list);
    res.json({ success: true });
  });
  app.get("/api/calls/:callId/signals", (req, res) => {
    const { callId } = req.params;
    const since = Number(req.query.since) || 0;
    const list = signals.get(callId) || [];
    const newSignals = list.filter((s) => s.timestamp > since);
    res.json({ signals: newSignals, now: Date.now() });
  });
  app.get("/download-project.zip", (req, res) => {
    const zipPath = import_path.default.join(process.cwd(), "public", "zapple-project.zip");
    res.setHeader("Content-Type", "application/zip");
    res.setHeader("Content-Disposition", 'attachment; filename="zapple-project.zip"');
    res.sendFile(zipPath, (err) => {
      if (err && !res.headersSent) {
        res.status(404).send("ZIP file not found.");
      }
    });
  });
  app.get("/zapple.apk", (req, res) => {
    const apkPath = import_path.default.join(process.cwd(), "public", "zapple.apk");
    res.setHeader("Content-Type", "application/vnd.android.package-archive");
    res.setHeader("Content-Disposition", 'attachment; filename="zapple.apk"');
    res.sendFile(apkPath, (err) => {
      if (err && !res.headersSent) {
        res.status(404).send("APK file not found.");
      }
    });
  });
  if (process.env.NODE_ENV !== "production") {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(import_path.default.join(distPath, "index.html"));
    });
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`TalkReward Production Server running at http://0.0.0.0:${PORT}`);
  });
}
startServer();
//# sourceMappingURL=server.cjs.map
