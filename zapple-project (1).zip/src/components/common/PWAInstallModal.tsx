import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { usePWAInstall } from '../../hooks/usePWAInstall';
import { copyToClipboard } from '../../utils/clipboard';
import {
  Download,
  Smartphone,
  ExternalLink,
  Copy,
  Check,
  X,
  Layers,
  Terminal,
  Share2
} from 'lucide-react';

interface PWAInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PWAInstallModal: React.FC<PWAInstallModalProps> = ({ isOpen, onClose }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [activeTab, setActiveTab] = useState<'instant' | 'apk' | 'cli'>('instant');
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [copiedCmd, setCopiedCmd] = useState(false);

  // Determine current live URL
  const appUrl = typeof window !== 'undefined' ? window.location.origin : 'https://ais-pre-tokkzlrn7wgyadjajt2bh6-945000662871.asia-southeast1.run.app';

  const handleCopyUrl = async () => {
    await copyToClipboard(appUrl);
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 2000);
  };

  const handleCopyCmd = async () => {
    const cmd = `npx @bubblewrap/cli init --manifest=${appUrl}/manifest.json && npx @bubblewrap/cli build`;
    await copyToClipboard(cmd);
    setCopiedCmd(true);
    setTimeout(() => setCopiedCmd(false), 2000);
  };

  const handleInstallClick = async () => {
    const success = await install();
    if (success) {
      onClose();
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="w-full max-w-sm bg-neutral-950 border border-neutral-900 rounded-2xl p-5 space-y-4 max-h-[90vh] flex flex-col"
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-neutral-900 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-white text-black flex items-center justify-center font-bold text-xs">
                  Z
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-white">Convert & Install App</h3>
                  <p className="text-[11px] text-neutral-400">Android APK & PWA Setup</p>
                </div>
              </div>
              <button
                onClick={onClose}
                className="p-1 rounded-lg text-neutral-500 hover:text-white transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Navigation Tabs */}
            <div className="grid grid-cols-3 gap-1 p-1 bg-neutral-900 rounded-xl">
              <button
                onClick={() => setActiveTab('instant')}
                className={`py-1.5 px-2 rounded-lg text-xs font-medium transition-colors cursor-pointer text-center ${
                  activeTab === 'instant'
                    ? 'bg-neutral-800 text-white shadow-xs'
                    : 'text-neutral-400 hover:text-neutral-200'
                }`}
              >
                1-Tap Install
              </button>
              <button
                onClick={() => setActiveTab('apk')}
                className={`py-1.5 px-2 rounded-lg text-xs font-medium transition-colors cursor-pointer text-center ${
                  activeTab === 'apk'
                    ? 'bg-neutral-800 text-white shadow-xs'
                    : 'text-neutral-400 hover:text-neutral-200'
                }`}
              >
                PWABuilder APK
              </button>
              <button
                onClick={() => setActiveTab('cli')}
                className={`py-1.5 px-2 rounded-lg text-xs font-medium transition-colors cursor-pointer text-center ${
                  activeTab === 'cli'
                    ? 'bg-neutral-800 text-white shadow-xs'
                    : 'text-neutral-400 hover:text-neutral-200'
                }`}
              >
                Bubblewrap
              </button>
            </div>

            {/* Content Body */}
            <div className="flex-1 overflow-y-auto space-y-3 pr-0.5 text-xs text-neutral-300">
              {activeTab === 'instant' && (
                <div className="space-y-3">
                  <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-3.5 space-y-2">
                    <div className="flex items-center gap-2 text-white font-medium">
                      <Smartphone className="w-4 h-4 text-emerald-400" />
                      <span>Direct Android Installation</span>
                    </div>
                    <p className="text-neutral-400 leading-relaxed text-[11px]">
                      Install Zapple directly onto your Android home screen as an app without visiting the Play Store. It runs fullscreen with its own app icon and splash screen.
                    </p>
                  </div>

                  {isInstalled ? (
                    <div className="p-3 bg-neutral-900 border border-neutral-800 rounded-xl text-center space-y-1">
                      <Check className="w-5 h-5 text-emerald-400 mx-auto" />
                      <div className="font-medium text-white">App is Already Installed</div>
                      <p className="text-[11px] text-neutral-400">
                        You are running Zapple in standalone app mode.
                      </p>
                    </div>
                  ) : isInstallable ? (
                    <button
                      onClick={handleInstallClick}
                      className="w-full py-3 px-4 rounded-xl bg-white hover:bg-neutral-200 active:scale-[0.99] text-black font-semibold text-xs transition-colors cursor-pointer flex items-center justify-center gap-2"
                    >
                      <Download className="w-4 h-4" />
                      <span>Install Zapple App Now</span>
                    </button>
                  ) : isIOS ? (
                    <div className="p-3 bg-neutral-900 border border-neutral-800 rounded-xl space-y-2">
                      <div className="font-medium text-white">Install on iPhone / iPad</div>
                      <p className="text-neutral-400 leading-relaxed text-[11px]">
                        1. Tap the <Share2 className="w-3.5 h-3.5 inline mx-1 text-white" /> <strong>Share</strong> button in the Safari toolbar.<br />
                        2. Scroll down and tap <strong>Add to Home Screen</strong>.
                      </p>
                    </div>
                  ) : (
                    <div className="p-3 bg-neutral-900 border border-neutral-800 rounded-xl space-y-2">
                      <div className="font-medium text-white">Install via Chrome / Browser Menu</div>
                      <p className="text-neutral-400 leading-relaxed text-[11px]">
                        Open this page in Google Chrome on your Android device, tap the <strong>three dots menu (⋮)</strong> in the top-right corner, and tap <strong>&quot;Install app&quot;</strong> or <strong>&quot;Add to Home screen&quot;</strong>.
                      </p>
                    </div>
                  )}
                </div>
              )}

              {activeTab === 'apk' && (
                <div className="space-y-3">
                  <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-3.5 space-y-2.5">
                    <div className="flex items-center gap-2 text-white font-medium">
                      <Download className="w-4 h-4 text-emerald-400" />
                      <span>Direct Android APK Download</span>
                    </div>
                    <p className="text-neutral-400 leading-relaxed text-[11px]">
                      Install Zapple directly onto any Android device with the standalone signed APK package (supports WebRTC voice calls, audio rewards, and full real-time sync).
                    </p>
                    <a
                      href="/zapple.apk"
                      download="zapple.apk"
                      className="w-full py-2.5 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-400 active:scale-[0.99] text-black font-semibold text-xs transition-all flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20"
                    >
                      <Download className="w-4 h-4" />
                      <span>Download Zapple APK (~15 MB)</span>
                    </a>
                  </div>

                  <div className="flex items-center gap-2 my-2">
                    <div className="h-px bg-neutral-800 flex-1"></div>
                    <span className="text-[10px] text-neutral-500 uppercase tracking-wider font-semibold">Or Build Custom APK</span>
                    <div className="h-px bg-neutral-800 flex-1"></div>
                  </div>

                  {/* App URL Box */}
                  <div className="space-y-1">
                    <label className="text-[11px] font-medium text-neutral-400">
                      Step 1: Copy your App URL
                    </label>
                    <div className="flex items-center gap-2 bg-neutral-900 border border-neutral-800 rounded-xl p-2.5">
                      <span className="font-mono text-[11px] text-neutral-300 truncate flex-1">
                        {appUrl}
                      </span>
                      <button
                        onClick={handleCopyUrl}
                        className="px-2.5 py-1 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-white text-[11px] font-medium flex items-center gap-1 shrink-0 transition-colors cursor-pointer"
                      >
                        {copiedUrl ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                        <span>{copiedUrl ? 'Copied' : 'Copy'}</span>
                      </button>
                    </div>
                  </div>

                  {/* Steps */}
                  <div className="space-y-1.5 text-[11px] text-neutral-400 bg-neutral-900/60 p-3 rounded-xl border border-neutral-900">
                    <div className="font-medium text-neutral-300">Step 2: Generate APK on PWABuilder</div>
                    <div>1. Visit <strong>pwabuilder.com</strong></div>
                    <div>2. Paste the URL and click <strong>&quot;Start&quot;</strong></div>
                    <div>3. Click <strong>&quot;Build My PWA&quot;</strong> &rarr; Select <strong>Android</strong></div>
                    <div>4. Click <strong>&quot;Download Package&quot;</strong> to get your signed APK!</div>
                  </div>

                  <a
                    href="https://www.pwabuilder.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full py-2.5 px-4 rounded-xl bg-white hover:bg-neutral-200 active:scale-[0.99] text-black font-semibold text-xs transition-colors cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    <span>Open PWABuilder.com</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              )}

              {activeTab === 'cli' && (
                <div className="space-y-3">
                  <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-3.5 space-y-2">
                    <div className="flex items-center gap-2 text-white font-medium">
                      <Terminal className="w-4 h-4 text-white" />
                      <span>Google Bubblewrap CLI</span>
                    </div>
                    <p className="text-neutral-400 leading-relaxed text-[11px]">
                      Build an Android APK directly from terminal using Google&apos;s official Trusted Web Activity (TWA) CLI.
                    </p>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[11px] font-medium text-neutral-400">
                      Terminal Command:
                    </label>
                    <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-2.5 space-y-2">
                      <code className="text-[10px] font-mono text-neutral-300 block break-all leading-relaxed">
                        npx @bubblewrap/cli init --manifest={appUrl}/manifest.json &amp;&amp; npx @bubblewrap/cli build
                      </code>
                      <button
                        onClick={handleCopyCmd}
                        className="w-full py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-white text-[11px] font-medium flex items-center justify-center gap-1 transition-colors cursor-pointer"
                      >
                        {copiedCmd ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                        <span>{copiedCmd ? 'Command Copied' : 'Copy Terminal Command'}</span>
                      </button>
                    </div>
                  </div>

                  <div className="text-[11px] text-neutral-400 space-y-1">
                    <p>&bull; Requires Node.js and Android SDK / JDK.</p>
                    <p>&bull; Generates an APK and AAB with assetlinks.json integration.</p>
                  </div>
                </div>
              )}
            </div>

            {/* Close Button */}
            <button
              onClick={onClose}
              className="w-full py-2.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 active:scale-[0.99] text-neutral-300 font-medium text-xs transition-colors cursor-pointer"
            >
              Close
            </button>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
